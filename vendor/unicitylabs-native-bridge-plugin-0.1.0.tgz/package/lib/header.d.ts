/** `keccak256(rlp([]))`, the empty-uncle-list hash. */
export declare const EMPTY_UNCLE_HASH: Uint8Array<ArrayBuffer>;
/** The empty trie root, also the empty withdrawals root. */
export declare const EMPTY_TRIE_ROOT: Uint8Array<ArrayBuffer>;
/** The pinned header shape: 20 fields (Cancun, through parentBeaconBlockRoot) or 21 (+ requestsHash). */
export interface HeaderProfile {
    fields: 20 | 21;
}
export interface Header {
    stateRoot: Uint8Array;
    number: bigint;
}
/** Decode and check a header against the pinned profile. */
export declare function decodeHeader(raw: Uint8Array, profile: HeaderProfile): Header;
