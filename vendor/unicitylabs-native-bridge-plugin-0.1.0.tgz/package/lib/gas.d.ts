import type { Envelope, LeafProof } from './envelope.js';
import { type Counts } from './certgroups.js';
/** Items of the fixed-shape objects the verifier opens itself: Cfg (array head and 15 fields... as counted by the oracle), policy, one IR opening per anchor. */
export declare const CFG_ITEMS = 17;
export declare const POLICY_ITEMS = 4;
export declare const IR_ITEMS = 12;
/** `D_max = 4 + 128 + pad32(B_cfg) + pad32(B_env)`: the calldata of the canonical call, an allowance. */
export declare const maxCalldata: (cfgBytes: number, envelopeBytes: number) => number;
/** `21000 + 16*D_max + 80*B_env`. */
export declare const intrinsicGas: (cfgBytes: number, envelopeBytes: number) => number;
/** `len(abi.encode(uint8 op, bytes cfg, bytes payload))`. */
export declare const kernelRequestBytes: (cfgBytes: number, payloadBytes: number) => number;
/** `G_kernel = 26000 + 20*B_kernel + 14000*L`. */
export declare const b2Gas: (requestBytes: number, leaves: number) => number;
/** `G_leaf = 2000 + 16*(136 + 32*s) + 250*(1 + s)`. */
export declare const rsmtGas: (siblings: number) => number;
/** `G_items = 1000*J`. */
export declare const itemGas: (items: number) => number;
/** The items the verifier itself opens besides the UC occurrences: Cfg, policy and one IR opening per anchor. */
export declare const fixedItems: (anchors: number) => number;
/** Bound one leaf path (bitmap popcount equal to the sibling count, at most `MAX_RSMT_SIBLINGS`) and price its member call. */
export declare function leafPathGas(p: LeafProof): {
    gas: number;
    steps: number;
};
/** The dimensions the BRIDGE_COMPOSE_V1 schedule prices (bft-core `ComposeDims`). */
export interface ComposeDims {
    b: number;
    j: number;
    l: number;
    q: number;
    e: number;
    a: number;
    k: number;
    p: number;
}
export declare const COMPOSE_BASE = 100000;
export declare const COMPOSE_PER_BYTE = 2;
export declare const COMPOSE_PER_ITEM = 20;
export declare const COMPOSE_PER_LEAF = 16000;
export declare const COMPOSE_PER_SIGNATURE = 7200;
export declare const COMPOSE_PER_EPOCH = 29900;
export declare const COMPOSE_PER_CLAIM = 2000;
export declare const COMPOSE_PER_STEP = 250;
export declare const COMPOSE_PER_GROUP_STEP = 50;
/** `50*K*ceil(log2 K)`: sort-based grouping of K claim occurrences (zero for K <= 1). */
export declare const composeGroupGas: (k: number) => number;
/** The native charge of a BRIDGE_COMPOSE_V1 call that succeeds. */
export declare const composeGas: (d: ComposeDims) => number;
export interface Gate {
    /** The BRIDGE_COMPOSE_V1 dimensions and their native charge. */
    compose: ComposeDims;
    native: number;
    intrinsic: number;
    b2: number;
    /** `G_batch`. */
    batch: number;
    /** `G_items`. */
    items: number;
    rsmt: number;
    steps: number;
    /** J, the bridge CBOR item occurrences. */
    j: number;
    /** The grouping the batch is priced by. */
    grouping: Counts;
    /** The transaction estimate: `21000 + 16*D_max + G_compose + 1,000,000`. */
    total: number;
    /** The protocol-5 composite of the corpus `gate` cases (`G_gate`). */
    legacyTotal: number;
}
/** `21000 + 16*D_max`: the calldata intrinsic gas of the canonical two-bytes-argument call. */
export declare const calldataGas: (cfgBytes: number, envelopeBytes: number) => number;
/** Estimate a complete bounded envelope (never a refusal): the native charge, the transaction estimate and the legacy composite. */
export declare function computeGate(cfg: Uint8Array, envelopeBytes: number, kernelRequest: number, e: Envelope): Gate;
/**
 * Lower bounds for the best-case projection, each at most what a real bundle can cost: the smallest certificate in the corpus
 * (the one-signature fixture, 445 bytes at depth 0), one signature, and an input record of no bytes.
 */
export declare const BEST_UC_BYTES = 445;
export declare const BEST_IR_BYTES = 0;
export declare const BEST_SIGNATURES = 1;
/** The CBOR items of the smallest certificate: the fixture's depth-0 certificate has 45 with four signatures, each signature entry is two (key and value). */
export declare const BEST_UC_ITEMS = 39;
/**
 * The burn-time best-case projection: the estimate of the redemption envelope a token with `leaves` leaves (the burn included) and a
 * `historyBytes` history would need if everything the burn cannot yet know turns out as small as it can: the consolidated bundle,
 * `anchors` anchors (one per aggregator shard the leaves touch, at least 1, at most `leaves`) under ONE seal, the smallest
 * certificates and empty paths. With the shard count unknown the best case is one anchor (a single certificate may serve every leaf).
 * It is the burn-time estimate only: nothing is refused for its size (owner section 36); the bundle actually fetched is estimated at
 * redemption.
 */
export declare function projectedGate(cfgBytes: number, policyBytes: number, leaves: number, historyBytes: number, anchors?: number): {
    gate: Gate;
    envelopeBytes: number;
};
