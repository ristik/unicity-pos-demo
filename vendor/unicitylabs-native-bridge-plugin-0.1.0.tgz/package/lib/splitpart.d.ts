import { PaymentAssetCollection } from '@unicitylabs/state-transition-sdk/lib/payment/asset/PaymentAssetCollection.js';
import type { IPaymentData } from '@unicitylabs/state-transition-sdk/lib/payment/IPaymentData.js';
import type { InclusionProof } from '@unicitylabs/state-transition-sdk/lib/api/InclusionProof.js';
import type { Token } from '@unicitylabs/state-transition-sdk/lib/transaction/Token.js';
/**
 * The bridge's value envelope `tag(39050,[1,[[b(aid32),b(amount)]],null])` as SDK payment data: exactly one asset, no memo, the exact
 * canonical bytes. The deployment's asset is the issuance policy's check; this decoder only refuses everything that is not an envelope.
 */
export declare class WalletValue implements IPaymentData {
    readonly assets: PaymentAssetCollection;
    private readonly bytes;
    private constructor();
    static of(aid: Uint8Array, amount: Uint8Array): WalletValue;
    /** Strict decode; throws on anything but one exact envelope. */
    static decode(bytes: Uint8Array): Promise<WalletValue>;
    encode(): Promise<Uint8Array>;
}
/** Whether a mint justification is a split reason (the token is a split part, not a lock-backed root). */
export declare const isSplitReason: (j: Uint8Array | null) => boolean;
/**
 * The lock reason of a part's root: walk the exact split reasons (each embeds its burned parent) down to the token minted from the
 * lock. Structure only: the relation and the SDK verify the walk; this only finds which deployment the part belongs to.
 */
export declare function rootJustification(j: Uint8Array | null): Uint8Array;
/** The part's ancestry as SDK tokens, root first, ending with the part itself. */
export declare function splitChain(part: Token): Promise<Token[]>;
/** Every certified transaction's proof of the lineage, root first, in the relation's leaf order (each token's mint, then its transfers). */
export declare const lineageProofs: (chain: readonly Token[]) => InclusionProof[];
