import { DeploymentRegistry, type Deployment } from './deployment.js';
import { NativeBridge } from './verifier.js';
import type { TrustInput } from './trust.js';
/** Resolver for artifacts pinned by SHA-256 (the installer's local artifact store). */
export type Artifacts = (sha256Hex: string) => Uint8Array | undefined;
export interface TrustPin {
    network: number;
    rootGenesis: Uint8Array;
    /** The EntryID of the trust base genesis entry. */
    genesisEntryId: Uint8Array;
}
/** Validate one entry (its registry key already matched) and return its deployments, active first. */
export declare function validateManifest(raw: unknown, artifacts?: Artifacts): {
    deployments: Deployment[];
    pin: TrustPin;
};
/** A validated registry and the trust-base genesis pins it names. */
export declare class Loaded {
    readonly registry: DeploymentRegistry;
    readonly trustPins: readonly TrustPin[];
    constructor(registry: DeploymentRegistry, trustPins: readonly TrustPin[]);
    /**
     * Install: every entry's pinned genesis must be exactly the installed trust input's, on its network. The history may have grown past the
     * named bundle (a wallet's own exported history, a newer release): the authority is the genesis pin and the witnessed appends.
     */
    install(trust: TrustInput): NativeBridge;
}
/**
 * Parse a manifest registry (an object keyed by `tokenTypeHex`), validate every entry and return
 * the allow-list. A key differing from its entry's `tokenTypeHex`, or any vault claimed twice, is
 * rejected.
 */
export declare function loadManifests(json: string, artifacts?: Artifacts): Loaded;
/** The pinned `trustBaseId` (trust base genesis EntryID) of one manifest entry. */
export declare function manifestTrustBaseId(raw: unknown): Uint8Array;
