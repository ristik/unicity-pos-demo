/** The native certificate scan bounds of `resources.ts` (bft-go-base's CBOR limits and the B1 UC byte cap). */
export declare const MAX_CBOR_DEPTH = 16;
export declare const MAX_CBOR_ITEMS = 32768;
export declare const MAX_UC_BYTES: number;
