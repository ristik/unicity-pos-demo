/**
 * The resource policy of the direct path (owner section 36, bft-core briefs/b7-direct-uncapped-design.md section 1) and fixed
 * protocol constants. The numbers of the first block are the `limits` of `protocol/profile-v7.json` (the single source shared with
 * the oracle and the contract; `test/limits.test.ts` pins them). There is no gas ceiling and no history cap: the composition
 * (BRIDGE_COMPOSE_V1) streams the history and the anchor table, bounded by the envelope (the ingress bound the pool and RPC carry),
 * the u16 anchor wire width and its gas (bft-core briefs/dev4-b7-native-compose-spec.md section 7). The transfer, leaf and
 * semantic-byte bounds are the standalone B2 kernel's own (0x0104, which prepareLock calls); the rest are per-object shape bounds.
 * Every count is checked before allocation or cryptography.
 */
export declare const NATIVE_BRIDGE_PROTO_VERSION: 7;
/** Distinct UC anchors of one redemption: the wire width (the CERT_BATCH_V2 claim count and every anchorIndex are u16). */
export declare const MAX_ANCHORS = 65535;
/** Standalone B2 transfers including the final burn (ureth b2 `MAX_TRANSFERS`). */
export declare const MAX_TRANSFERS = 64;
/** Standalone B2 leaves: the mint and every transfer (the kernel's result bound). */
export declare const MAX_LEAVES: number;
/** Standalone B2 history and Cfg input (ureth b2 `MAX_HISTORY`). */
export declare const MAX_SEMANTIC_BYTES: number;
/** Ingress: the composition's only aggregate byte bound. */
export declare const MAX_ENVELOPE_BYTES: number;
export declare const MAX_ANCHOR_UC_BYTES: number;
export declare const MAX_RSMT_SIBLINGS = 32;
export declare const MAX_POLICY_BYTES = 512;
/** B1's own sublimits, which the gate prices. */
export declare const MAX_UNICITY_STEPS = 32;
/** Signatures of one seal (`CERT_BATCH_V2`, contract section 4). */
export declare const MAX_SIGS_PER_SEAL = 16;
/** A native shard ID is 1..33 bytes (depth 0..256). */
export declare const MAX_SHARD_BYTES = 33;
export declare const MAX_SHARD_DEPTH = 256;
export declare const MAX_BATCH_UC_BYTES = 24576;
export declare const GAS_RESERVE = 1000000;
/** The price of one bridge CBOR item occurrence (Cfg, policy, every UC and every IR opening). */
export declare const BRIDGE_ITEM_GAS = 1000;
export declare const MAX_CBOR_DEPTH = 16;
export declare const MAX_CBOR_ITEMS = 32768;
export declare const MAX_RLP_DEPTH = 16;
export declare const MAX_AMOUNT_BYTES = 32;
/** The aggregate bounds of one history decode: bytes, transfers (the final burn included) and the CBOR items of the whole history. */
export interface HistoryBounds {
    readonly bytes: number;
    readonly transfers: number;
    readonly items: number;
}
/** The standalone kernel's (0x0104). */
export declare const KERNEL_HISTORY: HistoryBounds;
/** The composition's: the history is bounded by the envelope that carries it; every item and leaf is paid. */
export declare const COMPOSED_HISTORY: HistoryBounds;
export declare const MAX_JUSTIFICATION_BYTES: number;
export declare const MAX_UC_BYTES: number;
export declare const MAX_PDR_BYTES: number;
export declare const MAX_HEADER_BYTES: number;
export declare const MAX_MPT_NODES = 65;
export declare const MAX_MPT_NODE_BYTES: number;
export declare const MAX_MPT_TOTAL_BYTES: number;
export declare const MAX_INPUT_RECORD_BYTES = 512;
/** The native sublimit of the certified input record's summary value (`InputRecord._scan`, `resources.ts`). */
export declare const MAX_IR_SUMMARY_BYTES = 256;
export declare const MAX_TOKEN_BYTES: number;
export declare const TAG_PREDICATE = 39032n;
export declare const TAG_TOKEN = 39040n;
export declare const TAG_INCLUSION = 39033n;
export declare const TOKEN_VERSION = 2n;
export declare const INCLUSION_VERSION = 1n;
/** The SDK token decode (bft-core `DecodeToken`): a whole token and one proof's certificate. A nested ancestor also lies inside the
 * envelope, so the envelope bound binds first. */
export declare const MAX_DECODED_TOKEN_BYTES: number;
export declare const MAX_PROOF_UC_BYTES: number;
export declare const SPLIT_PROTO_VERSION: 7;
export declare const TAG_SPLIT_JUSTIFICATION = 39044n;
export declare const TAG_SPLIT_MANIFEST = 39046n;
/** One allocation-proof step per key bit. */
export declare const MAX_SUM_PROOF_STEPS = 256;
export declare const TAG_MINT = 39041n;
export declare const TAG_TRANSFER = 39045n;
export declare const TAG_CERTIFICATION = 39031n;
export declare const TAG_MINT_LOCK = 39049n;
export declare const TAG_RETURN_REASON = 39048n;
export declare const TAG_WALLET_VALUE = 39050n;
export declare const TAG_INPUT_RECORD = 39002n;
export declare const MINT_LOCK_VERSION = 2n;
export declare const LOCK_PROOF_VERSION = 1n;
export declare const PRED_SIGNATURE = 1;
export declare const PRED_BURN = 2;
export declare const NATIVE_BRIDGE_FAMILY: "unicity-native";
export declare const FAMILY: "unicity-native";
export declare const SDK_VERSION: "4.0.0";
