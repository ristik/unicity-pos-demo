/**
 * The host readiness contract for return proofs (`protocol/interop.md` "Assembly and refresh").
 *
 * Protocol 4 has no certificate-age window: B1 accepts an anchor whose seal round `r` lies in its epoch's permanent registry
 * entry, `start <= r <= O` (and `r < end` for a closed epoch), `O` being the registry `clock.rootRound` at the redemption's
 * EXECUTION block. An old certificate never expires; a NEW one can be ahead of the registry, whose origin only advances when the
 * system import lands. So the only advisory check left is `max(r) <= O` on the origin the host last read; the executing block
 * imports its own origin, so a read of the latest block is advisory and a refusal on chain is final.
 *
 * Everything here consumes host transports (the chain reader, the proof source, the transaction sender) and never decides
 * admission: a wrongly judged proof is refused on chain. A proof ahead of the origin is repaired by waiting, a racing (path, UC)
 * pair by refetching the proofs of the SAME burned token (exact M/T/CD/t/J preserved), never by rebuilding or re-burning, and never
 * to obtain matching certificates or fewer anchors. An exhausted wait is `ErrProofUnavailable` with a cause (the unavailable
 * family, retryable); a bound overflow (anchors, gas, size) stays a budget refusal and is never retried.
 */
import { NativeError } from './errors.js';
import { type ConsolidationPath, type NativeBridgePlugin, type ProofSource, type ReturnProofPath } from './wallet.js';
import { Token } from '@unicitylabs/state-transition-sdk/lib/transaction/Token.js';
/** What the chain says about the registry, read by the host from the registry. */
export interface ChainReader {
    /** The registry's `clock.rootRound` as of the latest block. */
    origin(): Promise<bigint>;
}
/** How the bundle's anchors stand against the origin: `future` means the newest anchor is beyond it (waiting helps). */
export type Readiness = 'ok' | 'future';
/** Classify the seal rounds of a bundle's distinct anchors against the origin the host last read. */
export declare function classifyReadiness(rounds: readonly bigint[], origin: bigint): Readiness;
export interface ReadinessPolicy {
    /** Fetch-and-assemble attempts (each re-fetches every leaf's proof) before the proof is reported unavailable. */
    maxAttempts: number;
    /** The longest the origin is awaited, per attempt, when an anchor is newer than it. */
    maxOriginWaitMs: number;
    pollMs: number;
    /**
     * The consolidated path (the default when the host supplies it): its first attempt uses the consolidated token's outer proofs,
     * re-attached to the held token; an unavailable consolidation, and every later attempt, fetch per SID from the source. The fresh
     * master seal is awaited against the origin like any anchor.
     */
    consolidation?: ConsolidationPath;
    /** Test seams. */
    sleep?: (ms: number) => Promise<void>;
    now?: () => number;
}
export declare const DEFAULT_READINESS: ReadinessPolicy;
/**
 * The distinct seal rounds of a token's anchors (byte-identical certificates counted once). A split part's anchors are the whole
 * lineage's: an ancestor's burn may have been certified just before the part was redeemed, so its round is awaited like the part's.
 */
export declare function anchorRounds(token: Token): Promise<bigint[]>;
export interface ReadyReturnProof {
    encoded: Uint8Array;
    nullifier: Uint8Array;
    /** The anchors' seal rounds and the origin they were last judged against (for the host's records). */
    rounds: bigint[];
    origin: bigint;
    /** Fetch rounds used (1 = the first fetch was ready). */
    attempts: number;
    /** Whether the bundle came from the consolidated token or per-SID proofs. */
    path: ReturnProofPath;
}
/**
 * Fetch every leaf's current proof, assemble the envelope and send it nowhere: return it once no anchor is
 * ahead of the origin. Every attempt re-fetches all leaves for the same burned token. An anchor newer than the
 * origin is awaited for at most `maxOriginWaitMs`.
 */
export declare function buildReadyReturnProof(plugin: NativeBridgePlugin, tokenBytes: Uint8Array, source: ProofSource, chain: ChainReader, policy?: ReadinessPolicy, sends?: number): Promise<ReadyReturnProof>;
/** The transaction transport and the vault's state, supplied by the host. */
export interface RedeemTransport {
    /** Broadcast `redeem(bytes)` and return the transaction hash. It may throw on a timeout after the transaction was in fact accepted. */
    send(data: Uint8Array): Promise<string>;
    /** The receipt of a sent transaction: undefined while it is not mined. */
    receipt(txHash: string): Promise<'success' | 'reverted' | undefined>;
    /**
     * The vault's spent state for one part of a lock (protocol 6): `spentPart(nonce, partId)`, the burn nullifier the vault stored when it
     * credited that part. The vault keys spent state by (root lock NONCE, part token ID) and keeps the nullifier as the stored value (and in
     * `RedemptionCredited`, whose indexed topics are nonce, partId and recipient); it has no nullifier-keyed lookup. A whole (unsplit) token
     * is the part whose ID is the root token ID. `undefined` or an all-zero word: not redeemed. A host that only has the logs may answer from
     * `RedemptionCredited`.
     */
    spentPart(nonce: bigint, partId: Uint8Array): Promise<Uint8Array | undefined>;
}
/** What `redeemReturn` tells the host's journal, in order: before every send, and with its hash (undefined when the send failed without one). */
export interface RedeemObserver {
    beforeSend?(): Promise<void>;
    sent?(txHash: string | undefined): Promise<void>;
}
export interface RedeemPolicy extends ReadinessPolicy {
    /** Sends before giving up. Each re-fetches every proof for the same burned token. */
    maxSends: number;
    receiptTimeoutMs: number;
}
export declare const DEFAULT_REDEEM: RedeemPolicy;
export type RedeemResult = {
    status: 'redeemed';
    txHash?: string;
    nullifier: Uint8Array;
    sends: number;
} | {
    status: 'already-redeemed';
    nullifier: Uint8Array;
    sends: number;
};
/**
 * A redemption whose outcome is unknown: no receipt and no vault change within `receiptTimeoutMs`. It is still an
 * `ErrProofUnavailable` (retryable), but `txHash` is the sent transaction (absent when the send itself failed without a hash) and
 * the caller keeps it: pass it back in `pending` so the next call checks its receipt before any new send.
 */
export declare class RedemptionUnconfirmed extends NativeError {
    readonly txHash: string | undefined;
    constructor(txHash: string | undefined);
}
/** What the vault knows a return token by. */
export interface ReturnIdentity {
    /** The ROOT lock's nonce. */
    nonce: bigint;
    /** The redeemed part's token ID (the root token ID for a whole token): with the nonce, the spent-state key. */
    partId: Uint8Array;
    /** The part's whole amount, which the redemption credits. */
    partAmount: bigint;
    /** The part's burn nullifier (the stored value). */
    nullifier: Uint8Array;
}
/** The identity the vault knows a return token by: (root lock nonce, part token ID) and its burn nullifier. Needs no aggregator proof. */
export declare function returnIdentity(plugin: NativeBridgePlugin, tokenBytes: Uint8Array): Promise<ReturnIdentity>;
/**
 * Redeem a burned token. The vault is asked FIRST (after the receipts of the hashes in `pending`), before any proof is fetched and before the origin is read: an already executed
 * redemption (a third party's, or an earlier send of ours whose hash was lost) is reported as such even when the proof service is down or the
 * origin cannot be met. Then every hash in `pending` (an earlier unconfirmed send) is checked: a success ends the call, a transaction still
 * pending, with the vault still not showing the nonce credited, leaves the call unconfirmed again with no new send, a revert is dropped. Before every send the vault's state is read again. After a send
 * the receipt and the vault state, never the RPC's answer alone, decide the next step: an RPC timeout is not a revert. A revert refetches every
 * proof for the same token and sends again, within `maxSends`, whatever its cause: a deterministic refusal (a closed authority interval, bad
 * backing) therefore costs `maxSends` transactions. A send whose outcome is unknown is never repeated while it may still be pending (see
 * `RedemptionUnconfirmed`). The wallet burn is never repeated. `observer` lets the host journal each step (`beforeSend`, `sent`).
 */
export declare function redeemReturn(plugin: NativeBridgePlugin, tokenBytes: Uint8Array, source: ProofSource, chain: ChainReader, transport: RedeemTransport, policy?: RedeemPolicy, pending?: readonly string[], observer?: RedeemObserver): Promise<RedeemResult>;
