import type { Token } from '@unicitylabs/state-transition-sdk/lib/transaction/Token.js';
import type { Deployment } from './deployment.js';
import { type HistoryBounds } from './limits.js';
import { type Item } from './scan.js';
export interface Pred {
    type: number;
    params: Uint8Array;
}
export declare const predBytes: (p: Pred) => Uint8Array;
/** The exact predicate bytes of an encoded predicate, strictly decoded and re-encoded. */
export declare const decodePredicateBytes: (b: Uint8Array) => Uint8Array;
export interface Mint {
    network: number;
    recipient: Pred;
    salt: Uint8Array;
    ty: Uint8Array;
    justification: Uint8Array | null;
    data: Uint8Array | null;
    expiresAt: bigint | null;
}
export interface Transfer {
    recipient: Pred;
    mask: Uint8Array;
    data: Uint8Array | null;
    expiresAt: bigint | null;
}
export interface Cd {
    source: Pred;
    sourceHash: Uint8Array;
    txHash: Uint8Array;
    expiresAt: bigint | null;
    unlock: Uint8Array;
}
export declare function decodeCd(it: Item): Cd;
export declare function decodeMint(it: Item): Mint;
export declare function decodeTransfer(it: Item): Transfer;
export interface History {
    mint: Mint;
    mintCd: Cd;
    mintT: bigint;
    transfers: Transfer[];
    cds: Cd[];
    times: bigint[];
    mintRaw: Uint8Array;
    transfersRaw: Uint8Array[];
}
/**
 * Strictly decode `C([M,CD0,t0],[[T1,CD1,t1],...])`; the transfer count is bounded first. The default bounds are the standalone
 * kernel's (`KERNEL_HISTORY`); a wallet decodes a held history as the composition does (`COMPOSED_HISTORY`).
 */
export declare function decodeHistory(b: Uint8Array, lim?: HistoryBounds): History;
export interface Leaf {
    sid: Uint8Array;
    txHash: Uint8Array;
    referenceTime: bigint;
    value: Uint8Array;
    expiresAt: bigint | null;
}
export interface Outcome {
    cfg: Uint8Array;
    nonce: bigint;
    amount: Uint8Array;
    tokenId: Uint8Array;
    salt: Uint8Array;
    firstPredicateHash: Uint8Array;
    lockDigest: Uint8Array;
    releaseTo: Uint8Array;
    nullifier: Uint8Array;
    leaves: Leaf[];
}
export declare const stateId: (source: Pred, sourceHash: Uint8Array) => Uint8Array;
export declare const resultState: (sourceHash: Uint8Array, mask: Uint8Array) => Uint8Array;
export declare const mintSourceHash: (id: Uint8Array) => Uint8Array;
export declare function minterKey(id: Uint8Array): Uint8Array;
/** `prepareLock`: validate a lock request and derive the values the vault compares with its own. */
export declare function prepareLock(dep: Deployment, n: bigint, amount: Uint8Array, p0: Uint8Array): Outcome;
/** Parse and cross-check the mint justification against the deployment, returning the nonce (bft-core `ParseJustification`, in
 * its order). Structure only; the proof's cryptography needs the trust input. */
export declare function checkJustification(dep: Deployment, j: Uint8Array | null): bigint;
/** Exactly `tag(39050,[1,[[b(aid),b(amount)]],null])`; returns the amount. */
export declare function checkMintData(dep: Deployment, d: Uint8Array | null): Uint8Array;
export declare function checkStep(source: Pred, sourceHash: Uint8Array, txRaw: Uint8Array, txDeadline: bigint | null, cd: Cd, t: bigint, key: Uint8Array, seen: Set<string>): Promise<Leaf>;
/** The relation. `wantBurn` selects the return relation (terminal burn) or the receipt relation. */
export declare function verifyHistory(dep: Deployment, hist: History, wantBurn: boolean): Promise<Outcome>;
export declare function checkReturn(dep: Deployment, out: Outcome, t: Transfer): void;
/**
 * Export the compact history of an SDK token: the unchanged tagged transactions and certification
 * data with each original reference time `t`, and no inclusion proofs.
 */
export declare function projectToken(token: Token): Uint8Array;
