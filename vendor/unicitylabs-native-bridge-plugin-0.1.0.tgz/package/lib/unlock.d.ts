/** `H(C(b(sourceHash32), b(txHash32)))` with no extra prehash. */
export declare const unlockMessage: (sourceHash: Uint8Array, txHash: Uint8Array) => Uint8Array;
/**
 * The one token-unlock acceptance rule: exactly 65 bytes, 1<=r<n, 1<=s<=n/2, recovery ID 0..3,
 * recover the signer, require equality with the reconstructed source key, then verify the compact
 * signature through the SDK. No normalisation; IDs 2/3 need a real matching recovery.
 */
export declare function verifyUnlock(key33: Uint8Array, sourceHash: Uint8Array, txHash: Uint8Array, unlock: Uint8Array): Promise<void>;
export declare function parseKey(b: Uint8Array): Uint8Array;
