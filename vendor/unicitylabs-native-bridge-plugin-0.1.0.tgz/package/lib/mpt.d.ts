/**
 * The value of `key` (32 bytes, the hashed path) under `root`, from the ordered root-to-leaf list of hash-referenced nodes (nodes under 32
 * bytes are embedded in their parent). bft-core `mptVerify` exactly, with its reasons: a node that is not canonical, mis-hashed or out of order
 * `ErrMPTNode`; a path the supplied nodes do not take to its end `ErrMPTPath`; the key absent `ErrMPTAbsent`; a node left unused
 * `ErrMPTExtraneous`. The root is hash-referenced whatever its size.
 */
export declare function verifyProof(root: Uint8Array, key: Uint8Array, nodes: Uint8Array[]): Uint8Array;
