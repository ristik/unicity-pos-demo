/** A scanned CBOR item of the profile subset, with its byte span. */
export type Item = {
    kind: 'uint';
    value: bigint;
    start: number;
    end: number;
} | {
    kind: 'bytes';
    data: Uint8Array;
    start: number;
    end: number;
} | {
    kind: 'array';
    kids: Item[];
    start: number;
    end: number;
} | {
    kind: 'tag';
    tag: bigint;
    content: Item;
    start: number;
    end: number;
} | {
    kind: 'null';
    start: number;
    end: number;
} | {
    kind: 'text';
    data: Uint8Array;
    start: number;
    end: number;
} | {
    kind: 'map';
    kids: Item[];
    start: number;
    end: number;
};
/**
 * Strict scanner: shortest-form heads, definite lengths; text strings, maps, floats and every
 * simple value other than null are forbidden.
 */
export declare function scanOne(b: Uint8Array, maxItems?: number): Item;
/**
 * {@link scanOne} for items that embed a native certificate (bft-core `scanOneNative`): definite text strings and maps are
 * admitted, which the profile's own objects never use but the certificate inside an SDK inclusion proof does. Canonical key order
 * inside that certificate is the certificate scan's concern, not this scanner's.
 */
export declare function scanNative(b: Uint8Array, maxItems?: number): Item;
/** The scan and its item count (bft-core `scanner.tokens`), which the composition charges per item. */
export declare function scanCounted(b: Uint8Array, maxItems: number, native: boolean): {
    root: Item;
    tokens: number;
};
export declare const raw: (b: Uint8Array, it: Item) => Uint8Array;
export declare function arrayOf(it: Item, n?: number): Item[] | null;
export declare function bytesN(it: Item, n: number): Uint8Array;
export declare const bytesAny: (it: Item) => Uint8Array;
export declare function tagContent(it: Item, tag: bigint): Item;
export declare const uint: (it: Item) => bigint;
export declare function uintMax(it: Item, max: bigint): bigint;
export declare function version(it: Item, want: bigint): void;
/** A positive minimal big-endian amount of at most 32 bytes. */
export declare function amount(it: Item): Uint8Array;
export declare function nullableBytes(it: Item): Uint8Array | null;
export declare function nullableUint(it: Item): bigint | null;
/**
 * Split a canonical native tag(39008, PDR array) into the raw bytes of its elements. The PDR carries text and a
 * map, so it cannot use {@link scanOne}; canonical form is still enforced: shortest heads, definite
 * lengths, strictly bytewise-increasing map keys, valid UTF-8, no floats, no nested tags.
 */
export declare function pdrElements(b: Uint8Array): Uint8Array[];
