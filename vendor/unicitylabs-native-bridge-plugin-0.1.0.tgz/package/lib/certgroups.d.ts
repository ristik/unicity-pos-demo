/** The fields of a batch claim (an `Anchor` without the opening). */
export interface Claim {
    partition: number;
    shard: Uint8Array;
    shardConfHash: Uint8Array;
    expectedStateRoot: Uint8Array;
    expectedIRHash: Uint8Array;
    uc: Uint8Array;
}
/** The most claims one composed batch carries (`K`): the u16 wire count. */
export declare const MAX_CLAIMS = 65535;
export interface Counts {
    k: number;
    c: number;
    e: number;
    s: number;
    q: number;
    a: number;
    p: number;
    /** CBOR items over all UC occurrences, before deduplication. */
    items: number;
}
/** `G_scan(C, K) = 60000 + 16*C + 500*K*(K-1)`. */
export declare const scanGas: (c: number, k: number) => number;
/** `G_batch`: what the native call is forwarded and charges. */
export declare const batchGas: (n: Counts) => number;
/** The CBOR item occurrences of one complete canonical object (`J` contribution), refused as soon as the next item would cross `left`. */
export declare function countItems(b: Uint8Array, left: number): number;
/** Scan and group the claims of one batch. Each UC occurrence is scanned within its own `MAX_CBOR_ITEMS`. */
export declare function measure(claims: readonly Claim[]): Counts;
/** The `CERT_BATCH_V2` request: `version 2 | flags 0 | K:u16 | Claim[K]`, each `partition:u32 | shardLen:u16 | shard | three hashes | ucLen:u32 | uc`. */
export declare function batchRequest(claims: readonly Claim[]): Uint8Array;
