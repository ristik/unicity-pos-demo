import { type Cd, type History, type Mint, type Transfer } from './history.js';
/**
 * The bounded certificate scan every token-carried certificate passes before anything proportional to its contents: the native shape
 * and sublimit scan intersected with the SDK codec subset. Signatures and quorum stay the verifier's.
 */
export declare function scanCertificate(rawUc: Uint8Array): void;
/** A certified inclusion proof; pending or uncertified responses are not proofs and have no encoding here. */
export interface InclusionProof {
    cd: Cd;
    /** the reference time: part of the certified leaf, never a UC timestamp */
    t: bigint;
    bitmap: Uint8Array;
    siblings: Uint8Array[];
    /** the canonical native certificate, an inline CBOR item */
    uc: Uint8Array;
}
/** A strictly decoded SDK token: its mint, transfers and proofs, with the exact transaction bytes. */
export interface SdkToken {
    mint: Mint;
    mintProof: InclusionProof;
    transfers: Transfer[];
    proofs: InclusionProof[];
    mintRaw: Uint8Array;
    transfersRaw: Uint8Array[];
}
/**
 * Strictly decode an entire SDK token: every proof mandatory and complete; trailing bytes, extra slots and a separate
 * reference-time slot are refused. A token is bounded by its bytes alone: its transfers and items are those of the history the
 * composition streams.
 */
export declare function decodeToken(b: Uint8Array): SdkToken;
/** The B2 projection of a decoded token: the same tagged transactions and CDs, each `t` taken solely from its proof. */
export declare const projectSdkToken: (t: SdkToken) => History;
