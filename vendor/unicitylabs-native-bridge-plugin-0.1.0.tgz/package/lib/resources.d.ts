export declare function preflightToken(bytes: Uint8Array): void;
/**
 * The native certificate sublimit scan alone (the step bft-core `scanCertificate` takes from `b1ref.ScanUC`), with the B1 byte cap
 * `maxBytes`; any failure is the caller's to classify.
 */
export declare function nativeUcScan(bytes: Uint8Array, maxBytes: number): void;
export declare function preflightUc(bytes: Uint8Array): void;
