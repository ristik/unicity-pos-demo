/**
 * The wallet's path from a durable burn to claimed native funds, journalled at each step (`RedemptionEntry.status`):
 * `burned` -> `submitted` (a redeem was sent, every hash kept) -> `redeemed` (the vault credited the recipient) -> `settled` (the claim was
 * confirmed by its receipt and by the `claimable` balance falling by the claimed amount). Settlement is never inferred from the wallet burn
 * acknowledgement. The host supplies the transports; nothing here decides admission.
 */
import { NativeError } from './errors.js';
import { type ChainReader, type RedeemPolicy, type RedeemResult, type RedeemTransport } from './readiness.js';
import { type NativeBridgePayments, type NativeBridgePlugin, type ProofSource } from './wallet.js';
/**
 * Redeem a journalled burn. The journal is written before every send (`submitted`) and with every hash, so a restart resumes with the hashes
 * of earlier sends (`RedemptionUnconfirmed` leaves the entry `submitted`); on success, or when the vault already credited the nonce, the entry
 * becomes `redeemed`. An entry that is already `redeemed` or `settled` is not sent again.
 */
export declare function redeemBurned(plugin: NativeBridgePlugin, payments: NativeBridgePayments, burnId: string, source: ProofSource, chain: ChainReader, transport: RedeemTransport, policy?: RedeemPolicy): Promise<RedeemResult>;
/** The vault's claim transport. `send` must submit from the credited recipient's account: only it can claim. */
export interface ClaimTransport {
    send(tx: {
        to: Uint8Array;
        data: Uint8Array;
    }): Promise<string>;
    receipt(txHash: string): Promise<'success' | 'reverted' | undefined>;
    /** `claimable(recipient)`: the credited, unclaimed balance. */
    claimable(recipient: Uint8Array): Promise<bigint>;
}
export interface ClaimPolicy {
    receiptTimeoutMs: number;
    pollMs: number;
    sleep?: (ms: number) => Promise<void>;
    now?: () => number;
}
export declare const DEFAULT_CLAIM: ClaimPolicy;
/** A claim without a receipt yet. The hash is journalled: calling `claimCredited` again checks it before any new send. */
export declare class ClaimUnconfirmed extends NativeError {
    readonly txHash: string;
    constructor(txHash: string);
}
/**
 * Claim a redeemed burn's own amount to `to` and settle its entry. The attempt is journalled BEFORE the send and the hash right after it; on the
 * fresh path the entry becomes `settled` only when the receipt is a success AND `claimable` fell by exactly the claimed amount. A hash already
 * journalled is checked first and settles on its receipt alone (a restart no longer has the balance before the claim: `claimableBefore` is then
 * absent). An attempt without a hash (a crash between the mark and the hash) is never repeated automatically: another claim could take the same
 * recipient's other credit. The host looks at the account's transactions and then calls `abandonAttempt`.
 */
export declare function claimCredited(payments: NativeBridgePayments, burnId: string, to: Uint8Array, vault: Uint8Array, transport: ClaimTransport, policy?: ClaimPolicy): Promise<{
    amount: bigint;
    txHash: string;
    claimableBefore?: bigint;
    claimableAfter: bigint;
}>;
/**
 * The host's decision that a send is dead: it has established (for example by the sender's nonce having been used by another transaction, or the
 * transaction having been replaced) that `redeemTx` never was or never will be mined, or that a claim attempt without a recorded hash did not go
 * out. Nothing is inferred by the plug-in: it only forgets the attempt so the entry can be retried. Wrongly abandoning a transaction that is still
 * pending can pay twice (a second claim) or send a redeem the vault will refuse, so this is for the host's own evidence only.
 */
export declare function abandonAttempt(payments: NativeBridgePayments, burnId: string, what: {
    redeemTx: string;
} | {
    claim: true;
}): Promise<void>;
