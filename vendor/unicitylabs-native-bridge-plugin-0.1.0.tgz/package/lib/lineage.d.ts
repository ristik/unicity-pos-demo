import { type Deployment } from './deployment.js';
import { type History, type Outcome } from './history.js';
import { type HistoryBounds } from './limits.js';
/** Scanning and hashing one nested byte: the outer mint and every justification descended into. */
export declare const SPLIT_PER_BYTE = 16;
/** One allocation proof: the commitment and the leaf hash, then each node hash. */
export declare const SPLIT_EDGE_BASE = 20000;
export declare const SPLIT_PER_STEP = 1500;
/** One token of a verified lineage, root first. */
export interface LevelInfo {
    tokenId: Uint8Array;
    amount: Uint8Array;
    /** certified leaves the token contributes: its mint and every transfer */
    leaves: number;
}
/**
 * A verified redemption: the root's identity (words 3 to 8 of BRIDGE_COMPOSE_V2), the part's return (releaseTo, nullifier), every
 * leaf in root-to-part order, the part and the depth. `splitGas` is the walk's byte, item and edge charge beyond the protocol 5
 * schedule; the ancestors' leaves are in that schedule's `L` (one leaf proof per leaf of the whole lineage).
 */
export interface LineageOutcome extends Outcome {
    partTokenId: Uint8Array;
    partAmount: Uint8Array;
    depth: number;
    levels: LevelInfo[];
    splitGas: number;
}
/** The return operation: `history` is the redeemed part's projection; its ancestry is read from the exact bytes of its mint reason. */
export declare function verifyLineageReturn(dep: Deployment, history: Uint8Array, lim?: HistoryBounds): Promise<LineageOutcome>;
/**
 * The walk (part first), then the verification (root first). `wantReturn` selects the return relation (the part ends in its return
 * burn: the composition's) or the receipt relation a wallet checks a held part with (every transfer of the part a signature transfer
 * with no data, none required; no releaseTo or nullifier).
 */
export declare function verifyLineage(dep: Deployment, h: History, wantReturn?: boolean): Promise<LineageOutcome>;
/**
 * BRIDGE_COMPOSE_V2's steps a wallet can run offline, in the composition's order, on the exact call it would send: the input's own Cfg
 * (decoded and validated), the envelope, the policy body, the lineage relation, the anchor plan, the anchor openings and the gas
 * estimate (the protocol 5 schedule over every leaf plus the walk's charge: the native charge of a successful call). B1 (certificate
 * signatures and quorum, RSMT membership) is the chain's. `fixture` supplies the deployment's other pins.
 */
export declare function composeOfflineV2(fixture: Deployment, cfgB: Uint8Array, envelope: Uint8Array): Promise<LineageOutcome & {
    gas: number;
}>;
