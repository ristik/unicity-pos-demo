/**
 * Splitting a held bridged token (protocol 6, `protocol/interop.md` "Split lineage"): the SDK's burn-and-mint `TokenSplit`, journaled so
 * that every step survives a crash.
 *
 * The split is deterministic once its plan is fixed: the source token, each output's recipient, amount and salt, and the burn's state
 * mask. `planSplit` checks and prices it and has no side effect; the host journals the plan BEFORE anything is submitted. `runSplit`
 * then rebuilds the same manifest burn and the same child mints from the plan on every call, journals the burn's certification data
 * before submitting it (so a resubmission after a crash is the identical request, never a second burn), journals the certified burned
 * source, then each certified child. A step is never acknowledged before its certified blob is in the journal, and a call on a journaled
 * record continues where the last one stopped. The plug-in submits nothing itself: certification and signing are the host's.
 */
import type { InclusionProof } from '@unicitylabs/state-transition-sdk/lib/api/InclusionProof.js';
import { CertificationData } from '@unicitylabs/state-transition-sdk/lib/api/CertificationData.js';
import type { IUnlockScript } from '@unicitylabs/state-transition-sdk/lib/predicate/IUnlockScript.js';
import type { TransferTransaction } from '@unicitylabs/state-transition-sdk/lib/transaction/TransferTransaction.js';
import { type Gate } from './gas.js';
import { type NativeBridgePlugin } from './wallet.js';
/** One output of a split: its first owner (an encoded predicate, tag 39032), its whole amount and its mint salt (32 bytes). */
export interface SplitOutput {
    recipient: Uint8Array;
    amount: bigint;
    salt: Uint8Array;
}
/** A split as the host journals it. Everything after the plan is a certified result, appended in order. */
export interface SplitRecord {
    splitId: string;
    /** The held token being split (exact bytes). */
    source: Uint8Array;
    outputs: SplitOutput[];
    /** The burn's state mask: with the outputs it fixes the manifest burn. */
    burnStateMask: Uint8Array;
    /** The manifest burn's certification data, journaled before its first submission. */
    burnRequest?: Uint8Array;
    /** The certified burned source token. */
    burned?: Uint8Array;
    /** Each output's certified token, in output order (null until minted). */
    children: (Uint8Array | null)[];
}
export interface SplitJournal {
    put(record: SplitRecord): Promise<void>;
    get(splitId: string): Promise<SplitRecord | null>;
}
export declare class MemorySplitJournal implements SplitJournal {
    private readonly records;
    put(r: SplitRecord): Promise<void>;
    get(id: string): Promise<SplitRecord | null>;
}
/** The host's side of a split: the holder's signature on the burn, and certification by the aggregator. */
export interface SplitHost {
    journal: SplitJournal;
    /** The holder's unlock script for the manifest burn of the source. */
    unlock(burn: TransferTransaction): Promise<IUnlockScript>;
    /** Submit one certification request and return its inclusion proof. Submitting the same request again must be harmless. */
    certify(request: CertificationData, what: string): Promise<InclusionProof>;
}
/** What `planSplit` returns: the record to journal before `runSplit`, and each output's best-case redemption estimate. */
export interface SplitPlan {
    record: SplitRecord;
    estimates: Gate[];
}
/**
 * Check and price a split before anything is burned. The held token must verify as a receipt (a whole token or a part); the outputs must
 * be at least two, each positive, summing to exactly the held amount, with distinct 32-byte salts. Each output's redemption is priced
 * from the lineage it will have (the held lineage, the manifest burn, the output's mint and its own return burn) and the walk's charge of
 * the new edge: the full estimate interop.md asks for before the manifest burn ("Split lineage": the whole lineage and the walk, not the
 * output's own leaves only), computed before the burn exists and therefore a lower bound, as `preflightBurn`'s is for a whole token. An
 * output that could never be redeemed under the resource policy (`ErrInputTooLarge`) refuses the whole split. The estimate is never a gas
 * ceiling (owner section 36).
 */
export declare function planSplit(plugin: NativeBridgePlugin, splitId: string, tokenBytes: Uint8Array, outputs: SplitOutput[], burnStateMask?: Uint8Array): Promise<SplitPlan>;
/**
 * Run (or resume) a planned split: the manifest burn of the source, then each output's mint, every certified result journaled before the
 * next step. Each minted output is verified as a receipt of the source's deployment (the issuance policy fails closed) before it is
 * journaled. Returns the certified output tokens in output order.
 */
export declare function runSplit(plugin: NativeBridgePlugin, record: SplitRecord, host: SplitHost): Promise<Uint8Array[]>;
