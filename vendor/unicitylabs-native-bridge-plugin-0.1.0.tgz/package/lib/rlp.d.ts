/** A decoded RLP item: a byte string or a list, with its raw encoding. */
export type Rlp = {
    kind: 'bytes';
    data: Uint8Array;
    raw: Uint8Array;
} | {
    kind: 'list';
    items: Rlp[];
    raw: Uint8Array;
};
/** Decode exactly one canonical item spanning all of `b`. */
export declare function decode(b: Uint8Array): Rlp;
export declare const bytesOf: (r: Rlp) => Uint8Array;
export declare const listOf: (r: Rlp) => Rlp[];
/** A canonical unsigned integer of at most 8 bytes. */
export declare function u64Of(r: Rlp): bigint;
export declare function encodeBytes(s: Uint8Array): Uint8Array;
export declare function encodeList(items: Uint8Array[]): Uint8Array;
export declare function encodeU64(v: bigint): Uint8Array;
