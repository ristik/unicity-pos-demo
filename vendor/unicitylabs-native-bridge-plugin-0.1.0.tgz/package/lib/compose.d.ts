export declare const COMPOSE_ADDRESS: "0x0000000000000000000000000000000000000105";
/** `bytes32("UNICITY_BRIDGE_COMPOSE_V1")`, left aligned. */
export declare const COMPOSE_MARKER: Uint8Array;
export declare const COMPOSE_OUTPUT_BYTES = 384;
/** Status code i is `COMPOSE_STATUS[i - 1]`; code 0 is success. Append-only, pinned against the corpus. */
export declare const COMPOSE_STATUS: readonly string[];
/** The reason name of a status code: `ok` for 0, `undefined` for an unknown code. */
export declare const composeStatusName: (code: number) => string | undefined;
/** `abi.encode(uint8 op, bytes cfg, bytes envelope)`: the canonical native input (its length is the schedule's B). */
export declare function composeInput(op: number, cfg: Uint8Array, envelope: Uint8Array): Uint8Array;
/** The status word of a 384-byte output, or `undefined` when the bytes are not an output (wrong length or marker). */
export declare function composeOutputStatus(out: Uint8Array): number | undefined;
/** `bytes32("UNICITY_BRIDGE_COMPOSE_V2")`, left aligned. */
export declare const COMPOSE_MARKER_V2: Uint8Array;
/** Fifteen words: V1's twelve (the root's identity), then partTokenId, partAmount and splitDepth. */
export declare const COMPOSE_OUTPUT_BYTES_V2: number;
/** The V1 table with the split reasons appended, then the two certificate-codec reasons an embedded ancestor proof can raise. */
export declare const COMPOSE_STATUS_V2: readonly string[];
export declare const composeStatusNameV2: (code: number) => string | undefined;
/** A decoded successful V2 output (amounts minimal big-endian, as the relation returns them). */
export interface ComposeResultV2 {
    cfg: Uint8Array;
    nonce: bigint;
    amount: Uint8Array;
    tokenId: Uint8Array;
    salt: Uint8Array;
    firstPredicateHash: Uint8Array;
    lockDigest: Uint8Array;
    releaseTo: Uint8Array;
    nullifier: Uint8Array;
    leafCount: bigint;
    partTokenId: Uint8Array;
    partAmount: Uint8Array;
    splitDepth: bigint;
}
/**
 * Strictly decode a V2 output (bft-core `DecodeComposeOutputV2`): the marker, a status in the table, every field zero on a failure,
 * and on success words that fit (a 64-bit nonce and depth, a 20-byte releaseTo). `undefined` for anything else.
 */
export declare function decodeComposeOutputV2(out: Uint8Array): {
    status: number;
    result?: ComposeResultV2;
} | undefined;
