import { type Item } from './scan.js';
/** Minimal positive big-endian bytes (the CBOR amount of a sum step). */
export declare const amountBytes: (v: bigint) => Uint8Array;
export declare const beToBigint: (b: Uint8Array) => bigint;
/** `SHA-256(0x10 || key || data || u256(value))`, or null outside the amount domain. */
export declare function sumLeafHash(key: Uint8Array, data: Uint8Array, value: bigint): Uint8Array | null;
/** `SHA-256(0x11 || depth || hL || u256(sL) || hR || u256(sR))` and the checked 256-bit sum, or null. */
export declare function sumNodeHash(depth: number, hl: Uint8Array, sl: bigint, hr: Uint8Array, sr: bigint): {
    hash: Uint8Array;
    sum: bigint;
} | null;
/** One sibling entry of a leaf-to-root path: the parent's bifurcation depth, the sibling subtree hash and its positive sum. */
export interface SumStep {
    depth: number;
    hash: Uint8Array;
    sum: bigint;
}
/** The exact CBOR `[[depth, b(hash), b(sum)], ...]`. */
export declare const sumProofBytes: (p: readonly SumStep[]) => Uint8Array;
/** Strictly decode an allocation proof item (bft-core `decodeSumProof`). */
export declare function decodeSumProofItem(it: Item): SumStep[];
/**
 * Reconstruct the root from the leaf upward; the reconstructed root sum iff the root hash equals `root`. The caller compares that
 * sum with the authenticated source amount: the root hash alone does not conserve value.
 */
export declare function verifySumProof(p: readonly SumStep[], key: Uint8Array, data: Uint8Array, value: bigint, root: Uint8Array): bigint | null;
/** The manifest `tag(39046,[b(root)])`: the bridge admits one asset, so exactly one root. */
export declare const splitManifestBytes: (root: Uint8Array) => Uint8Array;
/** Strictly decode a burn transfer's data as a single-root manifest; returns the root. */
export declare function decodeSplitManifest(b: Uint8Array): Uint8Array;
/**
 * `SHA-256(CBOR([b("UNICITY_SPLIT_OUTPUT"), b(sourceId), network, b(encodedRecipient), b(salt), b(childId), b(type),
 * b(exactPaymentBytes)]))`: the child mint without its justification.
 */
export declare const splitOutputCommitment: (sourceId: Uint8Array, network: number, recipient: Uint8Array, salt: Uint8Array, childId: Uint8Array, ty: Uint8Array, data: Uint8Array) => Uint8Array;
/**
 * The decoded split mint reason `tag(39044,[token,[proof]])`: the exact burned source token bytes (an inline item, never re-encoded),
 * its one allocation proof (one asset) and the item count of the justification's own scan, which the composition charges.
 */
export interface SplitJustification {
    token: Uint8Array;
    proof: SumStep[];
    items: number;
}
export declare const splitJustificationBytes: (token: Uint8Array, proof: readonly SumStep[]) => Uint8Array;
/** The tag number of a justification without scanning it: the first head must be a tag. */
export declare function justificationTag(j: Uint8Array | null): bigint | null;
/** Strictly decode a split mint reason. The burned token is decoded strictly by the caller. */
export declare function decodeSplitJustification(j: Uint8Array): SplitJustification;
