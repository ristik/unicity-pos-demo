import type { Deployment } from './deployment.js';
import { type Item } from './scan.js';
import type { TrustInput } from './trust.js';
export interface LockProof {
    cfg: Uint8Array;
    trustBaseId: Uint8Array;
    pdr: Uint8Array;
    uc: Uint8Array;
    header: Uint8Array;
    accountNodes: Uint8Array[];
    storageNodes: Uint8Array[];
}
export interface Justification {
    chainId: bigint;
    vault: Uint8Array;
    zero: Uint8Array;
    nonce: bigint;
    proof: LockProof;
}
/** Parse one scanned LockProof (bft-core `decodeLockProof`, in its order): exact arity, literal version and every component's
 * bound before any crypto. A shape failure is ErrLockProofShape, a bound ErrLockProofTooLarge. */
export declare function parseLockProof(it: Item): LockProof;
export declare function encodeLockProof(p: LockProof): Uint8Array;
export declare function encodeJustification(chainId: bigint, vault: Uint8Array, zero: Uint8Array, nonce: bigint, lockProof: Uint8Array): Uint8Array;
/** Parse J without a deployment, to find the one it names: bft-core `ParseJustification` with its configuration comparisons
 * (chain, vault, zero address, the proof's cfg) left out. Outside oracle parity: for a J that names no deployment and also has a
 * malformed lock proof, this reports the proof's error where Go, parsing against one fixed cfg, would stop earlier at ErrMintJustif;
 * the registry lookup it serves has no Go counterpart. */
export declare function parseJustification(j: Uint8Array): Justification;
/** Parse J for a deployment's configuration (bft-core `ParseJustification`, in its order): the size bound, then J's own scan and
 * fields (all ErrMintJustif), then the embedded lock proof's shape and bounds, then its cfg, then the exact re-encoding. */
export declare function parseJustificationFor(cfg: Deployment['cfg'], cfgHash: Uint8Array, j: Uint8Array): Justification;
export declare function configHashOfPdr(pdr: Uint8Array): Uint8Array;
export interface VerifiedLock {
    trustBaseId: Uint8Array;
    evmBlockNumber: bigint;
    evmRootRound: bigint;
}
/** Verify a lock proof against the pinned deployment and trust input, in the specified order; a refusal carries the oracle's reason. */
export declare function verifyLockProof(dep: Deployment, trust: TrustInput, j: Justification, expectedDigest: Uint8Array): Promise<VerifiedLock>;
