export declare const H: (b: Uint8Array) => Uint8Array;
export declare const keccak256: (...parts: Uint8Array[]) => Uint8Array;
export declare const bs: (b: Uint8Array) => Uint8Array;
export declare const u: (n: bigint | number) => Uint8Array;
export declare const arr: (...items: Uint8Array[]) => Uint8Array;
/** The one-byte native encoding of the empty shard prefix (not the empty bstr). */
export declare const EMPTY_PREFIX_SHARD: Uint8Array<ArrayBuffer>;
/** The immutable bridge configuration. Integers are bigint; widths follow the Go oracle. */
export interface Cfg {
    network: number;
    rootGenesis: Uint8Array;
    chainId: bigint;
    executionGenesis: Uint8Array;
    evmPartition: number;
    evmShard: Uint8Array;
    vault: Uint8Array;
    zeroAddress: Uint8Array;
    ty: Uint8Array;
    aid: Uint8Array;
    semanticProfileHash: Uint8Array;
    tokenVerifierAddress: Uint8Array;
    tokenVerifierCodeHash: Uint8Array;
    b1ProfileHash: Uint8Array;
    aggregatorPolicyHash: Uint8Array;
}
export declare function cfgBytes(c: Cfg): Uint8Array;
export declare const cfgHash: (c: Cfg) => Uint8Array;
export declare function decodeCfg(b: Uint8Array): Cfg;
/** `D = networkDecimal:rootGenesisHex:executionGenesisHex:chainIdDecimal:zeroAddressHex`. */
export declare function identityDomain(network: number, rootGenesis: Uint8Array, executionGenesis: Uint8Array, chainId: bigint): string;
/** `ty = SHA256(UTF8("unicity-bridge:unicity-native:" + D))`; the vault is deliberately not part of it. */
export declare const deriveType: (n: number, rg: Uint8Array, eg: Uint8Array, c: bigint) => Uint8Array;
/** `aid = SHA256(UTF8("unicity-bridge-coin:unicity-native:" + D))`. */
export declare const deriveAsset: (n: number, rg: Uint8Array, eg: Uint8Array, c: bigint) => Uint8Array;
/** The common wallet value envelope `tag(39050,[1,[[b(aid),b(amount)]],null])`. */
export declare const valueEnvelope: (aid: Uint8Array, amount: Uint8Array) => Uint8Array;
/**
 * The sole admitted aggregator policy body `C("UNICITY_BR_AGG_PARTITION", 2, partition)`: it names the aggregation
 * partition only. Every anchor's UC authenticates its own historical shard and shard configuration hash; there is
 * no depth, shard list or allow-list in the policy.
 */
export interface Policy {
    partition: number;
}
export declare const makePolicy: (partition: number) => Policy;
export declare const policyBytes: (p: Policy) => Uint8Array;
export declare const policyHash: (p: Policy) => Uint8Array;
export declare function decodePolicy(b: Uint8Array): Policy;
/**
 * The depth of a native shard ID: the bits before its terminator, `8*len - trailingZeroBits(lastByte) - 1`.
 * The ID is 1..33 bytes with a nonzero last byte (the terminator is that byte's lowest set bit).
 */
export declare function shardDepth(shard: Uint8Array): number;
/** Whether the first `shardDepth(shard)` bits of `sid` equal the prefix bits of the native shard ID `shard`. */
export declare function shardCovers(shard: Uint8Array, sid: Uint8Array): boolean;
export declare const deriveSalt: (cfg: Uint8Array, n: bigint) => Uint8Array;
export declare const deriveTokenId: (salt: Uint8Array, network: number) => Uint8Array;
export declare const lockRecord: (zero: Uint8Array, ty: Uint8Array, aid: Uint8Array, amount: Uint8Array, id: Uint8Array, rcpt: Uint8Array) => Uint8Array;
/** `d = H(C("UNICITY_BR_LOCK", b(cfg), n, K))`; binds cfg, nonce, amount, id, recipient, not J. */
export declare const lockDigest: (cfg: Uint8Array, n: bigint, k: Uint8Array) => Uint8Array;
export declare function returnReason(chainId: bigint, vault: Uint8Array, zero: Uint8Array, ty: Uint8Array, aid: Uint8Array, recipient: Uint8Array, amount: Uint8Array): Uint8Array;
export declare const burnId: (sid: Uint8Array, txHash: Uint8Array) => Uint8Array;
export declare const nullifier: (cfg: Uint8Array, btid: Uint8Array) => Uint8Array;
/** The certified leaf value `v = H(C(b(txHash32), t))`. */
export declare const leafValue: (txHash: Uint8Array, t: bigint) => Uint8Array;
export declare const SLOT_LOCK_DIGEST = 5n;
export declare const SLOT_REDEEMED_AMOUNT = 6n;
export declare const SLOT_CLAIMABLE = 7n;
export declare const SLOT_LOCKED_AMOUNT = 8n;
export declare const SLOT_SPENT_PART = 9n;
export declare function word(n: bigint): Uint8Array;
export declare function mappingSlot(key: Uint8Array, base: bigint): Uint8Array;
export declare const lockDigestSlot: (n: bigint) => Uint8Array;
export declare const redeemedAmountSlot: (n: bigint) => Uint8Array;
export declare const lockedAmountSlot: (n: bigint) => Uint8Array;
/** `spentPart[nonce][partId]`: the inner mapping's slot is `keccak256(partId . keccak256(nonce . 9))`. */
export declare const spentPartSlot: (n: bigint, partId: Uint8Array) => Uint8Array;
export declare const claimableSlot: (a: Uint8Array) => Uint8Array;
export declare const storageTrieKey: (slot: Uint8Array) => Uint8Array;
export declare const accountTrieKey: (a: Uint8Array) => Uint8Array;
