/**
 * Trust input: the network's Unicity Trust Base history, installed from a release bundle (tag 39015: the genesis entry and every later entry,
 * each witnessed by its predecessor's committee) and pinned by the EntryID of its genesis entry.
 *
 * `trustBaseId` is that genesis EntryID: a lock proof and every manifest entry name it, and a history is the same trust input exactly when it
 * has the same network and genesis. Each certificate is verified by the SDK against the committee of its own epoch (weighted quorum, the upstream
 * seal rule: each signature counts alone, an unknown signer or a signature that is not an exact recoverable one of its member counts zero;
 * the epoch's round interval); a certificate of an epoch newer than the latest held entry is `ErrNoEntryForEpoch`, retryable once
 * the history holds the newer entries (fetched by the wallet, never by the plug-in).
 */
import { NetworkId } from '@unicitylabs/state-transition-sdk/lib/api/NetworkId.js';
import { TrustBaseHistory } from '@unicitylabs/state-transition-sdk/lib/api/bft/trustbase/TrustBaseHistory.js';
import type { UnicityCertificate } from '@unicitylabs/state-transition-sdk/lib/api/bft/UnicityCertificate.js';
import type { VerificationResult } from '@unicitylabs/state-transition-sdk/lib/verification/VerificationResult.js';
import { type NativeReason } from './errors.js';
export declare class TrustInput {
    /** The held history; the wallet appends newer entries to it (each verified from its predecessor), never replaces held ones. */
    readonly history: TrustBaseHistory;
    /** The genesis EntryID: the value a lock proof's `trustBaseId` and the manifest pin must equal. */
    readonly id: Uint8Array;
    private constructor();
    /**
     * Install a release bundle: complete (no continuation), contiguous from its genesis, every link witnessed by the predecessor's quorum, and
     * its genesis EntryID equal to the pin.
     */
    static fromBundle(bundle: Uint8Array, pin: Uint8Array): Promise<TrustInput>;
    get network(): NetworkId;
    /** The history to verify against. */
    authority(): Promise<TrustBaseHistory>;
    /**
     * Select the committee of the certificate's seal epoch (protocol/trust-base.md steps 1-4, before any structure, root or signature check, as
     * the oracle orders them): another network `ErrSealNetwork`, an epoch newer than the latest held `ErrNoEntryForEpoch`, before the genesis or
     * outside the epoch's round interval `ErrSealEpoch`.
     */
    selectEpoch(uc: UnicityCertificate): void;
    /**
     * Verify an embedded certificate with the SDK's certificate verifier for its own partition (the EVM partition pin is the caller's): the seal
     * epoch's committee first ({@link selectEpoch}), then native format and structure, the tree path to the seal hash, and the seal under that
     * committee (the upstream seal rule).
     */
    verifyEmbeddedUc(uc: UnicityCertificate): Promise<void>;
}
/**
 * The sentinel of a failed certificate verification, from its verdict class and failing rule: an epoch newer than the latest held entry is
 * retryable (`ErrNoEntryForEpoch`); malformed material and native structure failures are `ErrCertStructure`; the seal's epoch and interval
 * (`ErrSealEpoch`), tree root and quorum keep their own names. Null when no certificate rule failed.
 */
export declare function certificateFailure(r: VerificationResult<unknown>): NativeReason | null;
