import { type Config } from './config.js';
import { type Header } from './header.js';
import { type MintTx } from './token.js';
import { type TrustInput } from './trust.js';
/** Profile bounds of the deposit evidence (`profile.json` `limits`), checked before any cryptography. */
export declare const LIMITS: {
    readonly justificationBytes: 65536;
    readonly ucBytes: 16384;
    readonly headerBytes: 2048;
    readonly receiptNodes: 65;
    readonly receiptBranchNodeBytes: 1024;
    readonly receiptLeafNodeBytes: 49152;
};
export declare const FIRST_OWNER_BYTES = 42;
export declare const TAG_DEPOSIT_SECRET: Uint8Array<ArrayBufferLike>;
export declare const TAG_ARCHIVE_GENESIS: Uint8Array<ArrayBufferLike>;
export declare const TAG_ARCHIVE_STEP: Uint8Array<ArrayBufferLike>;
export declare const TOPIC: {
    readonly Deposited: Uint8Array<ArrayBufferLike>;
    readonly Paid: Uint8Array<ArrayBufferLike>;
    readonly SegmentSealed: Uint8Array<ArrayBufferLike>;
};
/** r = HMAC-SHA256(key = k_w, msg = C(b("UNICITY_NB2_DEPOSIT_INTENT"), b(D), i)). */
export declare const depositIntentSecret: (kw: Uint8Array, d: Uint8Array, i: bigint) => Uint8Array;
/** rho = H_E(DEPOSIT_SECRET || D || r). */
export declare const rhoOf: (d: Uint8Array, r: Uint8Array) => Uint8Array;
/** salt_n = H_U(C(b("UNICITY_NB2_DEPOSIT_SALT"), b(D), n, b(r))). */
export declare const depositSalt: (d: Uint8Array, n: bigint, r: Uint8Array) => Uint8Array;
/** The 9-byte head of the 42-byte first owner tag(39032, [1, b(0x01), b(key33)]). */
export declare const FIRST_OWNER_PREFIX: Uint8Array<ArrayBuffer>;
export declare const firstOwnerOf: (key33: Uint8Array) => Uint8Array;
/** DepositProof = [1, b(evmUC), b(headerRLP), txIndex, logIndex, [b(receiptNodeRLP), ...]], also the seal receipt container. */
export interface DepositProof {
    uc: Uint8Array;
    header: Uint8Array;
    txIndex: bigint;
    logIndex: bigint;
    nodes: Uint8Array[];
}
export declare const encodeDepositProof: (p: DepositProof) => Uint8Array;
/** J = tag(39051, [1, b(D), n, b(r), DepositProof]). */
export interface ReceiptBacking {
    d: Uint8Array;
    n: bigint;
    r: Uint8Array;
    proof: DepositProof;
}
export declare const encodeReceiptBacking: (j: ReceiptBacking) => Uint8Array;
export declare function decodeReceiptBacking(b: Uint8Array): ReceiptBacking;
/** A standalone DepositProof container (a seal receipt). */
export declare function decodeDepositProof(b: Uint8Array): DepositProof;
export interface ReceiptLog {
    address: Uint8Array;
    topics: Uint8Array[];
    data: Uint8Array;
    header: Header;
}
/**
 * Section 6.2 steps 2 to 5 up to the emitter: the EVM UC (`DepositUC`), the header bound to its input record (`DepositHeader`), the
 * receipt path keyed by RLP(txIndex) (`ReceiptPath`), type and status, `logs[logIndex]` (`LogIndex`) and its address (`LogEmitter`).
 * The caller checks its event's topics and data.
 */
export declare function verifyReceiptLog(c: Config, t: TrustInput, p: DepositProof): Promise<ReceiptLog>;
/** The 224-byte data of Deposited(n, D, v, rho, firstOwner). */
export declare function depositedData(d: Uint8Array, v: bigint, rho: Uint8Array, firstOwner: Uint8Array): Uint8Array;
/**
 * Section 6.2 steps 1 to 7 for a decoded J: the domain (`MintDomain`), the receipt log, its topics and data, the secret opening. It
 * returns the deposited amount and the first owner. The wallet runs it before minting; the verifier runs it inside the root mint check.
 */
export declare function verifyDepositEvidence(c: Config, domain: Uint8Array, t: TrustInput, j: ReceiptBacking): Promise<{
    v: bigint;
    firstOwner: Uint8Array;
    blockNumber: bigint;
}>;
/** Section 6.2 for a root mint whose reason is J, in order: J and the deposited amount v. */
export declare function verifyRootMint(c: Config, domain: Uint8Array, t: TrustInput, m: MintTx): Promise<{
    j: ReceiptBacking;
    v: bigint;
}>;
