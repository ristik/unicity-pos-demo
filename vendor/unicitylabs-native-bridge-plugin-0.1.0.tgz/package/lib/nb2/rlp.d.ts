export declare const MAX_RLP_DEPTH = 16;
export interface RlpItem {
    list: boolean;
    str: Uint8Array;
    kids: RlpItem[];
    raw: Uint8Array;
}
export declare class RlpError extends Error {
}
/** Exactly one item spanning all of `b`; throws {@link RlpError}. */
export declare function rlpDecode(b: Uint8Array): RlpItem;
/** A canonical RLP integer string: no leading zero byte, at most `max` bytes (the empty string is zero). */
export declare function rlpUint(it: RlpItem, max?: number): bigint | null;
export declare function rlpBytes(b: Uint8Array): Uint8Array;
export declare function rlpList(items: Uint8Array[]): Uint8Array;
/** The minimal big-endian bytes of an unsigned integer (empty for zero). */
export declare function uintBytes(v: bigint): Uint8Array;
export declare const rlpUintEnc: (v: bigint | number) => Uint8Array;
/** RLP(i) for an unsigned index: the receipt-trie key. */
export declare const rlpIndexKey: (i: bigint | number) => Uint8Array;
