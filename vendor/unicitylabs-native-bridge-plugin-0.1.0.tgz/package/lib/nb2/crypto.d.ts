/** H_U: raw SHA-256, the Unicity hash. */
export declare const HU: (...parts: Uint8Array[]) => Uint8Array;
/** H_E: EVM keccak256. */
export declare const HE: (...parts: Uint8Array[]) => Uint8Array;
/** I(h) = 0x0000 || h. */
export declare const imprint: (h: Uint8Array) => Uint8Array;
export declare const SECP_N: bigint;
/** H(C(b(sourceHash32), b(txHash32))). */
export declare const unlockMessage: (sourceHash: Uint8Array, txHash: Uint8Array) => Uint8Array;
/**
 * The SDK token-unlock rule, unchanged from protocol 7: exactly 65 bytes r||s||id (`UnlockLength`), 1 <= r < n and 1 <= s <= n/2
 * (`UnlockScalars`), id in 0..1 (`UnlockRecovery`; IDs 2 and 3 are refused for NB2), the key recovered with the supplied id equal to the source key (`UnlockKey`), then
 * the compact verification (defense in depth, reported as `UnlockKey`). Nothing is normalised.
 */
export declare function verifyUnlock(key33: Uint8Array, sourceHash: Uint8Array, txHash: Uint8Array, unlock: Uint8Array): void;
/** The unlock rule over a given 32-byte message (the vectors' `primitives.unlockRecovery` form). */
export declare function verifyUnlockDigest(key33: Uint8Array, digest: Uint8Array, unlock: Uint8Array): void;
/** r||s||id over the unlock message, low-s, with the signer's recovery ID. */
export declare function signUnlock(priv: Uint8Array, sourceHash: Uint8Array, txHash: Uint8Array): Uint8Array;
/** H(C(b("I_AM_UNIVERSAL_MINTER_FOR_"), b(id))). */
export declare const minterScalar: (id: Uint8Array) => Uint8Array;
/** A minter scalar is admitted only as a valid secp256k1 secret, 1 <= k < n, never reduced modulo n. */
export declare function minterScalarValid(k: Uint8Array): boolean;
/** The universal minter's compressed public key for a token ID (an invalid scalar: no such ID is known, about 2^-128 per ID). */
export declare function minterKey(id: Uint8Array): Uint8Array;
/** A compressed secp256k1 key on the curve (`Predicate` otherwise). */
export declare function parseKey(b: Uint8Array): Uint8Array;
