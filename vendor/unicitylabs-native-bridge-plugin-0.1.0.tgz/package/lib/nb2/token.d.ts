import { type Deadline } from './cbor.js';
export declare const TX_VERSION = 2n;
export declare const CERT_VERSION = 2n;
export declare const INCLUSION_VERSION = 1n;
export declare const VALUE_VERSION = 1n;
export declare const ENGINE_BUILTIN = 1n;
export declare const PRED_SIGNATURE = 1n;
export declare const PRED_BURN = 2n;
export interface Predicate {
    type: bigint;
    params: Uint8Array;
}
export declare const encodePredicate: (p: Predicate) => Uint8Array;
export declare const signaturePredicate: (key33: Uint8Array) => Predicate;
export declare const burnPredicate: (reasonHash: Uint8Array) => Predicate;
export interface MintTx {
    network: number;
    recipient: Predicate;
    salt: Uint8Array;
    type: Uint8Array;
    justification: Uint8Array | null;
    data: Uint8Array | null;
    deadline: Deadline;
}
export declare const encodeMint: (m: MintTx) => Uint8Array;
export interface TransferTx {
    recipient: Predicate;
    mask: Uint8Array;
    data: Uint8Array | null;
    deadline: Deadline;
}
export declare const encodeTransfer: (t: TransferTx) => Uint8Array;
export interface Certification {
    source: Predicate;
    sourceHash: Uint8Array;
    txHash: Uint8Array;
    deadline: Deadline;
    unlock: Uint8Array;
}
export declare const encodeCertification: (c: Certification) => Uint8Array;
export interface InclusionProof {
    cd: Certification;
    t: bigint;
    bitmap: Uint8Array;
    siblings: Uint8Array[];
    uc: Uint8Array;
}
export declare const encodeProof: (p: InclusionProof) => Uint8Array;
export interface LineageLevel {
    allocation: Uint8Array;
    mint: MintTx;
    mintProof: InclusionProof;
    transfers: TransferTx[];
    proofs: InclusionProof[];
    /** The exact transaction bytes, as decoded. */
    mintRaw: Uint8Array;
    transfersRaw: Uint8Array[];
}
export interface Token extends LineageLevel {
    ancestors: LineageLevel[];
}
export declare const lineageOf: (token: Token) => LineageLevel[];
export declare const MAX_TRANSFER_PAIR = 40960;
export declare const MAX_ROOT_MINT = 66048;
export declare const MAX_CHILD_MINT = 512;
export declare const MAX_ALLOCATION = 20480;
export declare function encodeLevel(level: LineageLevel): Uint8Array;
export declare function frameLevel(allocation: Uint8Array, mint: Uint8Array, proof: Uint8Array, pairs: Uint8Array[]): Uint8Array;
export declare function frameLineage(levels: Uint8Array[]): Uint8Array;
export declare const encodeToken: (token: Token) => Uint8Array;
/** Import exact signed bytes. Counts drive reads only after checking remaining bytes. */
export declare function decodeToken(input: Uint8Array): Token;
/** Decode the exact signed transfer and its separate certification request. */
export declare const parseTransfer: (raw: Uint8Array) => TransferTx;
export declare const parseCertification: (raw: Uint8Array) => Certification;
/** sid = H(C(Psource, b(sourceHash32))). */
export declare const stateId: (source: Predicate, sourceHash: Uint8Array) => Uint8Array;
/** The output state H(C(b(I(sourceHash)), b(mask))); a mint's mask is the token ID. */
export declare const resultState: (sourceHash: Uint8Array, mask: Uint8Array) => Uint8Array;
/** v = H(C(b(txHash32), t)). */
export declare const leafValue: (txHash: Uint8Array, t: bigint) => Uint8Array;
/** id = H(C(b(salt), network)). */
export declare const tokenIdOf: (salt: Uint8Array, network: number) => Uint8Array;
/** h0 = H(C(b(id), b(H("TOKENID")))). */
export declare const mintSourceHash: (id: Uint8Array) => Uint8Array;
/** tag(39050, [1, [[b(aid32), b(v)]], null]). */
export declare const valueData: (aid: Uint8Array, v: bigint | Uint8Array) => Uint8Array;
