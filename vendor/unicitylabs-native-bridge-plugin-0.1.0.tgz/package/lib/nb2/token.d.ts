import { type Deadline, type Item } from './cbor.js';
export declare const TX_VERSION = 2n;
export declare const CERT_VERSION = 2n;
export declare const TOKEN_VERSION = 2n;
export declare const INCLUSION_VERSION = 1n;
export declare const VALUE_VERSION = 1n;
export declare const ENGINE_BUILTIN = 1n;
export declare const PRED_SIGNATURE = 1n;
export declare const PRED_BURN = 2n;
export interface Predicate {
    type: bigint;
    params: Uint8Array;
}
export declare const encodePredicate: (p: Predicate) => Uint8Array;
export declare const signaturePredicate: (key33: Uint8Array) => Predicate;
export declare const burnPredicate: (reasonHash: Uint8Array) => Predicate;
export interface MintTx {
    network: number;
    recipient: Predicate;
    salt: Uint8Array;
    type: Uint8Array;
    justification: Uint8Array | null;
    data: Uint8Array | null;
    deadline: Deadline;
}
export declare const encodeMint: (m: MintTx) => Uint8Array;
export interface TransferTx {
    recipient: Predicate;
    mask: Uint8Array;
    data: Uint8Array | null;
    deadline: Deadline;
}
export declare const encodeTransfer: (t: TransferTx) => Uint8Array;
export interface Certification {
    source: Predicate;
    sourceHash: Uint8Array;
    txHash: Uint8Array;
    deadline: Deadline;
    unlock: Uint8Array;
}
export declare const encodeCertification: (c: Certification) => Uint8Array;
export interface InclusionProof {
    cd: Certification;
    t: bigint;
    bitmap: Uint8Array;
    siblings: Uint8Array[];
    uc: Uint8Array;
}
export declare const encodeProof: (p: InclusionProof) => Uint8Array;
export interface Token {
    mint: MintTx;
    mintProof: InclusionProof;
    transfers: TransferTx[];
    proofs: InclusionProof[];
    /** The exact transaction bytes, as decoded. */
    mintRaw: Uint8Array;
    transfersRaw: Uint8Array[];
}
export declare function encodeToken(t: Token): Uint8Array;
/** Strictly decode a token from its exact bytes. */
export declare function decodeToken(b: Uint8Array): Token;
export declare function decodeTokenItem(it: Item, b: Uint8Array): Token;
/** sid = H(C(Psource, b(sourceHash32))). */
export declare const stateId: (source: Predicate, sourceHash: Uint8Array) => Uint8Array;
/** The output state H(C(b(I(sourceHash)), b(mask))); a mint's mask is the token ID. */
export declare const resultState: (sourceHash: Uint8Array, mask: Uint8Array) => Uint8Array;
/** v = H(C(b(txHash32), t)). */
export declare const leafValue: (txHash: Uint8Array, t: bigint) => Uint8Array;
/** id = H(C(b(salt), network)). */
export declare const tokenIdOf: (salt: Uint8Array, network: number) => Uint8Array;
/** h0 = H(C(b(id), b(H("TOKENID")))). */
export declare const mintSourceHash: (id: Uint8Array) => Uint8Array;
/** tag(39050, [1, [[b(aid32), b(v)]], null]). */
export declare const valueData: (aid: Uint8Array, v: bigint | Uint8Array) => Uint8Array;
