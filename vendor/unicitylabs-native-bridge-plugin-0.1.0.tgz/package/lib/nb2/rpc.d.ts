import { type RawLog, type VaultState } from './abi.js';
import { type DepositProof } from './deposit.js';
import { WalletError } from './errors.js';
import { type Header } from './header.js';
import type { Config } from './config.js';
import { u256 } from './cbor.js';
import type { RecoveryEvent, RecoveryReceiptSource } from './recovery.js';
import { type TrustInput } from './trust.js';
export declare const LOG_BLOCK_RANGE = 10000n;
/** A JSON-RPC transport: one method call. */
export interface JsonRpc {
    call<T = unknown>(method: string, params: unknown[]): Promise<T>;
}
/** A JSON-RPC error object, or a gateway refusal (HTTP status and its error text). */
export declare class RpcError extends Error {
    readonly status: number;
    readonly code: number;
    readonly data?: unknown | undefined;
    constructor(status: number, code: number, message: string, data?: unknown | undefined);
}
/** Readers exhausted for a component of an identified transaction's certificate. */
export declare class ProofUnavailable extends Error {
    readonly component: string;
    readonly pruned: boolean;
    constructor(component: string, pruned: boolean);
}
/** An `eth_sendRawTransaction` answered with HTTP 503 ("broadcast may be partial"): the transaction may still be included. */
export declare class AmbiguousBroadcast extends Error {
    readonly txHash: Uint8Array;
    constructor(txHash: Uint8Array, detail: string);
}
export interface HttpRpcOptions {
    fetch?: typeof fetch;
    /** Retries of a 429 or busy 503 (not of a send); default 10. */
    retries?: number;
    sleep?: (ms: number) => Promise<void>;
    timeoutMs?: number;
}
/** The gateway client. */
export declare class HttpJsonRpc implements JsonRpc {
    private readonly url;
    private readonly opts;
    private id;
    constructor(url: string, opts?: HttpRpcOptions);
    call<T>(method: string, params: unknown[]): Promise<T>;
    private once;
}
export declare const qty: (v: bigint | number) => string;
export declare function bytesOf(s: unknown, what: string): Uint8Array;
export declare function qtyOf(s: unknown, what: string): bigint;
/** The header fields of an `eth_getBlockBy*` answer, as the 20-field Cancun header. */
export declare function headerOfJson(j: Record<string, unknown>): Header;
export interface ReceiptJson {
    type?: string;
    status: string;
    cumulativeGasUsed: string;
    logsBloom: string;
    logs: {
        address: string;
        topics: string[];
        data: string;
        logIndex?: string;
        blockNumber?: string;
        blockHash?: string;
        transactionHash?: string;
    }[];
    blockHash: string;
    blockNumber: string;
    transactionIndex: string;
    transactionHash: string;
    gasUsed?: string;
    effectiveGasPrice?: string;
}
/** The consensus encoding of a receipt: a legacy RLP list, or type || RLP(...) for types 1..3. */
export declare function encodeReceiptJson(r: ReceiptJson): Uint8Array;
export declare function rawLogOf(l: Record<string, unknown>): RawLog;
/** A built receipt proof and the facts it was built from. */
export interface ReceiptProof {
    proof: DepositProof;
    encoded: Uint8Array;
    blockNumber: bigint;
    blockHash: Uint8Array;
    log: RawLog;
    receiptLogIndex: number;
}
/** The typed RPC reads the wallet uses. */
export declare class EvmReader {
    readonly rpc: JsonRpc;
    constructor(rpc: JsonRpc);
    blockNumber(): Promise<bigint>;
    chainId(): Promise<bigint>;
    receipt(txHash: Uint8Array): Promise<ReceiptJson | null>;
    /** The header of a block by hash, as its exact RLP, which must hash to the requested hash. */
    headerByHash(hash: Uint8Array): Promise<{
        header: Header;
        raw: Uint8Array;
    }>;
    /** The header of a block by number and its hash (the hash of its exact re-encoding); null when the node does not hold it. */
    headerByNumber(n: bigint): Promise<{
        header: Header;
        hash: Uint8Array;
    } | null>;
    /**
     * The certificate of block N: witness 0 of the companion of its child N+1 (section 12.7). Not yet served while the child does not
     * exist (`CompanionUnknown`, retry after a round); `EvidencePruned` below the node's horizon.
     */
    certificateOf(header: Header, hash: Uint8Array, bindTechnicalRecord?: boolean, sources?: readonly EvmReader[], authenticate?: (uc: Uint8Array) => Promise<void>): Promise<Uint8Array>;
    /** The root-to-leaf receipt-trie path of RLP(txIndex), from the block's receipts, whose trie must hash to the header's root. */
    receiptPath(header: Header, hash: Uint8Array, txIndex: bigint): Promise<Uint8Array[]>;
    /** Verify a failed receipt against its certified block before abandoning a pending send. */
    verifyFailedReceipt(txHash: Uint8Array, cfg: Config, trust: TrustInput, receipt: ReceiptJson, archives?: readonly EvmReader[]): Promise<void>;
    /** The DepositProof container for the first log of `txHash` emitted by `emitter` with `topic0`. */
    receiptProof(txHash: Uint8Array, emitter: Uint8Array, topic0: Uint8Array, bindTechnicalRecord?: boolean, expected?: Pick<RecoveryEvent, 'topics' | 'data'>, archives?: readonly EvmReader[], authenticate?: (raw: Uint8Array, uc: Uint8Array) => Promise<void>): Promise<ReceiptProof>;
    /** `eth_getLogs` of `address` and `topics` over [from, to], in gateway windows, in order; a result-count error halves the window. */
    logs(address: Uint8Array, topics: (string | string[] | null)[], from: bigint, to: bigint): Promise<RawLog[]>;
    /** The newest SegmentSealed log of the vault at or after `from`, paging backwards from the head; null when it never sealed. */
    newestSeal(vault: Uint8Array, from: bigint): Promise<RawLog | null>;
    /** The SegmentSealed logs of segments [start, end) in order, paging forwards from `from` (a block at or before segment `start`'s seal). */
    segmentLogs(vault: Uint8Array, from: bigint, start: bigint, end: bigint): Promise<RawLog[]>;
    /** `Paid(eta)` logs of the vault from block `from`. */
    paid(vault: Uint8Array, eta: Uint8Array, from: bigint): Promise<RawLog[]>;
    call(to: Uint8Array, data: Uint8Array, from?: Uint8Array): Promise<Uint8Array>;
    /** Check imported authority and simulate the exact fee-bearing return at the same finalized block. */
    checkReturnImport(cfg: Config, epoch: bigint, tx: {
        from: Uint8Array;
        to: Uint8Array;
        data: Uint8Array;
        gas: bigint;
        value: bigint;
    }): Promise<void>;
    vaultState(vault: Uint8Array): Promise<VaultState>;
    vaultConfig(vault: Uint8Array): Promise<Uint8Array>;
    code(address: Uint8Array): Promise<Uint8Array>;
    balance(address: Uint8Array, tag?: 'latest' | bigint): Promise<bigint>;
    /** Best-effort view of calls a gateway exposes in its pending block. */
    pendingCalls(to: Uint8Array): Promise<{
        hash: Uint8Array;
        calldata: Uint8Array;
    }[]>;
    /** The account nonce: 'pending' counts the pool (for signing), 'latest' only mined transactions (for deciding a send is dead). */
    nonce(address: Uint8Array, tag?: 'pending' | 'latest' | bigint): Promise<bigint>;
    /** The base fee of the latest block and a priority fee. */
    fees(): Promise<{
        baseFee: bigint;
        priority: bigint;
    }>;
    /** `eth_estimateGas`; a revert is returned as its data (for classification), never thrown as success. */
    estimateGas(tx: {
        from: Uint8Array;
        to: Uint8Array;
        data: Uint8Array;
        value?: bigint;
    }): Promise<{
        gas: bigint;
    } | {
        revert: Uint8Array | null;
        message: string;
    }>;
    /** Submit a signed raw transaction; an HTTP 503 is {@link AmbiguousBroadcast}. */
    sendRaw(raw: Uint8Array): Promise<Uint8Array>;
}
/** The revert data an RPC error carries (`data` of the error object is not kept by every client; the message may embed it). */
export declare function revertDataOf(e: RpcError): Uint8Array | null;
export { WalletError, u256 };
export declare const recoveryRpcSource: (reader: EvmReader, txHash: Uint8Array) => RecoveryReceiptSource;
