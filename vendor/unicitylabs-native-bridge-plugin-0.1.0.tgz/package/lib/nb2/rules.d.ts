import { type Config } from './config.js';
import { type DepositProof } from './deposit.js';
import { Nb2Error, WalletError } from './errors.js';
import { type Segment } from './segment.js';
import { type TrustInput } from './trust.js';
/** A verified SegmentSealed(j) receipt. */
export interface SealReceipt {
    segment: Segment;
    proof: DepositProof;
    blockNumber: bigint;
}
/**
 * A seal receipt proof (a DepositProof container whose log is SegmentSealed), verified exactly as section 6.2 steps 2 to 5 for that
 * event: the same EVM UC rule, header, receipt path, type, status, log index and emitter, topics [topic0(SegmentSealed), u256(j)] with
 * j < 2^48, and the log's own check. Every failure is `SealReceipt` carrying the inner rule.
 */
export declare function verifySealReceipt(c: Config, domain: Uint8Array, t: TrustInput, receipt: Uint8Array): Promise<SealReceipt>;
/** Section 12.2: with the newest verified seal receipt of segment j, sign a = j + 1 and keep H_{j+1}; with none, a = 0 and H_0. */
export declare function burnIndex(c: Config, domain: Uint8Array, newest: SealReceipt | null): {
    a: bigint;
    startHead: Uint8Array;
};
/**
 * P_max = floor((L_max - L_T - L_O) / (65 + 32h)) and whether the return without history fits at all (L_T <= L_max and
 * L_O <= L_max - L_T); P_max is zero when it does not.
 */
export declare function maxProofs(lMax: bigint, lT: bigint, lO: bigint, K: bigint): {
    pMax: bigint;
    baseFits: boolean;
};
/** The before-burn capacity input (section 12.5 as amended by astra's review, finding 1). */
export interface Preflight {
    lMax: bigint;
    /** The encoded evidence, including the burn and its certification. */
    lT: bigint;
    /** All other framing of the redeem transaction (ABI padding, transaction envelope, start head). */
    lO: bigint;
    K: bigint;
    a: bigint;
    /** A current endpoint estimate, cObs >= a. */
    cObs: bigint;
    reserve: bigint;
    /** The gas limit (expected cost plus gasReserve) with P proofs, estimated conservatively; null when it cannot be bounded. */
    gasAt: (p: bigint) => bigint | null;
    userGasLimit: bigint;
}
/** Refuse the burn (`CapacityPreflight`) unless the return fits L_max and userGasLimit with P_now + returnReserveSegments proofs. */
export declare function capacityPreflight(p: Preflight): {
    pNow: bigint;
    need: bigint;
    pMax: bigint;
    gas: bigint;
};
/** The at-redemption refusal: P > P_max, or the gas limit above userGasLimit. */
export declare function capacityExceeded(lMax: bigint, lT: bigint, lO: bigint, K: bigint, P: bigint, gasLimit: bigint, userGasLimit: bigint): void;
/**
 * The stateReadOnly substitute for a seal receipt (section 12.2, test deployments only): the read index must lie in
 * [verified, verified + maxJump] (`ImplausibleIndex`); without stateReadOnly a state() read is not evidence at all.
 */
export declare function checkStateRead(stateReadOnly: boolean, read: bigint, verified: bigint, maxJump: bigint): void;
/** A seal companion answer (section 12.7): "found" with exactly two witnesses is usable; "unavailable" is EvidencePruned; anything else ("ok" included) is a provider fault. */
export declare function checkCompanion(status: string, witnesses: number): void;
export { Nb2Error, WalletError };
