/** bucket(eta) = eta >> (256 - log2 B). */
export declare const bucketOf: (eta: Uint8Array, B: bigint) => number;
export declare function cmp(a: Uint8Array, b: Uint8Array): number;
export declare const gapLeaf: (l: Uint8Array, u: Uint8Array) => Uint8Array;
export declare const gapNode: (l: Uint8Array, r: Uint8Array) => Uint8Array;
/** 65 + 32h bytes. */
export declare const gapProofLen: (K: bigint) => number;
export declare class GapTree {
    readonly z: Uint8Array[];
    private readonly levels;
    private constructor();
    /** Requires a power-of-two count >= 2, strictly increasing. */
    static build(z: Uint8Array[]): GapTree | null;
    /** M_j */
    get root(): Uint8Array;
    /** The gap proof of `eta`, or null when `eta` is one of the identifiers (paid in this segment). */
    prove(eta: Uint8Array): Uint8Array | null;
}
/** M derived from a gap proof for `eta` (section 10.2), or null when the proof is invalid. */
export declare function gapRoot(K: bigint, eta: Uint8Array, proof: Uint8Array): Uint8Array | null;
/** H_0 = H_E(ARCHIVE_GENESIS || D || u16(K)). */
export declare const genesisHead: (d: Uint8Array, K: bigint) => Uint8Array;
/** H_{j+1} = H_E(ARCHIVE_STEP || D || u64(j) || H_j || M_j). */
export declare const nextHead: (d: Uint8Array, j: bigint, hj: Uint8Array, mj: Uint8Array) => Uint8Array;
/** Redeem step 3: fold from `startHead` through j = a .. a+P-1; `BadGapProof(position)` for a refused proof. */
export declare function foldHistory(d: Uint8Array, K: bigint, eta: Uint8Array, a: bigint, startHead: Uint8Array, proofs: Uint8Array[]): Uint8Array;
/** The redeem history: empty for P = 0, else startHead || proof_0 || ... || proof_{P-1}. */
export declare const encodeHistory: (startHead: Uint8Array, proofs: Uint8Array[]) => Uint8Array;
/** Split a history into its start head and proofs (the vault's step 1 framing); null when the length is not admitted. */
export declare function splitHistory(K: bigint, history: Uint8Array): {
    startHead: Uint8Array;
    proofs: Uint8Array[];
} | null;
/** The 128 + 32K bytes of SegmentSealed(c, H_c, H_{c+1}, z_0 || ... || z_{K-1}). */
export declare const segmentSealedData: (before: Uint8Array, after: Uint8Array, z: Uint8Array[]) => Uint8Array;
/** One verified SegmentSealed log. */
export interface Segment {
    index: bigint;
    before: Uint8Array;
    after: Uint8Array;
    z: Uint8Array[];
    root: Uint8Array;
}
/**
 * The wallet's check of the SegmentSealed log of segment j (section 12.3): exact length, the offset and length words, strictly sorted
 * identifiers, and H_{j+1} == NextHead(D, j, headBefore, M_j) == headAfter with headBefore the expected previous head. Every failure is
 * `SegmentLog`.
 */
export declare function checkSegmentLog(d: Uint8Array, K: bigint, j: bigint, expectBefore: Uint8Array, data: Uint8Array): Segment;
/**
 * The wallet's proof builder (section 12.3): one gap proof of `eta` per verified segment a .. e-1 (in order, contiguous) and the start
 * head H_a. `paid` when `eta` is in one of them.
 */
export declare function buildHistory(segs: Segment[], eta: Uint8Array, a: bigint, e: bigint, ha: Uint8Array): {
    history: Uint8Array;
    paid: bigint | null;
};
