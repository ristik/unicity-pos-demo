export declare const MAX_CBOR_DEPTH = 16;
export declare function head(major: number, n: bigint | number): Uint8Array;
/** Fixed-width big-endian. */
export declare function be(v: bigint | number, width: number): Uint8Array;
export declare const u256: (v: bigint | number) => Uint8Array;
export declare const u64: (v: bigint | number) => Uint8Array;
export declare const u16: (v: bigint | number) => Uint8Array;
export declare const cUint: (n: bigint | number) => Uint8Array;
export declare const cBytes: (b: Uint8Array) => Uint8Array;
export declare const cTag: (tag: bigint | number, content: Uint8Array) => Uint8Array;
export declare const cArr: (...items: Uint8Array[]) => Uint8Array;
export declare const cNull: Uint8Array<ArrayBuffer>;
export declare const cNullOr: (b: Uint8Array | null) => Uint8Array;
export declare const ascii: (s: string) => Uint8Array;
/** The minimal unsigned big-endian bytes of a positive amount. */
export declare function amountBytes(v: bigint): Uint8Array;
export declare const cAmount: (v: bigint) => Uint8Array;
export declare const beInt: (b: Uint8Array) => bigint;
/** An SDK deadline: unset (null) or a u64 in [1, 2^64-1]. */
export type Deadline = bigint | null;
export declare const cDeadline: (d: Deadline) => Uint8Array;
export interface Item {
    major: number;
    arg: bigint;
    start: number;
    end: number;
    data?: Uint8Array;
    kids: Item[];
    isNull: boolean;
}
/** Exactly one strict item spanning all of `b`. */
export declare const scanOne: (b: Uint8Array) => Item;
/** One item that may embed a native certificate (text strings and maps admitted). */
export declare const scanNative: (b: Uint8Array) => Item;
/** The tag number at the head of `b`, without scanning further; null when it is not a well-formed tag head. */
export declare function headTag(b: Uint8Array): bigint | null;
export declare const raw: (b: Uint8Array, it: Item) => Uint8Array;
export declare const isUint: (it: Item) => boolean;
export declare const isBytes: (it: Item) => boolean;
export declare const isArray: (it: Item) => boolean;
export declare const isTag: (it: Item) => boolean;
export declare function array(it: Item, n: number): Item[];
export declare function bytesN(it: Item, n: number): Uint8Array;
export declare function bstr(it: Item): Uint8Array;
export declare function tagContent(it: Item, tag: bigint | number): Item;
export declare function uintIn(it: Item, lo: bigint, hi: bigint): bigint;
export declare function version(it: Item, want: bigint | number): void;
export declare function literal(it: Item, s: string): void;
/** An Amount: a minimal positive big-endian byte string of 1 to 32 bytes. */
export declare function amount(it: Item): bigint;
export declare const MAX_U64: bigint;
export declare function deadline(it: Item): Deadline;
export declare function nullableBytes(it: Item): Uint8Array | null;
