/** keccak256(RLP([])) */
export declare const EMPTY_UNCLE_HASH: Uint8Array<ArrayBufferLike>;
/** keccak256(RLP("")), the empty trie root. */
export declare const EMPTY_TRIE_ROOT: Uint8Array<ArrayBufferLike>;
export interface Header {
    parentHash: Uint8Array;
    ommersHash: Uint8Array;
    beneficiary: Uint8Array;
    stateRoot: Uint8Array;
    transactionsRoot: Uint8Array;
    receiptsRoot: Uint8Array;
    logsBloom: Uint8Array;
    difficulty: bigint;
    number: bigint;
    gasLimit: bigint;
    gasUsed: bigint;
    timestamp: bigint;
    extraData: Uint8Array;
    mixHash: Uint8Array;
    nonce: Uint8Array;
    baseFeePerGas: bigint;
    withdrawalsRoot: Uint8Array;
    blobGasUsed: bigint;
    excessBlobGas: bigint;
    parentBeaconBlockRoot: Uint8Array;
}
export declare function encodeHeader(h: Header): Uint8Array;
/** Decode the pinned header shape (exact field widths, canonical integers, 20 fields, identical re-encoding); `DepositHeader` otherwise. */
export declare function decodeHeader(raw: Uint8Array): Header;
/**
 * Bind a header to its certified input record: `H_E(headerRLP) == IR.blockHash` and `header.stateRoot == IR.hash`, then the profile's
 * constraints (zero difficulty, empty uncles and withdrawals, no blob gas, a nonzero u64 base fee, at most 32 extra bytes, number below
 * 2^63).
 */
export declare function bindHeader(raw: Uint8Array, irBlockHash: Uint8Array | null, irHash: Uint8Array | null): Header;
