/**
 * Size and gas bounds of a redemption (sections 12.4 and 12.5). The preflight needs a CONSERVATIVE bound of the complete redeem
 * transaction before the burn exists: its encoded size and its gas limit (expected cost plus `gasReserve`). The gas part is a named,
 * replaceable component: {@link GasModel}. The default {@link MeasuredGasModel} (estimate-nb2-1179, docs/nb2-gas-model.md) is a measured
 * conservative estimate of the redeem, term by term from the deployed verifier's cost structure with an explicit safety margin, and fails
 * closed (null, which the preflight reports as `CapacityPreflight`) for anything it cannot estimate. {@link ProvisionalGasModel} is NB2-07's earlier over-estimate, kept for comparison.
 */
import { type Token } from './token.js';
/** What the gas model sees of a prospective redemption. */
export interface RedeemShape {
    /** The evidence bytes (`C(1, Token)`), or an upper bound of their length when the burn does not exist yet. */
    evidenceBytes: number;
    /** The decoded token of the lineage walk, root first, when known (counts certificates, signatures and paths). */
    lineage: Token[];
    /** Transactions the evidence will hold that are not in `lineage` yet (the burn about to be made). */
    pendingTransactions: number;
    /** Historical gap proofs. */
    proofs: bigint;
    K: bigint;
}
/** A gas model: the gas limit of a redeem (expected cost plus gasReserve), or null when it cannot be bounded. */
export interface GasModel {
    readonly name: string;
    redeemGasLimit(s: RedeemShape): bigint | null;
    /**
     * Whether the model is calibrated for the deployment, given its runtime codes (the verifier's hash checked against Γ, the vault's against
     * the manifest) and the manifest's native gas schedule. A model without this method is the wallet's own choice and is used as supplied.
     */
    supportsDeployment?(d: DeploymentCode): boolean;
    /** The gas limit of a deposit call. */
    depositGasLimit(): bigint;
}
/** Measured by #1098 (K = 64, B = 16, optimizer runs 200): replay and settlement only. */
export declare const MEASURED: {
    readonly gasReserve: 500000n;
    readonly previousEndpoint: 78083n;
    readonly perSegment: 5950n;
    readonly depositFirst: 48758n;
};
/**
 * Upper-bound guesses for the unmeasured verifier, from the B1 price schedule (bft-core `b1ref/limits.go`, profile 7) charged for
 * EVERY certificate occurrence as its own call, plus a per-byte charge for parsing and hashing the evidence in Solidity. Each term is
 * chosen above any plausible cost; it is not a measurement.
 */
export declare const PROVISIONAL: {
    readonly perEvidenceByte: 128n;
    readonly perCertificate: bigint;
    readonly perCertificateByte: 16n;
    readonly perSignature: 7200n;
    readonly maxSignatures: 16;
    readonly perPathStep: 250n;
    readonly perTransaction: bigint;
    readonly receiptProof: 200000n;
    /** A pending transaction's own certificate. */
    readonly pendingCertificateBytes: 24576;
};
export declare class ProvisionalGasModel implements GasModel {
    readonly name = "provisional-nb2-07";
    redeemGasLimit(s: RedeemShape): bigint | null;
    depositGasLimit(): bigint;
}
/**
 * The redeem gas estimate (bft-core#1179, docs/nb2-gas-model.md, where the calibration, the terms derived from the code and the terms
 * measured are listed): a measured conservative estimate of the vault redeem's gas limit, term by term from the deployed verifier's cost
 * structure (unicity-pos-contracts `NativeBridgeVerifierV2`, its receipt helper `Nb2ReceiptVerifier`, the vault), not a fit to the token's
 * length. It is not a proven universal bound:
 *
 *   limit = transaction + vault + batch + membership + sha256 + execution + memory + forwarding + safety + gasReserve
 *
 *   transaction  21,000 + 16 per calldata byte (every byte priced as nonzero)
 *   vault        the worst measured call of NB2VaultBase (every phase, a never-used recipient) + 6,000 per historical segment
 *                + its copy of the evidence into the verifier call: 3 a word and the vault frame's memory expansion
 *   batch        CERT_BATCH_V2 (0x0100) exactly as charged, over the distinct claims in the verifier's batching (_flush)
 *   membership   the RSMT membership (0x0102) exactly as charged, per inclusion proof
 *   sha256       SHA-256 (0x02) of every hashed transaction, exactly (a mint's includes its justification, so nesting is counted)
 *   execution    the verifier's and the helper's own execution, each loop priced per iteration at its measured cost rounded up: per token, split
 *                edge, allocation step and inclusion proof; per transaction word copied; per RSMT sibling; per CBOR item each walk visits
 *                (scan and skip, by item form); per RLP item and head of J's receipt (by form); per UC
 *                parsed (base, byte, signature, shard tree sibling, unicity tree step, non-ASCII node ID byte) and its helper frame's memory;
 *                per key lookup, key decompression and hash-table probe (the verifier's three open-addressing tables replayed on the token's
 *                own keys, state IDs and claims; an unknown claim at every occupied slot); per byte of the root's J
 *   memory       the verifier frame's memory expansion, 3 M + M^2 / 512, over a bound M (words) of its high-water: what it allocates for
 *                the token plus the largest scratch beyond its free pointer
 *   forwarding   EIP-150: the vault keeps 1/64 of the gas it forwards to the verifier, the verifier 1/64 of its largest call
 *   safety       1/32 of the measured terms (execution, memory, vault)
 *
 * The token's own proofs are counted exactly. The pending burn of a preflight is counted at the decoder bounds: a 24 KiB UC with 16
 * signatures of 128-byte non-ASCII node IDs, 256 shard tree siblings and 32 unicity tree steps, 256 RSMT siblings, a new claim and a new
 * epoch. A UC that does not parse, or has more than 16 signatures, gives null (`CapacityPreflight`).
 */
export declare const REDEEM_GAS: {
    readonly txBase: 21000n;
    readonly calldataByte: 16n;
    readonly vaultWorstCall: 530000n;
    readonly perSegment: 6000n;
    readonly copyWord: 3n;
    readonly batchCall: 61100n;
    readonly batchByte: 16n;
    readonly batchPair: 500n;
    readonly batchEpoch: 29900n;
    readonly batchSignature: 7200n;
    readonly batchClaim: 2000n;
    readonly batchPath: 250n;
    readonly batchClaims: 16;
    readonly batchBytes: 262144;
    readonly memberCall: 2000n;
    readonly memberByte: 16n;
    readonly memberStep: 250n;
    readonly sha256Call: 60n;
    readonly sha256Word: 12n;
    readonly verifierBase: 159000n;
    readonly perToken: 0n;
    readonly perEdge: 16407n;
    readonly perAllocStep: 2000n;
    readonly perStep: 21226n;
    readonly perParentStep: 0n;
    readonly perTxWord: 3n;
    readonly perSibling: 3n;
    readonly scanItem: 410n;
    readonly scanLong: 230n;
    readonly scanNode: 185n;
    readonly skipItem: 260n;
    readonly skipLong: 90n;
    readonly perUcParse: 19100n;
    readonly perUcByte: 7n;
    readonly perUcIrByte: 27n;
    readonly perUcSignature: 1784n;
    readonly perUcStc: 1798n;
    readonly perUcUtc: 2146n;
    readonly perUcSlowByte: 367n;
    readonly perUcKeyWord: 320n;
    readonly perKeyLookup: 0n;
    readonly perDecompress: 2100n;
    readonly perProbe: 270n;
    readonly perClaim: 0n;
    readonly jByte: 10n;
    readonly perRlpItem: 320n;
    readonly perRlpLong: 190n;
    readonly perRlpList: 250n;
    readonly perRlpHead: 1070n;
    readonly perRlpLongHead: 450n;
    readonly perRlpKids: 2000n;
    readonly coldAccess: 5200n;
    readonly memBase: 320;
    readonly memPerStep100: 6744;
    readonly memPerParentStep100: 0;
    readonly memPerClaimWord100: 103;
    readonly memPerUcWord100: 306;
    readonly memPerPathWord100: 123;
    readonly memPerToken100: 28523;
    readonly memPerEdge100: 0;
    readonly memPerAllocStep100: 600;
    readonly memPerJWord100: 200;
    readonly pendingTxBytes: 256;
    readonly pendingUcBytes: 24576;
    readonly pendingSignatures: 16;
    readonly pendingIdBytes: 128;
    readonly pendingIrBytes: 448;
    readonly pendingStc: 256;
    readonly pendingUtc: 32;
    readonly pendingShardBytes: 33;
    readonly pendingSiblings: 256;
    readonly pendingUcItems: number;
    readonly pendingPairItems: 32;
    readonly pendingDataItems: 16;
    readonly maxSignatures: 16;
    readonly keyCache: 128;
    readonly safetyDivisor: 32n;
};
/** A UC's shape as the helper's parse prices it. */
export interface UcCost {
    bytes: number;
    ir: number;
    signatures: number;
    stc: number;
    utc: number;
    slow: number;
    keyWords: number;
}
/** The helper's certificate() on one UC, at the bound's coefficients (its execution and its frame's memory). */
export declare function helperGas(c: UcCost): bigint;
/** What the bound counts, extracted from the lineage. */
export interface RedeemFeatures {
    tokens: number;
    edges: number;
    allocSteps: number;
    steps: number;
    parentSteps: number;
    txWords: number;
    maxTx: number;
    siblings: number;
    ucParses: number;
    ucBytes: number;
    ucIr: number;
    ucSignatures: number;
    ucStc: number;
    ucUtc: number;
    ucSlow: number;
    ucKeyWords: number;
    helperMemory: bigint;
    evmUc: UcCost;
    rcptItems: number;
    rcptLong: number;
    rcptLists: number;
    rcptHeads: number;
    rcptLongHeads: number;
    rcptKids: number;
    rcptWords: number;
    ucCosts: UcCost[];
    pathWords: number;
    maxUc: number;
    scratch: number;
    scan: CborCount;
    skip: CborCount;
    jBytes: number;
    keyLookups: number;
    decompressions: number;
    probes: number;
    claims: {
        bytes: number;
        signatures: number;
        path: number;
        epoch: bigint | null;
    }[];
}
/** What a walk of the verifier's CBOR reader visits: items, heads with argument bytes, and nested items (a non-empty array or map, a tag). */
export interface CborCount {
    items: number;
    long: number;
    nodes: number;
}
/** The items of a CBOR item sequence as Nb2Cbor's scan and skip visit them (definite lengths, string payloads skipped). */
export declare function cborCount(b: Uint8Array): CborCount;
/** The heads of a CBOR item sequence (definite lengths, string payloads skipped): the items the verifier's scanner visits. */
export declare function cborItems(b: Uint8Array): number;
/** The features of a prospective redemption; null when a UC does not parse or has more signatures than the bound. */
export declare function redeemFeatures(s: RedeemShape): RedeemFeatures | null;
/** The memory expansion of WORDS words (the Yellow Paper's C_mem). */
export declare const memoryGas: (words: number) => bigint;
/** CERT_BATCH_V2 over the distinct claims in the verifier's batching (_flush): balanced calls of at most 16 claims and 256 KiB. */
export declare function batchGas(claims: RedeemFeatures['claims']): {
    gas: bigint;
    calls: number;
    largest: bigint;
};
/** The verifier frame's memory high-water bound (words): its hash tables exactly, what else it allocates, its largest scratch use. */
export declare function verifierMemoryWords(f: RedeemFeatures): number;
/** The verifier's CBOR walks at the bound's prices. */
export declare function walkGas(f: RedeemFeatures): bigint;
/** The receipt helper's RLP walk at the bound's prices. */
export declare function receiptWalkGas(f: RedeemFeatures): bigint;
/** The estimate's terms: each is derived from the code or measured (docs/nb2-gas-model.md lists which). */
export interface GasTerms {
    transaction: bigint;
    vault: bigint;
    batch: bigint;
    membership: bigint;
    sha256: bigint;
    execution: bigint;
    memory: bigint;
    forwarding: bigint;
    safety: bigint;
    reserve: bigint;
    limit: bigint;
    memoryWords: number;
}
/** The terms of a redemption with FEATURES, EVIDENCEBYTES of evidence and PROOFS historical gap proofs at K. */
export declare function priceFeatures(f: RedeemFeatures, evidenceBytes: number, proofs: bigint, K: bigint): GasTerms;
export declare function redeemGasTerms(s: RedeemShape): GasTerms | null;
/** The native gas schedules {@link REDEEM_GAS} assumes (ureth unicity/main crates/unicity/b1, profile 7; SHA-256 as in Cancun). */
export declare const NATIVE_GAS_SCHEDULE = "CERT_BATCH_V2 61100+16C+500K(K-1)+29900E+7200Q+2000A+250P; RSMT 2000+16L+250(1+S); SHA256 60+12W";
/**
 * The deployment {@link REDEEM_GAS} is calibrated for: unicity-pos-contracts 884c4829 `src/nb2` as deploy_nb2.py creates it (solc 0.8.37,
 * via-IR; the verifier at optimizer runs 1, the vault at 200), its helper, and {@link NATIVE_GAS_SCHEDULE}. Each runtime is the artifact's
 * code with its immutables filled in; the immutables are all derived from Γ and the verifier's address, so the expected runtime is rebuilt
 * from them and compared with the deployed one in full ({@link calibratedDeployment}).
 */
export declare const CALIBRATED_DEPLOYMENT: {
    readonly verifier: {
        readonly codeLength: 19574;
        readonly maskedCodeHash: "65fbc862ae2ea16729506cd9e6a62458785751b690103ce25d9515495029f201";
        readonly admitsTestSet: readonly [8541, 12187];
        readonly receipts: readonly [325, 3071, 8473, 15504];
        readonly receiptsCodeHash: readonly [368, 8417];
    };
    readonly helperCodeHash: "16f1381ed6c1d9cd1c14b467fcfb2ec84ab8903f65da506048fbb2e2c10ffe23";
    readonly vault: {
        readonly codeLength: 6363;
        readonly maskedCodeHash: "9bc8cce34b22e45345a9a49c28a4041229f748c8d13964e69fbf2020b90545e4";
        readonly immutables: readonly [readonly [103, 1318, 2642, 4362, 5801], readonly [1218], readonly [5648], readonly [1460, 1792, 1924, 1986, 2090, 2181, 2222, 2391, 2455, 2500, 4057, 6226], readonly [375, 4228, 4291, 4415, 4531, 4761], readonly [519, 576, 1529, 1567, 1607, 1642, 2031, 2139, 2266, 2344, 3419, 3468, 3543, 3639, 3688, 4019, 6189], readonly [1097, 4929], readonly [641, 5044], readonly [676, 5079], readonly [713, 5117], readonly [751, 5155], readonly [789, 5193], readonly [827, 5231], readonly [865, 5269], readonly [903, 5307], readonly [941, 5345], readonly [980, 5384], readonly [1019, 5423], readonly [1058, 5462]];
    };
};
/** What the bridge shows a gas model of the deployment (codes from the RPC; the vault's and the verifier's hashes already checked). */
export interface DeploymentCode {
    gamma: Uint8Array;
    verifier: Uint8Array;
    K: bigint;
    B: bigint;
    Qmax: bigint;
    verifierCode: Uint8Array;
    /** The code at the verifier's first CREATE address ({@link createAddress}(verifier, 1)), where its constructor deploys the helper. */
    helperCode: Uint8Array;
    vaultCode: Uint8Array;
    /** The deployment manifest's `nativeGasSchedule` pin, when it has one. */
    nativeGasSchedule?: string;
}
/** The address of the contract ADDRESS creates with nonce NONCE (keccak256(RLP([address, nonce]))[12:]). */
export declare function createAddress(address: Uint8Array, nonce: bigint): Uint8Array;
/**
 * Whether D is the calibrated deployment: the verifier's, the helper's and the vault's runtimes are exactly the calibrated artifacts with the
 * immutables this deployment must have (admitsTestSet unless (K, B) is the production pair; the helper at the verifier's first CREATE
 * address with the calibrated code hash, which the verifier pins; the vault's D = H_U(Γ), verifier, Qmax, K, log2 K, log2 B and Γ's twelve
 * words), and the manifest pins {@link NATIVE_GAS_SCHEDULE}.
 */
export declare function calibratedDeployment(d: DeploymentCode): boolean;
/** The default model: {@link REDEEM_GAS}, for the {@link CALIBRATED_DEPLOYMENT} only (the bridge refuses it for any other). */
export declare class MeasuredGasModel implements GasModel {
    readonly name = "estimate-nb2-1179";
    supportsDeployment(d: DeploymentCode): boolean;
    redeemGasLimit(s: RedeemShape): bigint | null;
    depositGasLimit(): bigint;
}
/** The byte-level count, kept only as a cross-check in tests. */
export declare function countSignaturesRaw(uc: Uint8Array): number | null;
/**
 * The encoded size of a signed EIP-1559 redeem transaction around `calldata` bytes: the envelope, nine scalar fields at their widest,
 * the 20-byte target, an empty access list and a 65-byte signature, plus the RLP heads of the data string and the list.
 */
export declare const redeemTxFraming: (calldata: number) => number;
