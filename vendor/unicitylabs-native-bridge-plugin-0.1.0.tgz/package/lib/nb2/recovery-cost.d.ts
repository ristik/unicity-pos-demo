import { type Params } from './config.js';
import type { RecoveryDeployment } from './recovery.js';
import type { TrustInput } from './trust.js';
export declare const validRecoveryDeployment: (d: RecoveryDeployment) => boolean;
export interface RecoveryShape {
    entry: 'run' | 'advanceGaps' | 'redeemRecovered';
    calldataBytes: number;
    operations: number;
    pages: number;
    gaps: number;
    receiptBytes: number;
    openingBytes: number;
}
/** Authenticated release calibration. The execution bound includes forwarding and memory, excluding transaction intrinsic and the seal reserve. */
export interface RecoveryCalibration {
    pins: Uint8Array;
    runtimeHash: Uint8Array;
    vaultRuntimeHash?: Uint8Array;
    ranges: readonly RecoveryCalibrationRange[];
}
/** A qualified envelope for the same entry, operation count and gap count.
 * It covers the inclusive receipt interval and all smaller calldata, page and opening sizes for that class.
 */
export interface RecoveryCalibrationRange {
    minReceiptBytes: number;
    max: Readonly<RecoveryShape>;
    execution: bigint;
}
/** Effective minima over the authenticated deployment, node/relay, chain and payer. Empty access lists, zero value. */
export interface RecoveryLimits {
    signedBytes: number;
    calldataBytes: number;
    gas: bigint;
    chainId: bigint;
    maxNonce: bigint;
    maxFeePerGas: bigint;
    maxPriorityFeePerGas: bigint;
    maxTransactionFee?: bigint;
    balance: bigint;
    feeBudget: bigint;
    /** Size the signed envelope at maximal nonce and bid widths for portable wallet plans. */
    worstCaseEnvelope?: boolean;
}
export interface RecoveryQuote {
    shape: RecoveryShape;
    gas: bigint;
    signedBytes: number;
    fee: bigint;
}
export declare function quoteRecovery(shape: RecoveryShape, calibration: RecoveryCalibration, limits: RecoveryLimits): RecoveryQuote | null;
/** Quote the exact full advance and all terminal suffixes with the widest allowed predecessor receipt. */
export declare function quoteRecoveryGapBatch(K: bigint, batch: number, calibration: RecoveryCalibration, limits: RecoveryLimits): {
    advance: RecoveryQuote;
    settle: RecoveryQuote;
} | null;
export interface RecoveryBacklog {
    signedStart: bigint;
    observed: bigint;
    /** Upper bound on segments appended while the progress packets become certified. */
    duringProgress: bigint;
    /** Sustained peak count over elapsedMs, for the catch-up throughput check. */
    peakSeals: bigint;
    elapsedMs: bigint;
    receiptP99Ms: bigint;
    /** Qualified maximum arrivals, including bursts, in any receiptP99Ms window. */
    advancePeakSeals: bigint;
    /** Qualified time from sealing the final endpoint, including proof retrieval, through settlement inclusion. */
    finalInclusionMs: bigint;
    /** Qualified maximum arrivals, including bursts, in any finalInclusionMs window. */
    finalPeakSeals: bigint;
    /** Horizon for which the peak-rate and timing bounds are qualified after lineage progress. */
    qualifiedForMs: bigint;
}
/** Verify that the chosen advance can reach a payable end under the qualified arrival windows. */
export declare function recoveryCatchUpCalls(batch: number, backlog: RecoveryBacklog): bigint;
/** Price each remaining scheduled run at the same bounds used at admission. */
export declare function checkRemainingRecoveryRuns(held: Uint8Array, cuts: readonly number[], confirmedCuts: number, calibration: RecoveryCalibration, limits: RecoveryLimits): void;
/** Price the hypothetical terminal pair at its decoder cap, including its prefix, page alignment and worst later witnesses. */
export declare function preflightRecovery(gamma: Uint8Array, held: Uint8Array, trust: TrustInput, params: Params, deployment: RecoveryDeployment, calibration: RecoveryCalibration, limits: RecoveryLimits, backlog: RecoveryBacklog, startingSeal?: Uint8Array): Promise<{
    run: RecoveryQuote[];
    advance: {
        quote: RecoveryQuote;
        calls: bigint;
    };
    settle: RecoveryQuote;
    settlementMaxGaps: number;
    totalFee: bigint;
}>;
