import { type Config, type Params } from './config.js';
import { type RecoveryCalibration, type RecoveryLimits, type RecoveryQuote, type RecoveryShape } from './recovery-cost.js';
import { type TrustInput } from './trust.js';
export declare const recoveryGeneration: (salt: Uint8Array, domain: Uint8Array) => Uint8Array;
declare const topics: {
    progress: Uint8Array<ArrayBufferLike>;
    complete: Uint8Array<ArrayBufferLike>;
    gap: Uint8Array<ArrayBufferLike>;
};
type Kind = keyof typeof topics;
/** Identify a visible recovered settlement using its certified Complete or Gap receipt. */
export declare function recoveredSettlementEta(cfg: Config, domain: Uint8Array, trust: TrustInput, emitter: Uint8Array, calldata: Uint8Array): Promise<Uint8Array | undefined>;
/** These identities must come from the authenticated deployment, including the recovery runtime hash and dependency pin. */
export interface RecoveryDeployment {
    salt: Uint8Array;
    recovery: Uint8Array;
    runtimeHash: Uint8Array;
    pins: Uint8Array;
    vaultRuntimeHash?: Uint8Array;
}
export interface RecoveryEvent {
    kind: Kind;
    topics: Uint8Array[];
    data: Uint8Array;
}
export interface RecoveryReceipt {
    encoded: Uint8Array;
    blockNumber: bigint;
    blockHash: Uint8Array;
    txIndex: bigint;
    logIndex: bigint;
}
export type RecoveryReceiptSource = (emitter: Uint8Array, event: RecoveryEvent) => Promise<Uint8Array>;
export interface GapPrior {
    seq: bigint;
    cursor?: {
        next: bigint;
        head: Uint8Array;
    };
}
export interface GapPacket {
    shape: RecoveryShape;
    calldata: Uint8Array;
    event: RecoveryEvent | null;
    next: bigint;
    head: Uint8Array | undefined;
}
export interface RunPacket {
    shape: RecoveryShape;
    calldata: Uint8Array;
    end: number;
    state: Uint8Array | null;
    event: RecoveryEvent;
}
/** One authority for all sessions on a deployment. Restore the persisted checkpoint before reopening. */
export declare class RecoveryAuthority {
    #private;
    private readonly persist;
    constructor(checkpoint: TrustInput, persist: (next: TrustInput) => Promise<void>);
    get checkpoint(): Promise<TrustInput>;
    get revision(): number;
    accept(offered: TrustInput, cfg: Config): Promise<void>;
}
export declare class RecoverySession {
    private readonly cfg;
    private readonly deployment;
    private readonly pages;
    private readonly session;
    private readonly header;
    private readonly verdict;
    private readonly ops;
    private readonly authority;
    private constructor();
    static create(gamma: Uint8Array, evidence: Uint8Array, authority: RecoveryAuthority, params: Params, input: RecoveryDeployment): Promise<RecoverySession>;
    get id(): Uint8Array;
    get pageRoot(): Uint8Array;
    get redemptionId(): Uint8Array;
    get operationCount(): number;
    private event;
    /** Produce one exact cut. Resume requires an authenticated receipt for the state derived from that prefix. */
    run(from: number, count: number, trust: TrustInput, prior?: {
        seq: bigint;
        receipt: Uint8Array;
    }): Promise<RunPacket>;
    private checkCalibration;
    /** Fit the largest prefix within the authenticated packet and transaction limits. */
    runBounded(from: number, trust: TrustInput, calibration: RecoveryCalibration, limits: RecoveryLimits, prior?: {
        seq: bigint;
        receipt: Uint8Array;
    }): Promise<{
        packet: RunPacket;
        quote: RecoveryQuote;
    }>;
    private snapshotEvent;
    /** A certified Complete is sufficient to start settlement without the producer's run schedule. */
    verifyComplete(trust: TrustInput, input: Uint8Array, seq: bigint): Promise<RecoveryReceipt>;
    verifyEvent(trust: TrustInput, input: Uint8Array, expected: RecoveryEvent): Promise<RecoveryReceipt>;
    /** Trim only an external predecessor presentation, rechecking the actual historical quorum after each removal. */
    trimReceipt(trust: TrustInput, receipt: Uint8Array, expected: RecoveryEvent): Promise<RecoveryReceipt>;
    /** Try independently authenticated sources. An unknown child remains retryable; pruning is an availability failure. */
    acquire(trust: TrustInput, expected: RecoveryEvent, sources: readonly RecoveryReceiptSource[], refresh?: (held: TrustInput) => Promise<TrustInput>): Promise<{
        receipt: RecoveryReceipt;
        trust: TrustInput;
    }>;
    /** Materialize consecutive exclusion proofs from certified vault seal receipts. */
    certifiedGaps(trust: TrustInput, start: bigint, head: Uint8Array, receipts: readonly Uint8Array[]): Promise<Uint8Array[]>;
    /** Authenticate Complete or Gap and fold exactly this consecutive suffix. */
    gaps(entry: 'advanceGaps' | 'redeemRecovered', trust: TrustInput, input: Uint8Array, prior: GapPrior, inputGaps: readonly Uint8Array[], inputHead?: Uint8Array): Promise<GapPacket>;
    /** Cut a gap suffix to the largest fitting advance. The caller retains the unconsumed suffix. */
    advanceBounded(trust: TrustInput, receipt: Uint8Array, prior: GapPrior, gaps: readonly Uint8Array[], calibration: RecoveryCalibration, limits: RecoveryLimits, startHead?: Uint8Array): Promise<{
        packet: GapPacket;
        quote: RecoveryQuote;
    }>;
}
export type RecoveryContractRefusal = 'BadPacket' | 'BadPredecessor' | 'BadPage' | 'BadStep';
/** Decode exact on-chain transport errors separately from local admission and provider refusals. */
export declare function decodeRecoveryRefusal(data: Uint8Array): RecoveryContractRefusal | null;
export {};
