/** An unsigned EIP-1559 transaction. */
export interface TxRequest {
    chainId: bigint;
    nonce: bigint;
    maxPriorityFeePerGas: bigint;
    maxFeePerGas: bigint;
    gas: bigint;
    to: Uint8Array;
    value: bigint;
    data: Uint8Array;
}
/** A signed transaction: its exact bytes and hash. */
export interface SignedTx {
    raw: Uint8Array;
    hash: Uint8Array;
    request: TxRequest;
}
/** The wallet's EVM account. Implementations may be a hardware wallet or a remote signer; they only have to return the raw bytes. */
export interface EvmSigner {
    readonly address: Uint8Array;
    signTransaction(tx: TxRequest): Promise<Uint8Array>;
}
/** keccak256(0x02 || RLP(unsigned fields)): the EIP-1559 signing hash. */
export declare const signingHash: (t: TxRequest) => Uint8Array;
/** The address of a secp256k1 public key. */
export declare const addressOf: (pub: Uint8Array) => Uint8Array;
export declare class LocalKeySigner implements EvmSigner {
    private readonly key;
    readonly address: Uint8Array;
    constructor(key: Uint8Array);
    signTransaction(t: TxRequest): Promise<Uint8Array>;
}
/**
 * Sign `t` with `signer` and check the signed bytes before they are journaled: an external signer must return exactly this request
 * (chain ID, nonce, fees, gas, target, value, data), signed by its own address. The journaled request is the decoded one.
 */
export declare function signTx(signer: EvmSigner, t: TxRequest): Promise<SignedTx>;
/** Decode a signed EIP-1559 transaction and recover its sender (used by the offline simulator and by tests). */
export declare function decodeSignedTx(raw: Uint8Array): {
    request: TxRequest;
    from: Uint8Array;
    hash: Uint8Array;
};
