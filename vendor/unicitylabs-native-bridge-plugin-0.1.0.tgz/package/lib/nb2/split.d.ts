import { type MintTx, type Token } from './token.js';
export declare function sumLeafHash(key: Uint8Array, data: Uint8Array, value: bigint): Uint8Array | null;
export declare function sumNodeHash(depth: number, hl: Uint8Array, sl: bigint, hr: Uint8Array, sr: bigint): [Uint8Array, bigint] | null;
export interface SumStep {
    depth: number;
    hash: Uint8Array;
    sum: bigint;
}
export declare const encodeSumProof: (p: SumStep[]) => Uint8Array;
/** Fold the leaf to the root; the root sum iff the fold equals `root`. */
export declare function verifySumProof(p: SumStep[], key: Uint8Array, data: Uint8Array, value: bigint, root: Uint8Array): bigint | null;
export declare const encodeSplitManifest: (root: Uint8Array) => Uint8Array;
/** A split burn's data; any failure is `SplitManifest`. */
export declare function decodeSplitManifest(b: Uint8Array): Uint8Array;
/** The child mint's commitment without its justification. */
export declare function splitOutputCommitment(parentId: Uint8Array, m: MintTx): Uint8Array;
export interface SplitJustification {
    parent: Token;
    proof: SumStep[];
}
/** A split reason: arity, the inline parent token (its own wire rules) and exactly one allocation proof. */
export declare function decodeSplitJustification(j: Uint8Array): SplitJustification;
export declare const encodeSplitJustification: (parentToken: Uint8Array, proof: SumStep[]) => Uint8Array;
export interface SumLeaf {
    key: Uint8Array;
    data: Uint8Array;
    value: bigint;
}
export declare class SumTree {
    private readonly rootNode;
    private constructor();
    static build(leaves: SumLeaf[]): SumTree;
    get root(): Uint8Array;
    proof(key: Uint8Array): SumStep[] | null;
}
