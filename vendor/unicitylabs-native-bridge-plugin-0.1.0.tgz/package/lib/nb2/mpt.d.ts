export declare class MptError extends Error {
}
/** The value stored at `key` under `root`; throws {@link MptError}. */
export declare function mptVerify(root: Uint8Array, key: Uint8Array, nodes: Uint8Array[]): Uint8Array;
/** Build the trie of `entries` (distinct keys): its root and the root-to-leaf path of `target` (empty if `target` is null). */
export declare function buildTrie(entries: [Uint8Array, Uint8Array][], target: Uint8Array | null): {
    root: Uint8Array;
    path: Uint8Array[];
};
