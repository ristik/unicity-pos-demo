import { type DecodedError, type RedeemAction } from './abi.js';
import { log2, type Build, type Config } from './config.js';
import { decodeDepositProof } from './deposit.js';
import { type EvmSigner, type TxRequest } from './evm.js';
import { type GasModel, type RedeemShape } from './gas.js';
import { Journal, type DepositRecord, type IntentsRecord, type JournalStore, type ReturnRecord, type SendRecord } from './journal.js';
import { type SealReceipt } from './rules.js';
import { EvmReader, type JsonRpc } from './rpc.js';
import { gapProofLen } from './segment.js';
import { encodeToken, lineageOf } from './token.js';
import { type Aggregator, type OwnerSigner } from './tokenops.js';
import { type TrustInput } from './trust.js';
import { type Verdict } from './verify.js';
/** The deployment manifest pins outside D (section 4.3; the manifest schema is NB2-09's). */
export interface DeploymentPins {
    gamma: Uint8Array;
    build: Build;
    vaultRuntimeCodeHash: Uint8Array;
    maxEncodedTxBytes: bigint;
    userGasLimit: bigint;
    gasReserve: bigint;
    returnReserveSegments: bigint;
    deploymentBlock: bigint;
    stateReadOnly: boolean;
    /** The plausibility bound of a stateReadOnly index read (default 64). */
    maxJump?: bigint;
    /** The chain's native gas schedules (CERT_BATCH_V2, the RSMT membership, SHA-256), as the default gas model names them. */
    nativeGasSchedule?: string;
}
export interface BridgeOptions {
    pins: DeploymentPins;
    trust: TrustInput;
    rpc: JsonRpc;
    aggregator: Aggregator;
    journal: JournalStore;
    /** k_w: the 32-byte wallet bridge key, derived from the wallet seed (see {@link deriveBridgeKey}). */
    bridgeKey: Uint8Array;
    /** The wallet-versioned name of the k_w derivation, recorded in the journal. */
    keyScheme?: string;
    /** Back up the intent high-water mark with the seed (section 12.1). Required unless `requireBackup` is false. */
    backup?: (intents: IntentsRecord) => Promise<void>;
    /** Default true: a deposit is not sent before its intent's high-water mark is backed up. */
    requireBackup?: boolean;
    gas?: GasModel;
    /** Blocks the head must advance, after a send's nonce is seen used without its success receipt, before the send counts as dead. */
    deadAfterBlocks?: bigint;
    /** A seal receipt older than this many blocks gives a warning: the index then reflects a stale view (default 7,200). */
    maxSealAgeBlocks?: bigint;
    /**
     * Extend the trust-base history (append the authenticated successor entries) when a certificate's epoch is not held yet. A seal
     * receipt or a token refused with the retryable NoEntryForEpoch is retried once after it; it is never treated as invalid.
     */
    refreshTrust?: () => Promise<TrustInput | void>;
    /** Receipt polling. */
    receiptTimeoutMs?: number;
    pollMs?: number;
    sleep?: (ms: number) => Promise<void>;
    now?: () => number;
}
export declare const DEFAULT_KEY_SCHEME = "nb2-hmac-sha256-v1";
/** k_w = HMAC-SHA256(key = seed, "unicity-nb2/wallet-bridge-key/v1"): the {@link DEFAULT_KEY_SCHEME} derivation. */
export declare const deriveBridgeKey: (seed: Uint8Array) => Uint8Array;
export interface DepositPlan {
    intent: bigint;
    amount: bigint;
    rho: Uint8Array;
    firstOwner: Uint8Array;
    calldata: Uint8Array;
    record: DepositRecord;
}
/** Ask for a verified alternative when the exact signed request holds an ahead proof. */
export interface ProofRecoveryOptions {
    recoverProof?: boolean;
}
export interface ReturnPlan {
    returnId: Uint8Array;
    amount: bigint;
    recipient: Uint8Array;
    a: bigint;
    /** The endpoint estimate and the history already owed from a. */
    cObs: bigint;
    pNow: bigint;
    /** The proofs that fit beside the evidence (bytes) and the remaining margin: pMax - (pNow + returnReserveSegments). */
    pMax: bigint;
    marginSegments: bigint;
    gasLimit: bigint;
    warnings: string[];
    record: ReturnRecord;
}
/** A wallet may admit recovery when the calibrated ordinary route cannot fit. */
export interface ReturnAdmission {
    ordinaryEnvelope?: {
        encodedBytes: bigint;
        gas: bigint;
        gasFor?: (shape: RedeemShape) => bigint | null;
    };
    checkOrdinary?(record: ReturnRecord, gas: bigint): Promise<void>;
    recover?(record: ReturnRecord): Promise<NonNullable<ReturnRecord['recovery']>>;
    beforeCertification?(record: ReturnRecord): Promise<void>;
}
export interface RedeemOptions {
    recovery?: Uint8Array;
    envelope?: ReturnAdmission['ordinaryEnvelope'];
    archives?: readonly EvmReader[];
    admit?: (request: TxRequest, prior: readonly SendRecord[]) => Promise<void>;
}
export interface RedeemTx {
    returnId: Uint8Array;
    calldata: Uint8Array;
    gasLimit: bigint;
    P: bigint;
    endpoint: bigint;
    history: Uint8Array;
    eta: Uint8Array;
    claimedStart: bigint;
}
export type ReconcileResult = {
    state: 'paid';
    txHash: Uint8Array;
    blockNumber: bigint;
} | {
    state: 'pending';
    txHash: Uint8Array;
} | {
    state: 'needs-archive';
    txHash: Uint8Array;
} | {
    state: 'route-blocked';
    txHash: Uint8Array;
    route: 'ordinary' | 'recovery';
    payer?: Uint8Array;
} | {
    state: 'not-paid';
    lastFailure?: {
        txHash: Uint8Array;
        action: RedeemAction;
        error: DecodedError | null;
    };
};
export interface ReturnEvidence {
    /** Exact signed settlement hashes held locally. */
    settlements?: readonly Uint8Array[];
    /** Also check matching pending-block calls before reporting a provisional payment hint. */
    pending?: {
        recovery?: Uint8Array;
    };
    /** A certified vault receipt. Its transaction hash is a lookup hint. */
    paid?: ReturnRecord['paid'];
    readOnly?: boolean;
}
export declare const FAILURE_PROOF_READS = 3;
export declare class NativeBridgeV2 {
    #private;
    readonly cfg: Config;
    readonly domain: Uint8Array;
    readonly journal: Journal;
    readonly evm: EvmReader;
    readonly gas: GasModel;
    private readonly keyScheme;
    private readonly opts;
    /** In-process serialization per journal key (with the store's compare-and-swap across processes). */
    private readonly locks;
    /** Whether the gas model applies to this deployment (checked once, from its runtime codes and native gas schedule). */
    private gasFits;
    private constructor();
    /**
     * Open the bridge for one pinned deployment. The installation check (section 4.3): the chain ID, the vault's exact Γ through config()
     * and its runtime code hash. These come from the RPC, which the wallet trusts here exactly as far as its manifest source.
     */
    static open(opts: BridgeOptions, check?: boolean): Promise<NativeBridgeV2>;
    private sleep;
    private now;
    /** Run `f` after every earlier call holding `key` in this instance has finished. */
    private locked;
    /** r for intent i (never stored unless the wallet asks: it is derivable from k_w and i). */
    secretOf(i: bigint): Uint8Array;
    /**
     * Plan a deposit of `amount` to the Unicity owner `ownerKey` (compressed key): allocate a never-used intent i, derive r and rho, and
     * journal the plan with the new high-water mark, which is handed to the backup. Serialized: two plans never share an intent.
     */
    planDeposit(amount: bigint, ownerKey: Uint8Array): Promise<DepositPlan>;
    /** Record that the wallet backed up the high-water mark covering this intent by other means. */
    markBackedUp(intent: bigint): Promise<void>;
    private depositRecord;
    /** Every Deposited event of the vault carrying `rho`, from block `from`, in chain order. */
    private depositsWithRho;
    /**
     * Send the deposit. Refuses a plan whose journal entry is not persisted exactly as planned, or whose high-water mark is not backed
     * up. Earlier sends of the intent are reconciled first, and before the first send the vault's events are searched for a deposit that
     * already carries this rho (another device on the same backup), so a retry never deposits twice.
     */
    submitDeposit(plan: DepositPlan | bigint, signer: EvmSigner): Promise<{
        txHash: Uint8Array;
        depositNumber: bigint;
        blockNumber: bigint;
    }>;
    private recordDeposit;
    /** Merge deposit entries into `seenDeposits` by deposit number, keeping journaled tokens, in number order. */
    private mergeSeen;
    /** Journal the deposits found for a record's rho: the first becomes its own, every one is listed (each is a separate root token). */
    private adoptDeposits;
    /** The receipt proof and J of deposit number `n` of intent `i`, verified offline. */
    private proveDeposit;
    /** The ordinary mint with reason J, certified by the aggregator and verified offline. */
    private mintWith;
    /**
     * Fetch the certified header evidence and the block's receipts, build the receipt proof and verify it offline (section 6.2 steps 1 to
     * 7), then journal J. Retry `CompanionUnknown` after a round (the block's certificate is served once its child block exists).
     */
    collectDepositProof(intent: bigint): Promise<{
        reason: Uint8Array;
        depositNumber: bigint;
    }>;
    /** Mint with receipt-backed reason J. Recovery can look for a verified alternative to an ahead proof. */
    mint(intent: bigint, options?: ProofRecoveryOptions): Promise<Uint8Array>;
    /**
     * Mint a further deposit that carries this intent's rho (`seenDeposits`): a reused secret, or a second device. Its value is a
     * separate root token with its own deposit number; nothing is lost.
     */
    mintExtraDeposit(intent: bigint, depositNumber: bigint, options?: ProofRecoveryOptions): Promise<Uint8Array>;
    /**
     * Recover deposits from the seed (k_w) and a backed-up high-water mark (section 5.1): every intent below `next` is matched by its rho
     * against the vault's Deposited events. A match upgrades a planned or submitted record (or creates the record) to deposited; every
     * deposit number seen for a rho is journaled. Intents without a matching event were never funded. A look-ahead past the mark does
     * not replace it.
     */
    recoverDeposits(next: bigint): Promise<bigint[]>;
    /** Verify a held token fully offline (receipt origin, lineage, every certificate): its ID, amount, owner and spendable state. */
    verifyToken(token: Uint8Array): Promise<{
        tokenId: Uint8Array;
        amount: bigint;
        owner: Uint8Array | null;
        state: Uint8Array;
    }>;
    /** An ordinary transfer to `toKey`; the result is verified before it is returned. */
    transfer(token: Uint8Array, owner: OwnerSigner, toKey: Uint8Array, options?: ProofRecoveryOptions): Promise<Uint8Array>;
    /**
     * Split a held token into whole parts. The plan is journaled first, then the burn's
     * exact request, the burned parent and each child as it is minted; a call with the same `splitId` resumes.
     */
    split(token: Uint8Array, owner: OwnerSigner, outputs: {
        ownerKey: Uint8Array;
        amount: bigint;
    }[], splitId?: Uint8Array, options?: ProofRecoveryOptions): Promise<Uint8Array[]>;
    private splitInner;
    /** The newest verified seal receipt (section 12.2) and its container, or null when the vault has never sealed. */
    newestSealReceipt(): Promise<{
        receipt: SealReceipt;
        encoded: Uint8Array;
    } | null>;
    private trustBehind;
    /** Keep a certification result through trust refresh, retry and reload. */
    private retainedCertification;
    /** Run `f` again after refreshing missing history or an origin behind its proof. */
    private retryingTrust;
    /** Byte headroom for the prospective terminal pair, independent of gas calibration. */
    returnHeadroom(token: Uint8Array): {
        operations: number;
        bytes: number;
        ordinarySegments: bigint;
    };
    private checkReturnRecipient;
    /**
     * Plan the return of a whole held part to `recipient` on the EVM: verify its full provenance, pick the index from a verified seal
     * receipt, and run the capacity preflight (section 12.5): the complete prospective return with the history already owed from `a` plus
     * `returnReserveSegments` must fit the encoded-transaction limit and `userGasLimit`, and `payer` must fund that gas limit. Journals the
     * plan; nothing irreversible happens here.
     */
    planReturn(token: Uint8Array, recipient: Uint8Array, payer: Uint8Array, opts?: {
        useStateRead?: boolean;
        verifiedIndex?: bigint;
        admission?: ReturnAdmission;
    }): Promise<ReturnPlan>;
    /**
     * Whether the gas model applies to the deployment: a model that says which deployments it is calibrated for (the default does) is shown
     * the verifier's runtime code (whose hash must be Γ's), the vault's (whose hash must be the manifest's), the code at the verifier's first
     * CREATE address (its helper) and the manifest's native gas schedule; a model that does not say is the wallet's own choice.
     */
    private gasApplies;
    /**
     * The section 12.5 preflight for burning `token` at index `a` to `recipient`, with a fresh endpoint estimate (c_obs = max(c, a); the
     * state read is an availability assumption, not evidence) and the payer's funds for the worst-case gas limit.
     */
    private preflight;
    private admitReturn;
    private verifyReturnAnchor;
    /** Authenticate the private request before a backup can submit it on another device. */
    private validatePendingReturn;
    /** Authenticate the backup and its optional terminal proof before committing a return. */
    importPendingReturn(snapshot: ReturnRecord, terminal?: Uint8Array, beforeCommit?: (verified: ReturnRecord, incoming: ReturnRecord) => Promise<void | null | NonNullable<ReturnRecord['recovery']>>, archives?: readonly EvmReader[], evidence?: ReturnEvidence): Promise<ReturnRecord>;
    private requireReturnArchive;
    private returnRecord;
    /**
     * Certify the terminal burn of a planned return: R signs the recipient, the amount and the index. The exact request is journaled
     * before certification, the certified burn before this returns; a second call resumes the same burn and never makes another.
     */
    burn(returnId: Uint8Array, owner?: OwnerSigner, admission?: ReturnAdmission, expectedRecipient?: Uint8Array, options?: ProofRecoveryOptions): Promise<{
        burned: Uint8Array;
        eta: Uint8Array;
        verdict: Verdict;
    }>;
    private burnInner;
    private certifyReturn;
    /**
     * Build the redeem transaction of a burned return: one SegmentSealed log per segment a .. c-1 from any provider, each checked
     * (length, order, M_j, head link from the journaled start head), the gap proofs, and the gas limit (expected cost plus gasReserve).
     * A missing or reordered log is missing evidence, never absence. Refuses with `CapacityExceeded` when the claim does not fit.
     */
    buildRedeem(returnId: Uint8Array, envelope?: RedeemOptions['envelope']): Promise<RedeemTx>;
    private requireRedeemable;
    private buildRedeemInner;
    /**
     * Send the redeem. Earlier sends are reconciled first (a pending one is never doubled; a landed one is the answer). Every signed
     * transaction is journaled before broadcast; an ambiguous broadcast is resolved by its receipt. A stale endpoint is rebuilt, never
     * the burn; failures are classified by error selector.
     */
    submitRedeem(returnId: Uint8Array, signer: EvmSigner, options?: RedeemOptions): Promise<ReconcileResult>;
    private submitRedeemInner;
    /**
     * Look for Paid(eta) and the receipts of every journaled send; never changes the burn. A Paid log counts only from the vault and only
     * once its receipt is verified under the block's EVM UC (section 6.2 steps 2 to 5): a provider that invents or withholds Paid can
     * delay the wallet, never stop its redemption.
     */
    reconcile(returnId: Uint8Array, archives?: readonly EvmReader[], evidence?: ReturnEvidence): Promise<ReconcileResult>;
    /** A final read-only check before signing a new settlement. */
    checkSettlement(returnId: Uint8Array, archives: readonly EvmReader[], recovery?: Uint8Array, observed?: Uint8Array): Promise<ReconcileResult>;
    private settlementGate;
    private pendingSettlements;
    private reconcileInner;
    private reconcileRecord;
    private findPaid;
    /** A return may sign again only after authenticating failure of its last exact send. */
    private reconcileSend;
    private exactFailure;
    /**
     * Verify that transaction `tx` paid this return: its Paid log, from the vault, with topics [Paid, eta, recipient] and data the amount,
     * in a receipt verified under the block's certificate. Journals `paid` and returns it; 'pending' while the block is not certified yet;
     * null when the claim does not verify (it is ignored).
     */
    private verifiedPaid;
    private recordPaid;
    /** Where every journaled deposit and return stands, in words. */
    status(): Promise<string[]>;
    private signed;
    private sendRecord;
    /** Broadcast and poll the receipt of the locally computed hash; null when none arrived in time (the send stays journaled). */
    private broadcastAndWait;
    /**
     * The outcome of a record's earlier sends: a success receipt (the answer), 'pending', or null (none is alive: a new send is safe).
     * The order defends against a send mined between reads and against load-balanced backends at different heights: the account's MINED
     * nonce is read first, then every send's receipt; a success receipt is the answer whenever it is seen. A send whose nonce is used
     * without a success receipt is dead only after the head has advanced `deadAfterBlocks` since that was first seen (journaled in
     * `nonceUsedAt`), the block at `nonceUsedAt` has a certificate (a found companion), and every receipt is read again; until then it
     * is pending. A send still in a pool is broadcast again (same bytes).
     */
    private landedSend;
}
export { lineageOf };
/**
 * An upper bound of the encoded [burn transfer, inclusion proof] pair with return data of `rLen` bytes: the transfer, the
 * certification data, the reference time, an RSMT path of at most 256 siblings and an aggregator UC at its decoder bound.
 */
export declare const burnPairBound: (rLen: number) => number;
/** Everything of the redeem transaction besides the evidence and the gap proofs: ABI heads and padding, the start head, the envelope. */
export declare const otherBytes: (evidence: number) => number;
export { encodeToken, log2, gapProofLen, decodeDepositProof };
