import { type Config, type Params } from './config.js';
import { type Predicate, type Token } from './token.js';
import { type TrustInput } from './trust.js';
/** The authenticated return tuple. */
export interface Verdict {
    domain: Uint8Array;
    eta: Uint8Array;
    minSegment: bigint;
    asset: Uint8Array;
    recipient: Uint8Array;
    amount: bigint;
}
/** The verifier's exact 192-byte return data. */
export declare function verdictAbi(v: Verdict): Uint8Array;
/** btid = H_U(C(b("UNICITY_NB2_BURN"), b(sidBurn), b(txHashBurn))). */
export declare const burnTransitionId: (sid: Uint8Array, txHash: Uint8Array) => Uint8Array;
/** eta = H_U(C(b("UNICITY_NB2_REDEMPTION"), b(D), b(btid))). */
export declare const redemptionId: (d: Uint8Array, btid: Uint8Array) => Uint8Array;
/** R = tag(39052, [1, b(D), b(asset32), b(recipient20), b(v), a]). */
export interface ReturnData {
    d: Uint8Array;
    asset: Uint8Array;
    recipient: Uint8Array;
    amount: bigint;
    minIndex: bigint;
}
export declare const encodeReturnData: (r: ReturnData) => Uint8Array;
/** evidence = C(1, Token). */
export declare const evidenceOf: (token: Uint8Array) => Uint8Array;
/** The verifier: the verdict, or the rule that refuses the evidence. */
export declare function verifyReturn(gamma: Uint8Array, evidence: Uint8Array, t: TrustInput, p: Params): Promise<Verdict>;
export declare function decodeEvidence(b: Uint8Array): Token;
export declare function verifyPart(c: Config, d: Uint8Array, t: TrustInput, part: Token): Promise<Verdict>;
/** A held (not burned) part: the same walk and every check of steps 3 to 5; its own transfers all go to signature owners with null data. */
export interface Held {
    tokenId: Uint8Array;
    amount: bigint;
    owner: Predicate;
}
export declare function verifyHeld(c: Config, d: Uint8Array, t: TrustInput, part: Token): Promise<Held>;
/** Fold (key, value) along the path (siblings root to leaf, bitmap bit d MSB-first) to `root`: the generic RSMT membership. */
export declare function rsmtMember(root: Uint8Array, key: Uint8Array, value: Uint8Array, bitmap: Uint8Array, siblings: Uint8Array[]): boolean;
/** Strictly decode R; any failure to be exactly a tag(39052, ...) R is `ReturnData`. */
export declare function decodeReturnData(b: Uint8Array | null): ReturnData;
