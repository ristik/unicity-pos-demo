import { Nb2Error, fail, type Rule } from './errors.js';
export declare const NATIVE_BRIDGE_PROTO_VERSION = 9;
export declare const TAG: {
    readonly predicate: 39032n;
    readonly mint: 39041n;
    readonly transfer: 39045n;
    readonly certification: 39031n;
    readonly token: 39040n;
    readonly inclusion: 39033n;
    readonly value: 39050n;
    readonly splitJustification: 39044n;
    readonly splitManifest: 39046n;
    readonly receiptBacking: 39051n;
    readonly segmentReturn: 39052n;
};
export declare const V2_VERSION = 1n;
export declare const DOMAIN: {
    readonly config: "UNICITY_NB2_CFG";
    readonly depositIntent: "UNICITY_NB2_DEPOSIT_INTENT";
    readonly depositSalt: "UNICITY_NB2_DEPOSIT_SALT";
    readonly burn: "UNICITY_NB2_BURN";
    readonly redemption: "UNICITY_NB2_REDEMPTION";
    readonly splitOutput: "UNICITY_SPLIT_OUTPUT";
};
/** a_UCT = H_U(UTF8("unicity-nb2-asset:native-uct")). */
export declare const ASSET_UCT: Uint8Array<ArrayBufferLike>;
export declare const MAX_DEPOSIT: bigint;
export declare const MAX_SEGMENT: bigint;
export declare const MAX_INDEX: bigint;
export declare const QMAX_LIMIT: bigint;
/** The largest K any build admits. */
export declare const MAX_K = 64n;
/** An admitted (K, B) set: production admits only (64, 16) (#1098); a test build admits K in {4, 8} x B in {2, 4}, never both. */
export interface Params {
    readonly K: readonly bigint[];
    readonly B: readonly bigint[];
}
export declare const PRODUCTION_PARAMS: Params;
export declare const TEST_PARAMS: Params;
export type Build = 'production' | 'test';
export declare const buildParams: (b: Build) => Params;
export declare const admits: (p: Params, k: bigint, b: bigint) => boolean;
/** log2 of a power of two. */
export declare const log2: (x: bigint) => number;
export interface Config {
    network: number;
    rootGenesis: Uint8Array;
    executionGenesis: Uint8Array;
    chainId: bigint;
    evmPartition: number;
    evmShard: Uint8Array;
    aggregatorPartition: number;
    vault: Uint8Array;
    asset: Uint8Array;
    ty: Uint8Array;
    aid: Uint8Array;
    semanticProfileHash: Uint8Array;
    verifier: Uint8Array;
    verifierCodeHash: Uint8Array;
    K: bigint;
    B: bigint;
    Qmax: bigint;
}
export declare const CONFIG_ARITY = 19;
export declare function encodeConfig(c: Config): Uint8Array;
/** D = H_U(Γ). */
export declare const domainOf: (gamma: Uint8Array) => Uint8Array;
/** A Γ failure naming the first failing field (19: the array itself). The verifier reports it as ConfigShape. */
export declare class ConfigError extends Nb2Error {
    readonly field: number;
    readonly cause: Nb2Error;
    constructor(field: number, cause: Nb2Error);
}
/** A canonical native shard ID: 1..33 bytes, a last byte that is nonzero (the terminator bit), at most 256 prefix bits. */
export declare function canonicalShardId(b: Uint8Array): boolean;
/** Strictly decode Γ under the admitted set `p` (every section 4.1 check that needs no deployment environment). */
export declare function decodeConfig(b: Uint8Array, p: Params): Config;
/** ty = H_U(UTF8("unicity-bridge:unicity-native-nb2:" + Dstr)). */
export declare const deriveType: (network: number, rootGenesis: Uint8Array, executionGenesis: Uint8Array, chainId: bigint) => Uint8Array;
/** aid = H_U(UTF8("unicity-bridge-coin:unicity-native-nb2:" + Dstr)). */
export declare const deriveCoin: (network: number, rootGenesis: Uint8Array, executionGenesis: Uint8Array, chainId: bigint) => Uint8Array;
/** What the vault constructor checks Γ against. */
export interface Environment {
    address: Uint8Array;
    chainId: bigint;
    verifierCodeHash: Uint8Array;
}
/** BadConfig(field). */
export declare class BadConfigError extends Nb2Error {
    readonly field: number;
    constructor(field: number);
}
/** The vault constructor's acceptance of Γ, in the reference's order. */
export declare function construct(gamma: Uint8Array, env: Environment, p: Params): Config;
/** A decoded Γ with its exact bytes and D. */
export interface Deployment {
    readonly gamma: Uint8Array;
    readonly cfg: Config;
    readonly domain: Uint8Array;
    /** h = log2 K, the gap-proof depth. */
    readonly h: number;
}
export declare function deployment(gamma: Uint8Array, p: Params): Deployment;
export type { Rule };
export { fail };
