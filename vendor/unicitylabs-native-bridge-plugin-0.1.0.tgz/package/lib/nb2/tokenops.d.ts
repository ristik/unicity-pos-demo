import type { SigningService } from '@unicitylabs/state-transition-sdk/lib/crypto/secp256k1/SigningService.js';
import { SumTree } from './split.js';
import { encodePredicate, type MintTx, type Predicate, type LineageLevel, type TransferTx } from './token.js';
import type { Deadline } from './cbor.js';
/** A Unicity owner key: its compressed public key and the 65-byte r||s||id unlock signature over a 32-byte message. */
export interface OwnerSigner {
    readonly publicKey: Uint8Array;
    signUnlock(message: Uint8Array): Promise<Uint8Array>;
}
/** An owner key held in memory. */
export declare function localOwner(privateKey: Uint8Array): OwnerSigner;
/** An owner key behind the SDK's signing service. */
export declare function sdkOwner(s: SigningService): OwnerSigner;
/** The aggregator: certify a request (exact CD bytes) and return its inclusion proof (exact bytes). Resubmitting must be harmless. */
export interface Aggregator {
    certify(request: Uint8Array): Promise<Uint8Array>;
}
/** The certification request of a mint: the universal minter's unlock over (h0, txHash). */
export declare function mintRequest(m: MintTx): {
    tx: Uint8Array;
    cd: Uint8Array;
};
/** Export a certified root. */
export declare const tokenOfMint: (tx: Uint8Array, proof: Uint8Array) => Uint8Array;
/** Add the child level to the exact signed records of the parent. */
export declare function tokenOfChild(parent: Uint8Array, allocation: Uint8Array, tx: Uint8Array, proof: Uint8Array): Uint8Array;
/** Preserve the exact signed bytes when appending a certified transfer. */
export declare function appendTransfer(token: Uint8Array, tx: Uint8Array, proof: Uint8Array): Uint8Array;
/** The current owner predicate and state of a decoded token. */
export declare function headOf(t: LineageLevel): {
    owner: Predicate;
    state: Uint8Array;
};
/** A transfer of `token` and its certification request, signed by the current owner. */
export declare function transferRequest(token: Uint8Array, owner: OwnerSigner, tr: TransferTx): Promise<{
    tx: Uint8Array;
    cd: Uint8Array;
}>;
/** A transfer pair is the one-byte CBOR array head and two inline items. */
export declare const transferProofLimit: (tx: Uint8Array) => number;
/** Certify and check that the proof fits its destination and matches exactly this request. */
export declare function certifyChecked(agg: Aggregator, cd: Uint8Array, maxBytes?: number): Promise<Uint8Array>;
/** A fresh 32-byte state mask. */
export declare const freshMask: () => Uint8Array;
export interface SplitOutput {
    ownerKey: Uint8Array;
    amount: bigint;
    salt: Uint8Array;
    deadline?: Deadline;
}
/** The fixed parts of a split: the manifest, its burn transfer, and each child's mint template (without its justification). */
export declare function splitPlan(parent: LineageLevel, outputs: SplitOutput[], ty: Uint8Array, aid: Uint8Array, mask: Uint8Array, deadline?: Deadline): {
    manifest: Uint8Array;
    burn: TransferTx;
    children: MintTx[];
    tree: SumTree;
    parentId: Uint8Array;
};
/** Prepare a child after the parent split verifier has derived its authenticated link. */
export declare function childMint(link: Uint8Array, tree: SumTree, child: MintTx): {
    mint: MintTx;
    allocation: Uint8Array;
};
export { encodePredicate };
