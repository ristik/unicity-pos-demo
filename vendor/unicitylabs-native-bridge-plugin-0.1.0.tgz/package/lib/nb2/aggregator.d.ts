import type { Aggregator } from './tokenops.js';
export interface SdkAggregatorOptions {
    apiKey?: string | null;
    allowInsecure?: boolean;
    pollMs?: number;
    timeoutMs?: number;
    sleep?: (ms: number) => Promise<void>;
}
/** The SDK's aggregator client: submit, then wait for the certified proof of exactly this request. */
export declare class SdkAggregator implements Aggregator {
    private readonly opts;
    private readonly client;
    constructor(url: string, opts?: SdkAggregatorOptions);
    certify(request: Uint8Array): Promise<Uint8Array>;
}
