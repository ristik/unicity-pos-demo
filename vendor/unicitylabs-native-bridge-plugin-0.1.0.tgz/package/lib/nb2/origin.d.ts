import type { AuthenticatedOrigin, TrustInput } from './trust.js';
/** Taken from the independently selected release, including its SHA-256 pin. */
export interface Nb2OriginBinding {
    network: number;
    generation: string;
    genesisHash: string;
    releaseSha256: string;
}
export interface Nb2OriginCheckpoint extends AuthenticatedOrigin {
    blockHash: string;
    blockNumber: number;
}
/** Maximum UTF-8 size of the complete `nb2-origin.json` response body. */
export declare const MAX_NB2_ORIGIN_BYTES = 4096;
/**
 * Decode and validate UTF-8 bytes fetched over the operator's authenticated HTTPS channel.
 * Start with the pinned release's checkpoint, then use the last accepted checkpoint
 * as `held`. The caller persists it and returns `trust` from the existing refresh hook.
 */
export declare function refreshNb2Origin(trust: TrustInput, binding: Nb2OriginBinding, held: Nb2OriginCheckpoint, bytes: Uint8Array): {
    trust: TrustInput;
    checkpoint: Nb2OriginCheckpoint;
};
