export declare const JOURNAL_FORMAT = "unicity-nb2-journal";
export declare const JOURNAL_VERSION = 1;
/**
 * Durable key-value storage. `putIf` is a compare-and-swap: it writes `value` only when the stored value is exactly `expected` (null:
 * absent) and reports whether it did; it must not resolve before the value survives a crash. Two wallets (or two processes) sharing a
 * store therefore never both advance the same record: the second write is refused and the plug-in stops with `JournalConflict`.
 */
export interface JournalStore {
    get(key: string): Promise<string | null>;
    putIf(key: string, expected: string | null, value: string): Promise<boolean>;
    list(prefix: string): Promise<string[]>;
}
export declare class MemoryJournalStore implements JournalStore {
    readonly map: Map<string, string>;
    get(key: string): Promise<string | null>;
    putIf(key: string, expected: string | null, value: string): Promise<boolean>;
    list(prefix: string): Promise<string[]>;
}
export type Hex = string;
export type Dec = string;
/** A signed EVM transaction the wallet broadcast (or is about to). */
export interface SendRecord {
    hash: Hex;
    raw: Hex;
    nonce: Dec;
    gas: Dec;
    at: Dec;
    /** The head block when a mined transaction of the account was first seen past this nonce without this send's success receipt. */
    nonceUsedAt?: Dec;
}
interface Base {
    format: typeof JOURNAL_FORMAT;
    version: typeof JOURNAL_VERSION;
    domain: Hex;
}
export interface IntentsRecord extends Base {
    kind: 'intents';
    /** The wallet-versioned derivation of k_w from the seed, e.g. "nb2-hmac-sha256-v1". */
    keyScheme: string;
    next: Dec;
}
export type DepositStatus = 'planned' | 'submitted' | 'deposited' | 'proven' | 'minted';
export interface DepositRecord extends Base {
    kind: 'deposit';
    keyScheme: string;
    intent: Dec;
    amount: Dec;
    /** The first owner's compressed key and its 42-byte predicate. */
    ownerKey: Hex;
    firstOwner: Hex;
    rho: Hex;
    status: DepositStatus;
    /** The intent's high-water mark has been handed to the wallet's backup (section 12.1). */
    backedUp: boolean;
    sends: SendRecord[];
    /** The transaction that executed the deposit, its block and the vault's deposit number. */
    depositTx?: Hex;
    blockNumber?: Dec;
    depositNumber?: Dec;
    /** The DepositProof container and the mint reason J. */
    receiptProof?: Hex;
    reason?: Hex;
    /** The certified token. */
    token?: Hex;
    /** Optional: r itself, when the wallet backs up secrets rather than the high-water mark. */
    secret?: Hex;
    /** The head block when the plan was made: a deposit carrying this rho is looked for from here before the first send. */
    plannedBlock?: Dec;
    /**
     * Every Deposited event seen with this rho (a faulty wallet that reused r, or two devices). The first is the record's own deposit;
     * each further one is a separate root token (its own n), minted with `mintExtraDeposit`.
     */
    seenDeposits?: {
        tx: Hex;
        depositNumber: Dec;
        blockNumber: Dec;
        amount: Dec;
        firstOwner: Hex;
        token?: Hex;
    }[];
}
export type SplitStatus = 'planned' | 'burn-requested' | 'burned' | 'minted';
export interface SplitOutputRecord {
    ownerKey: Hex;
    amount: Dec;
    salt: Hex;
    token: Hex | null;
}
export interface SplitRecord extends Base {
    kind: 'split';
    splitId: Hex;
    source: Hex;
    outputs: SplitOutputRecord[];
    mask: Hex;
    status: SplitStatus;
    /** The manifest burn transaction and its certification request, journaled before the first submission. */
    burnTx?: Hex;
    burnRequest?: Hex;
    burned?: Hex;
}
export type ReturnStatus = 'planned' | 'burn-requested' | 'burned' | 'submitted' | 'paid';
export interface ReturnRecord extends Base {
    kind: 'return';
    returnId: Hex;
    /** The held part before its burn. */
    source: Hex;
    amount: Dec;
    recipient: Hex;
    /** The signed minimum segment index and the start head it came with (H_{j+1} of the seal receipt, or H_0). */
    a: Dec;
    startHead: Hex;
    /** The block of the seal receipt that gave `a` (the deployment block when there was none): history logs are read from here. */
    fromBlock: Dec;
    /** The verified seal receipt (a DepositProof container), absent when a = 0. */
    sealReceipt?: Hex;
    status: ReturnStatus;
    burnTx?: Hex;
    burnRequest?: Hex;
    /** The certified burned part: the redeem evidence's token. */
    burned?: Hex;
    eta?: Hex;
    sends: SendRecord[];
    /** The EVM account that pays the redeem's gas (its funds are checked before the burn). */
    payer?: Hex;
    /** The first block at which a redeem was broadcast: Paid(eta) cannot appear before it. */
    firstSendBlock?: Dec;
    paid?: {
        txHash: Hex;
        blockNumber: Dec;
    };
}
export type AnyRecord = IntentsRecord | DepositRecord | SplitRecord | ReturnRecord;
export declare const hex: (b: Uint8Array) => Hex;
export declare function unhex(s: Hex): Uint8Array;
export declare const dec: (v: bigint | number) => Dec;
export declare function undec(s: Dec): bigint;
/** The typed journal over a store, keyed by deployment. */
export declare class Journal {
    readonly store: JournalStore;
    readonly domain: Uint8Array;
    readonly prefix: string;
    /** The stored text of every record this instance last read or wrote: the `expected` of its next compare-and-swap. */
    private readonly seen;
    constructor(store: JournalStore, domain: Uint8Array);
    private key;
    /**
     * Read a record. Only a read `forUpdate` (taken under the key's lock, by the operation that then writes the record) sets the
     * `expected` of the next compare-and-swap; any other read leaves it alone, so an unlocked reader (`status`, a listing, a wallet's
     * own look) can never move a locked operation's comparison past another process's write.
     */
    private read;
    /** Write a record and read it back: the plug-in proceeds only on a record that is in the store. */
    private write;
    base(): Base;
    intents(): Promise<IntentsRecord | null>;
    /** The intents record, read for the write that follows (under its lock). */
    intentsForUpdate(): Promise<IntentsRecord | null>;
    putIntents(r: IntentsRecord): Promise<void>;
    deposit(i: bigint): Promise<DepositRecord | null>;
    depositForUpdate(i: bigint): Promise<DepositRecord | null>;
    putDeposit(r: DepositRecord): Promise<void>;
    deposits(): Promise<DepositRecord[]>;
    split(id: Hex): Promise<SplitRecord | null>;
    splitForUpdate(id: Hex): Promise<SplitRecord | null>;
    putSplit(r: SplitRecord): Promise<void>;
    ret(id: Hex): Promise<ReturnRecord | null>;
    retForUpdate(id: Hex): Promise<ReturnRecord | null>;
    putReturn(r: ReturnRecord): Promise<void>;
    returns(): Promise<ReturnRecord[]>;
}
/**
 * The `putIf` contract every wallet journal store must meet, as a check any store can run (its own tests, or a wallet's start-up
 * self-test against a scratch location). `fresh` opens an empty store; `reopen` opens the same storage again (a new process after a
 * crash would). It checks the compare-and-swap (one write against absence wins, a stale or absent expectation loses and changes
 * nothing), atomicity (of `writers` concurrent writes against one text exactly one wins and its value is stored), persistence (a
 * reopened store reads back every won write) and `list` (sorted keys of a prefix). Throws on the first violation.
 */
export declare function checkJournalStore<S extends JournalStore>(fresh: () => Promise<S> | S, reopen: (s: S) => Promise<S> | S, writers?: number): Promise<void>;
export {};
