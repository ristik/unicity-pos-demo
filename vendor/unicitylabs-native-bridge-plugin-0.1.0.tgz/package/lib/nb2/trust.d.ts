/**
 * Historical authority (section 11.3; bft-core `nb2ref/trust.go`). The trust input is the network's Unicity Trust Base history (the
 * SDK's `TrustBaseHistory`, installed from a release bundle and pinned by its genesis EntryID, `Γ.rootGenesis32`). Every UC is
 * judged under the entry of its own seal epoch by the upstream seal rule: an unknown signer or a signature that fails the weighting
 * rule counts zero, the weights reach floor(2W/3)+1 of that entry, and no legacy pre-scan rejects a seal for a signature's length or
 * recovery byte.
 */
import { ShardId } from '@unicitylabs/state-transition-sdk/lib/api/bft/ShardId.js';
import { UnicityCertificate } from '@unicitylabs/state-transition-sdk/lib/api/bft/UnicityCertificate.js';
import { TrustInput } from '../trust.js';
import type { Config } from './config.js';
export { TrustInput };
/** The B1 bound of one certificate's bytes (b1ref.MaxUCBytes). */
export declare const MAX_B1_UC_BYTES = 24576;
/** The history must be the one Γ names: its genesis EntryID is rootGenesis32 and its network Γ's. */
export declare function bindTrust(t: TrustInput, c: Config): void;
/** The bounded certificate scan and the canonical decode; every failure is `UnsupportedCertificateEncoding`. */
export declare function decodeUc(raw: Uint8Array): UnicityCertificate;
export declare function isCertificationTrustPending(error: unknown): boolean;
/**
 * One UC for the expected partition and shard, in the order of bft-core `nb2ref` (after the NB2-05 UC order): the seal's network
 * (`SealNetwork`), the structure (`CertStructure`: partition, shard, input record, a 32-byte ShardConfHash), the shard and unicity tree
 * folds over the UC's own ShardConfHash to the seal hash (`SealRoot`), then the entry of the seal's epoch (`NoEntryForEpoch`,
 * `SealEpoch`) and the quorum under it (`QuorumNotMet`). No expected configuration hash is supplied.
 */
export declare function ucCheck(t: TrustInput, uc: UnicityCertificate, partition: number, shard: Uint8Array): Promise<void>;
/**
 * A deposit or seal receipt's EVM certificate for exactly (Γ.evmPartition, Γ.evmShard). Certificate failures are wrapped in `DepositUC`.
 * Trust binding and retryable `NoEntryForEpoch` keep their own errors.
 */
export declare function verifyEvmUc(t: TrustInput, raw: Uint8Array, c: Config): Promise<UnicityCertificate>;
/** Whether a state ID falls in a shard's key range (the shard ID's bits are a prefix of the ID's). */
export declare function inShard(shard: ShardId, sid: Uint8Array): boolean;
/** For one complete seal and shard, canonical UC equality implies exact B1 claim equality. */
export declare function claimConsistency(): (uc: UnicityCertificate, raw: Uint8Array) => void;
