import { type Config, type Environment, type Params } from './config.js';
import { Nb2Error } from './errors.js';
export type VaultEvent = {
    name: 'Deposited';
    n: bigint;
    amount: bigint;
    rho: Uint8Array;
    firstOwner: Uint8Array;
} | {
    name: 'Paid';
    eta: Uint8Array;
    recipient: Uint8Array;
    amount: bigint;
} | {
    name: 'SegmentSealed';
    segment: bigint;
    before: Uint8Array;
    after: Uint8Array;
    ids: Uint8Array[];
};
export type RecipientBehaviour = 'accepts' | 'reverts' | 'reenters-redeem' | 'reenters-deposit';
/** The mock verifier's answer: a revert with that data, or its return data. */
export type VerifierAnswer = {
    revert: Uint8Array;
} | {
    ret: Uint8Array;
};
export interface RedeemOutcome {
    inner: Nb2Error | null;
}
export declare class VaultModel {
    readonly gamma: Uint8Array;
    readonly cfg: Config;
    readonly d: Uint8Array;
    A: bigint;
    T: [bigint[], bigint[]];
    S: [Uint8Array[], Uint8Array[]];
    head: Uint8Array;
    prev: Uint8Array;
    events: VaultEvent[];
    private entered;
    constructor(gamma: Uint8Array, env: Environment, p: Params, cfg?: Config);
    get n(): bigint;
    get c(): bigint;
    get m(): bigint;
    get q(): bigint;
    private tagAt;
    private setTag;
    /** The live identifiers of the current and previous buffer, in arrival order. */
    liveIds(): {
        current: Uint8Array[];
        previous: Uint8Array[];
    };
    /** The state() view. */
    state(): {
        deposits: bigint;
        segment: bigint;
        population: bigint;
        outstanding: bigint;
        head: Uint8Array;
        previousHead: Uint8Array;
    };
    deposit(value: bigint, firstOwner: Uint8Array, rho: Uint8Array): void;
    /** redeem(evidence, claimedEta, claimedStart, history) with the verifier's answer and the recipient's behaviour; a failure reverts all. */
    redeem(eta: Uint8Array, a: bigint, history: Uint8Array, ver: VerifierAnswer, rcp?: RecipientBehaviour): RedeemOutcome;
    private redeemInner;
    private tryInner;
    private seal;
    private snapshot;
    private restore;
    /** An independent copy of this vault's state (for simulating a call without effects). */
    copy(): VaultModel;
    /** The test harness's storage injection (states no sequence can reach). */
    setState(n: bigint, c: bigint, m: bigint, q: bigint, head: Uint8Array, prev: Uint8Array, current: Uint8Array[], previous: Uint8Array[]): void;
}
/** The longest verifier revert the vault relays as VerifierRefused(revertData). */
export declare const MAX_VERIFIER_REVERT = 1024;
/** words(K, B) = ceil(K / floor(256 / log2 B)). */
export declare function tagWords(K: bigint, B: bigint): number;
/** The verifier's return data: exactly 192 canonical bytes (uint64 and address words with zero high bytes). */
export declare function decodeVerdictAbi(b: Uint8Array): {
    domain: Uint8Array;
    eta: Uint8Array;
    minSegment: bigint;
    asset: Uint8Array;
    recipient: Uint8Array;
    amount: bigint;
} | null;
