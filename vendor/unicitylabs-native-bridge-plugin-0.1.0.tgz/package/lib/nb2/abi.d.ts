import { type Rule } from './errors.js';
export declare const SELECTOR: {
    readonly deposit: Uint8Array<ArrayBufferLike>;
    readonly redeem: Uint8Array<ArrayBufferLike>;
    readonly domain: Uint8Array<ArrayBufferLike>;
    readonly config: Uint8Array<ArrayBufferLike>;
    readonly state: Uint8Array<ArrayBufferLike>;
    readonly verifyReturn: Uint8Array<ArrayBufferLike>;
};
/** The vault errors with arguments (section 13.3); every other rule is `<Name>()`. */
export declare const ERROR_SIGNATURES: Partial<Record<Rule, string>>;
export declare const signatureOf: (r: Rule) => string;
export declare const selectorOf: (r: Rule) => Uint8Array;
/** Standard ABI of (static words..., dynamic bytes...) arguments given in order, each a word or bytes. */
export declare function abiEncode(args: ({
    word: Uint8Array;
} | {
    bytes: Uint8Array;
})[]): Uint8Array;
/** The exact revert data of a vault or verifier rule with its arguments (words as bigint or 32 bytes, `bytes` as Uint8Array). */
export declare function revertData(r: Rule, ...vals: (bigint | Uint8Array)[]): Uint8Array;
export declare const depositCalldata: (firstOwner: Uint8Array, rho: Uint8Array) => Uint8Array;
export declare const redeemCalldata: (evidence: Uint8Array, claimedEta: Uint8Array, claimedStart: bigint, history: Uint8Array) => Uint8Array;
/** The calldata length of a redeem with `evidence` bytes and `history` bytes (selector, four heads, two length words, padding). */
export declare const redeemCalldataLength: (evidence: number, history: number) => number;
export interface VaultState {
    deposits: bigint;
    segment: bigint;
    population: bigint;
    outstanding: bigint;
    head: Uint8Array;
    previousHead: Uint8Array;
}
export declare function decodeStateReturn(b: Uint8Array): VaultState;
/** A `bytes` return (config()). */
export declare function decodeBytesReturn(b: Uint8Array): Uint8Array;
/** A decoded vault or verifier error. */
export interface DecodedError {
    rule: Rule;
    args: (bigint | Uint8Array)[];
    raw: Uint8Array;
    inner?: DecodedError;
}
/** Decode revert data by selector; null for data that names no rule (an out-of-gas or a plain revert). */
export declare function decodeRevert(data: Uint8Array): DecodedError | null;
/** What the wallet does about a failed redeem (section 13.3 and the guide's failure table). */
export type RedeemAction = 'reconcile' | 'rebuild-history' | 'wait' | 'repair-proof' | 'retry-later' | 'stop';
export declare function classifyRedeemError(e: DecodedError | null): RedeemAction;
/** A log as an RPC returns it. */
export interface RawLog {
    address: Uint8Array;
    topics: Uint8Array[];
    data: Uint8Array;
    blockNumber: bigint;
    blockHash: Uint8Array;
    transactionHash: Uint8Array;
    logIndex: bigint;
    removed?: boolean;
}
export declare function decodeDeposited(l: RawLog): {
    n: bigint;
    domain: Uint8Array;
    amount: bigint;
    rho: Uint8Array;
    firstOwner: Uint8Array;
} | null;
export declare function decodePaid(l: RawLog): {
    eta: Uint8Array;
    recipient: Uint8Array;
    amount: bigint;
} | null;
