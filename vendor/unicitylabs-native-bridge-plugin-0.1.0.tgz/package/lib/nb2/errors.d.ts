/**
 * The rejection rules of the native bridge v2 specification (bft-core `docs/design/native-bridge-v2.md` section 14), one name each.
 * The Go reference (bft-core `nb2ref`, NB2-03) uses `Err<Name>`; the on-chain verifier reverts with `<Name>()`; the vault's names and
 * selectors are those of section 13.3. The plug-in's own refusals that are not section 14 rules (a journal that is not persisted, a
 * plain RPC index on a production deployment, a recipient refused by wallet policy) are {@link WalletError}s.
 */
export declare const RULES: {
    readonly '14.1': readonly ["Truncated", "Trailing", "NonCanonical", "Shape", "Tag", "Version", "Length", "IntRange", "InputTooLarge", "ConfigShape", "EvidenceShape"];
    readonly '14.2': readonly ["MintDomain", "DepositUC", "DepositHeader", "ReceiptPath", "ReceiptType", "ReceiptStatus", "LogIndex", "LogEmitter", "LogTopics", "LogData", "SecretOpening", "MintSalt", "MintType", "MintOwner", "MintData", "MintReason"];
    readonly '14.3': readonly ["NotBurn", "BurnNotFinal", "BurnReason", "ReturnData", "ReturnDomain", "ReturnAsset", "ReturnAmount", "ReturnRecipient", "ReturnIndex"];
    readonly '14.4': readonly ["Predicate", "MintShape", "TransferData", "CDMismatch", "UnlockLength", "UnlockScalars", "UnlockRecovery", "UnlockKey", "RepeatedSID", "NoTransfers", "DeadlineMismatch", "DeadlineExpired", "InclusionProof", "ReferenceTime", "SealNetwork", "SealEpoch", "NoEntryForEpoch", "CertStructure", "SealRoot", "QuorumNotMet", "UnsupportedCertificateEncoding", "SplitJustif", "SplitProofCount", "SplitProofShape", "SplitManifest", "SplitBurn", "SplitProof", "SplitSum"];
    readonly '14.5': readonly ["BadHistoryLength", "FutureIndex", "StaleEndpoint", "BadGapProof", "ChainMismatch", "AlreadyPaid", "VerifierRefused", "VerifierBadReturn", "DomainMismatch", "AssetMismatch", "ClaimMismatch", "BadRecipient", "ZeroAmount", "LiabilityUnderflow", "SegmentCounterExhausted", "PayoutFailed", "Reentrancy", "ZeroValue", "BadFirstOwner", "LiabilityCap", "DepositCounterExhausted", "BadConfig"];
    readonly '14.6': readonly ["SealReceipt", "SegmentLog", "CapacityPreflight", "CapacityExceeded", "ImplausibleIndex", "EvidencePruned"];
};
export type Rule = (typeof RULES)[keyof typeof RULES][number];
/** Every rule, in section 14 order. */
export declare const ALL_RULES: readonly Rule[];
/** Offline verification can retry once the trust history holds the seal's epoch. */
export declare const RETRYABLE_RULES: readonly Rule[];
/** The deployed verifier cannot distinguish a pending seal import from an invalid quorum. */
export declare function isRetryableVerifierRefusal(inner: Rule | undefined): boolean;
/**
 * A section 14 refusal. `args` are a vault error's arguments as the vectors write them (decimal or `0x` hex); `inner` is the rule a
 * wrapper (`SealReceipt`, `SegmentLog`) carries.
 */
export declare class Nb2Error extends Error {
    readonly rule: Rule;
    readonly detail?: string | undefined;
    readonly args?: string[] | undefined;
    readonly inner?: Nb2Error | undefined;
    constructor(rule: Rule, detail?: string | undefined, args?: string[] | undefined, inner?: Nb2Error | undefined);
    /** Retry after trust-history refresh or, for an ambiguous on-chain refusal, after seal import. */
    get retryable(): boolean;
    /** The innermost rule of a wrapper chain. */
    get innermost(): Rule;
}
export declare function fail(rule: Rule, detail?: string): never;
export declare function failArgs(rule: Rule, ...args: (bigint | number | string)[]): never;
/** `outer` carrying `inner` (a {@link Nb2Error}) as its cause; any other throw passes through. */
export declare function wrap(outer: Rule, e: unknown): never;
/**
 * Non-rule outcomes the plug-in reports (section 14.6 names a few of them without a rule: a `state()` read without `stateReadOnly`,
 * an unknown or malformed seal companion), and the plug-in's own safety refusals of NB2-07.
 */
export type WalletReason = 'StateReadNotAdmitted' | 'CompanionUnknown' | 'CompanionProvider' | 'TrustSyncRequired' | 'ImportLag' | 'TrustInput' | 'JournalNotPersisted' | 'JournalConflict' | 'RecipientRefused' | 'NotPending' | 'EvidenceMissing' | 'ProviderFault' | 'AlreadyPaid' | 'Unconfirmed' | 'Reverted' | 'InsufficientFunds' | 'BadDeployment' | 'PolicyRequired' | 'BadInput';
export declare class WalletError extends Error {
    readonly reason: WalletReason;
    readonly cause?: unknown | undefined;
    constructor(reason: WalletReason, detail?: string, cause?: unknown | undefined);
    get retryable(): boolean;
}
export declare function refuse(reason: WalletReason, detail?: string, cause?: unknown): never;
/** The rule (or wallet reason) an error names, for vector comparisons and logs. */
export declare function nameOf(e: unknown): string;
