/**
 * Return proof assembly and aggregator refresh.
 *
 * Refresh keeps the original `M/T` (including embedded J), CD and original `t` byte for byte and
 * replaces only the aggregator path and certificate, within the one fixed trust base. Fetching is
 * the host's concern: this module only consumes proofs.
 */
import type { InclusionProof } from '@unicitylabs/state-transition-sdk/lib/api/InclusionProof.js';
import { Token } from '@unicitylabs/state-transition-sdk/lib/transaction/Token.js';
import { type Envelope } from './envelope.js';
import { type Gate } from './gas.js';
import type { Deployment } from './deployment.js';
import type { NativeBridge, VerifiedToken } from './verifier.js';
/**
 * Replace every aggregator proof of `token` with the freshly fetched proof for the same leaf.
 * `fresh` is ordered like the history, genesis first.
 */
export declare function refreshToken(token: Token, fresh: InclusionProof[]): Promise<Token>;
/**
 * Assemble the return envelope from a token whose every aggregator proof carries its own (path, UC)
 * pair. The token is verified in full as a return first.
 *
 * The anchor table is the profile's: one anchor per distinct complete UC (byte-identical UCs are one
 * anchor), in first-use leaf order, each claim read from its own UC (its shard, shard configuration
 * hash and partition: the policy names only the partition, and the UC authenticates the rest). Nothing
 * here re-queries to make certificates converge: the pairs are used as fetched, and an envelope that
 * needs more anchors than the profile bound is `ErrTooManyPaths` (BudgetExceeded), never truncated or
 * split. The returned `gate` is the gas estimate the redemption should be sent with; it is never a
 * refusal (owner section 36).
 */
export declare function buildReturnProof(bridge: NativeBridge, token: Token, witnesses?: InclusionProof[]): Promise<{
    envelope: Envelope;
    encoded: Uint8Array;
    verified: VerifiedToken;
    gate: Gate;
}>;
/**
 * The envelope of a history and one witness per leaf, in leaf order: the anchor table (one anchor per distinct complete UC, in first-use
 * order, each claim read from its own UC) and the leaf paths. Assembly only: nothing is verified here ({@link buildReturnProof} verifies
 * the token first and checks the result), so a caller can also assemble what the chain must refuse (the live lane's negatives).
 */
export declare function assembleEnvelope(dep: Deployment, history: Uint8Array, proofs: readonly InclusionProof[]): {
    envelope: Envelope;
    encoded: Uint8Array;
};
/**
 * An upper bound on the size of the burn leaf's contribution to the history projection (the transfer, its
 * certification data with its unlock script and the terminal return reason).
 */
export declare const BURN_HISTORY_BYTES = 1024;
/**
 * The burn-time preflight. A burn that could never be redeemed under the resource policy is refused before
 * the wallet burns anything: an envelope over the ingress bound (`ErrInputTooLarge`, BudgetExceeded), never a
 * truncated history or a partial redemption. The composition streams the history, so no leaf count is refused. There is no gas ceiling (owner section 36): the returned best-case estimate is only that.
 * `tokenBytes` is the held receipt the burn would spend.
 */
export declare function preflightBurn(bridge: NativeBridge, tokenBytes: Uint8Array, shards?: number): Promise<Gate>;
/**
 * The size refusal of the preflight and its best-case estimate, on the projection's inputs. The composition
 * has no history bound of its own: the only refusal is the envelope (the ingress bound), which no refresh can
 * fix, so it errs safe: the burn leaf is assumed to add up to `BURN_HISTORY_BYTES` to the best-case envelope.
 * The estimate uses the known history only, a lower bound.
 */
export declare function checkBurnProjection(cfgLen: number, policyLen: number, leaves: number, history: number, anchors?: number): Gate;
/** The raw 32-byte state ID of every history leaf (genesis first): what `get_inclusion_proof.v2` is asked for. */
export declare function leafStateIds(token: Token): Promise<Uint8Array[]>;
