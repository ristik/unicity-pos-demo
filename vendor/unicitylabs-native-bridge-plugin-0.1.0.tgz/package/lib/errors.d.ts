/** Failure family: malformed encoding, relation outside the profile or wrong, or a budget. */
export type NativeFamily = 'malformed' | 'invalid' | 'budget' | 'unavailable';
/**
 * Sentinel names shared with the Rust crate and the Go oracle (`Err` + name). Every identity a test
 * asserts is one of these.
 */
declare const FAMILY: {
    readonly ErrTruncated: "malformed";
    readonly ErrTrailing: "malformed";
    readonly ErrNonCanonical: "malformed";
    readonly ErrForbiddenCBOR: "malformed";
    readonly ErrShape: "malformed";
    readonly ErrTag: "malformed";
    readonly ErrVersion: "malformed";
    readonly ErrLength: "malformed";
    readonly ErrIntRange: "malformed";
    readonly ErrABIFraming: "malformed";
    readonly ErrBadOperation: "malformed";
    readonly ErrRlpMalformed: "malformed";
    readonly ErrSdkDecode: "malformed";
    readonly ErrDeadline: "malformed";
    readonly ErrInputTooLarge: "budget";
    readonly ErrTooManyTx: "budget";
    readonly ErrTooManyItems: "budget";
    readonly ErrTooDeep: "budget";
    readonly ErrTooManyPaths: "budget";
    readonly ErrProofTooLarge: "budget";
    readonly ErrJustificationTooLarge: "budget";
    readonly ErrLockProofTooLarge: "budget";
    readonly ErrCfgMismatch: "invalid";
    readonly ErrPolicyHash: "invalid";
    readonly ErrPolicyTuple: "invalid";
    readonly ErrPolicyAnchors: "invalid";
    readonly ErrPolicyLeafIndex: "invalid";
    readonly ErrPolicyLeafCount: "invalid";
    readonly ErrPolicyPartition: "invalid";
    readonly ErrPathBitmap: "invalid";
    readonly ErrAnchorAuth: "invalid";
    readonly ErrPredicate: "invalid";
    readonly ErrMintShape: "invalid";
    readonly ErrMintJustif: "invalid";
    readonly ErrMintSalt: "invalid";
    readonly ErrMintType: "invalid";
    readonly ErrMintData: "invalid";
    readonly ErrTransferData: "invalid";
    readonly ErrCDMismatch: "invalid";
    readonly ErrUnlock: "invalid";
    readonly ErrUnlockLength: "invalid";
    readonly ErrUnlockScalars: "invalid";
    readonly ErrUnlockRecovery: "invalid";
    readonly ErrUnlockKey: "invalid";
    readonly ErrMinterKey: "invalid";
    readonly ErrRepeatedSID: "invalid";
    readonly ErrNoTransfers: "invalid";
    readonly ErrHasTransfers: "invalid";
    readonly ErrBurnNotFinal: "invalid";
    readonly ErrNotBurn: "invalid";
    readonly ErrBurnReason: "invalid";
    readonly ErrReturnData: "invalid";
    readonly ErrReturnAmount: "invalid";
    readonly ErrReturnRecip: "invalid";
    readonly ErrLockInput: "invalid";
    readonly ErrZeroDigest: "invalid";
    readonly ErrDeadlineMismatch: "invalid";
    readonly ErrDeadlineExpired: "invalid";
    readonly ErrReferenceTimeFuture: "invalid";
    readonly ErrInputRecordMismatch: "invalid";
    readonly ErrUnexpectedBurn: "invalid";
    readonly ErrRefreshMismatch: "invalid";
    readonly ErrProofUnavailable: "unavailable";
    readonly ErrIssuanceReason: "invalid";
    readonly ErrIssuanceData: "invalid";
    readonly ErrIssuanceSplit: "invalid";
    readonly ErrUnknownDeployment: "invalid";
    readonly ErrAmbiguousDeployment: "invalid";
    readonly ErrNetworkMismatch: "invalid";
    readonly ErrTrustBase: "invalid";
    readonly ErrSdkVerification: "invalid";
    readonly ErrSealEpoch: "invalid";
    readonly ErrNoEntryForEpoch: "unavailable";
    readonly ErrTrustBaseDigest: "invalid";
    readonly ErrUnsupportedCertificateEncoding: "invalid";
    readonly ErrSealNetwork: "invalid";
    readonly ErrSealRoot: "invalid";
    readonly ErrQuorumNotMet: "invalid";
    readonly ErrCertStructure: "invalid";
    readonly ErrNotAdmitted: "invalid";
    readonly ErrShardMismatch: "invalid";
    readonly ErrPathInvalid: "invalid";
    readonly ErrMissingBacking: "invalid";
    readonly ErrLockProofShape: "invalid";
    readonly ErrLockProofCfg: "invalid";
    readonly ErrLockProofTrust: "invalid";
    readonly ErrEvmPartition: "invalid";
    readonly ErrEvmShard: "invalid";
    readonly ErrEvmConfigHash: "invalid";
    readonly ErrEvmConfigPin: "invalid";
    readonly ErrHeaderHash: "invalid";
    readonly ErrHeaderRoot: "invalid";
    readonly ErrHeaderProfile: "invalid";
    readonly ErrAccountProof: "invalid";
    readonly ErrAccountCode: "invalid";
    readonly ErrStorageProof: "invalid";
    readonly ErrStorageValue: "invalid";
    readonly ErrLockDigest: "invalid";
    readonly ErrLockUC: "invalid";
    readonly ErrLockPDR: "invalid";
    readonly ErrLockHeader: "invalid";
    readonly ErrLockAccount: "invalid";
    readonly ErrLockCodeHash: "invalid";
    readonly ErrLockStorage: "invalid";
    readonly ErrMPTNode: "invalid";
    readonly ErrMPTPath: "invalid";
    readonly ErrMPTAbsent: "invalid";
    readonly ErrMPTExtraneous: "invalid";
    readonly ErrManifest: "invalid";
    readonly ErrCertScan: "malformed";
    readonly ErrCertSigLength: "malformed";
    readonly ErrIROpening: "invalid";
    readonly ErrIRShape: "invalid";
    readonly ErrIRState: "invalid";
    readonly ErrIRTime: "invalid";
    readonly ErrLeafProof: "invalid";
    readonly ErrSplitJustif: "invalid";
    readonly ErrSplitProofCount: "invalid";
    readonly ErrSplitProofShape: "invalid";
    readonly ErrSplitManifest: "invalid";
    readonly ErrSplitBurn: "invalid";
    readonly ErrSplitProof: "invalid";
    readonly ErrSplitSum: "invalid";
};
export type NativeReason = keyof typeof FAMILY;
/** A native profile failure; `reason` is the shared sentinel name. */
/**
 * Failures a host may retry later: a racing or mismatched (path, UC) pair that survived the bounded
 * retries, never a failure of the token or of the profile bounds.
 */
export declare const RETRYABLE: readonly NativeReason[];
export declare class NativeError extends Error {
    readonly reason: NativeReason;
    readonly detail?: string | undefined;
    readonly family: NativeFamily;
    /**
     * A diagnostic, never a protocol input: for a retryable refusal why it happened (for `ErrProofUnavailable`: why the proof could not be had in
     * time); for a refusal named by the oracle's canonical reason, the plug-in's finer one (a lock proof's `ErrLockUC` from `ErrQuorumNotMet`).
     */
    constructor(reason: NativeReason, detail?: string | undefined);
}
/** Throw a profile error. */
export declare function fail(reason: NativeReason, detail?: string): never;
export {};
