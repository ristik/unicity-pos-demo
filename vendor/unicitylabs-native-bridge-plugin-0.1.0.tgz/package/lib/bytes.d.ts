export declare function concat(...parts: Uint8Array[]): Uint8Array;
export declare function eq(a: Uint8Array, b: Uint8Array): boolean;
export declare function toHex(b: Uint8Array): string;
/** Strict lowercase/uppercase hex of even length; returns null on any other input. */
export declare function fromHex(s: string): Uint8Array | null;
export declare function u8(...xs: number[]): Uint8Array;
