import type { HeaderProfile } from './header.js';
import { cfgBytes, type Cfg, type Policy } from './profile.js';
/** One allow-listed deployment: everything the offline verifier needs about one vault. */
export interface Deployment {
    cfg: Cfg;
    cfgHash: Uint8Array;
    /** Immutable vault runtime code hash (the account `codeHash`). */
    vaultCodeHash: Uint8Array;
    /** Genesis `ConfigHash` of the EVM partition description. */
    evmConfigHash: Uint8Array;
    header: HeaderProfile;
    policy: Policy;
}
/** The configuration's own consistency (bft-core `Cfg.Validate`): identifiers recomputed from the family, a zero native address and a vault. */
export declare function validateCfg(cfg: Cfg): void;
/** Validate a deployment: identifiers recomputed from the family, policy bound into Cfg. */
export declare function makeDeployment(cfg: Cfg, vaultCodeHash: Uint8Array, evmConfigHash: Uint8Array, header: HeaderProfile, policy: Policy): Deployment;
/** An immutable allow-list keyed by `(network, chainId, vault)`; duplicates fail at registration. */
export declare class DeploymentRegistry {
    readonly deployments: readonly Deployment[];
    constructor(deployments: Deployment[]);
    index(network: number, chainId: bigint, vault: Uint8Array): number;
    find(network: number, chainId: bigint, vault: Uint8Array): Deployment;
    get tokenTypes(): Uint8Array[];
}
export { cfgBytes };
