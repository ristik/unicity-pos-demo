import { type Cfg, type Policy } from './profile.js';
export interface Anchor {
    partition: number;
    shard: Uint8Array;
    shardConfHash: Uint8Array;
    expectedStateRoot: Uint8Array;
    expectedIRHash: Uint8Array;
    uc: Uint8Array;
    inputRecord: Uint8Array;
}
export interface LeafProof {
    anchorIndex: number;
    bitmap: Uint8Array;
    siblings: Uint8Array[];
}
export interface Envelope {
    policyBody: Uint8Array;
    history: Uint8Array;
    anchors: Anchor[];
    leafProofs: LeafProof[];
}
export declare function encodeEnvelope(e: Envelope): Uint8Array;
/** Decode, rejecting noncanonical offsets/padding/aliases/trailing data by exact re-encoding. */
export declare function decodeEnvelope(b: Uint8Array): Envelope;
/**
 * The composing verifier's opening, run before the kernel and before any B1 call: the supplied body is
 * hashed against `Cfg.aggregatorPolicyHash` before it is interpreted, decoded (the partition-only body), the aggregator
 * partition must differ from the EVM partition and the anchor count must be within the bound. A submitted anchor
 * table never chooses its own admission.
 */
export declare function checkPolicyBody(cfg: Cfg, e: Envelope): Policy;
/** The anchor each leaf is certified by: an index into the envelope's anchor table. */
export interface AnchorPlan {
    leafAnchor: number[];
}
/**
 * The envelope's anchor table must be exactly the function of the exported leaves the profile defines: one leaf proof per leaf in
 * kernel order; every anchor of the policy's partition with a canonical native shard ID; anchors pairwise distinct by complete UC
 * bytes (byte-identical UCs are one anchor, never two); anchors numbered by first use in leaf order with none unused; and each
 * leaf's `anchorIndex` naming an anchor whose shard prefix the leaf's state ID carries (the first `d` bits, `d` that anchor's own
 * shard depth, never the current topology). Anchors of one history may come from different topologies: a parent shard before a
 * split and its child after it are both admitted, each bound by its own UC. The shard configuration hash is not checked here:
 * the UC authenticates it (B1). The number of anchors is not tied to the number of shards.
 */
export declare function planAnchors(pol: Policy, e: Envelope, sids: Uint8Array[]): AnchorPlan;
export interface InputRecordOpening {
    round: bigint;
    epoch: bigint;
    stateHash: Uint8Array;
    timestamp: bigint;
}
/** Bound, scan and parse the exact canonical native InputRecord opening (tag 39002, v1, arity 10); any shape failure is `ErrIRShape`. */
export declare function parseInputRecord(raw: Uint8Array): InputRecordOpening;
/** The anchor's opening: `H(inputRecord)==expectedIRHash`, then the exact shape, then the opened state hash == expectedStateRoot. */
export declare function openAnchor(a: Anchor): InputRecordOpening;
/**
 * Open every anchor and bound every leaf's reference time by the timestamp of the leaf's own anchor
 * (`t <=` its own IR time, never another anchor's).
 */
export declare function checkAnchors(e: Envelope, plan: AnchorPlan, leafTimes: bigint[]): InputRecordOpening[];
