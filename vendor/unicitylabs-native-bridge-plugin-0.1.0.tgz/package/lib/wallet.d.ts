/**
 * Wallet integration over bridge-core's structural contracts.
 *
 * The SDK's genesis hooks cannot enforce the full-history profile, so a bare `WalletTokenPlugin`
 * registration is not enough. {@link NativeBridgePayments} is the native `BridgePayments` adapter:
 * it gates every import/receive, cached balance activation, transfer, burn and export on
 * {@link NativeBridge.verifyNativeToken}, binds validation caches to exact token bytes, the pinned
 * trust-base document digest and the manifest/profile revision, and re-checks every burned blob it
 * receives instead of trusting a wallet success flag. Generic split/partial-payment/merge operations
 * are not exposed for this token type.
 *
 * Construction functions take an optional, separate transport; the verifier API has no network
 * capability. `ChainFamily` of bridge-core is not widened: native identity types stay local.
 */
import { type BridgePayments, type BurnForReturnArgs, type BurnForReturnResult, type MintRequest, type WalletBurnResult, type WalletMintResult, type WalletPendingBurn, type WalletTokenPlugin } from '@unicitylabs/bridge-core';
import type { InclusionProof } from '@unicitylabs/state-transition-sdk/lib/api/InclusionProof.js';
import type { ConsolidationResult, ProofUnavailableReason } from '@unicitylabs/state-transition-sdk/lib/consolidation/ConsolidationResult.js';
import type { Token } from '@unicitylabs/state-transition-sdk/lib/transaction/Token.js';
import { NativeError, type NativeReason } from './errors.js';
import { NativeBridge, type Expect, type VerifiedToken } from './verifier.js';
/** The wallet-side operations the adapter wraps. */
export interface NativeWalletBackend extends BridgePayments {
    /** The exact serialized token the wallet holds under `tokenId`, or null. */
    tokenBytes(tokenId: string): Promise<Uint8Array | null>;
    /** The recipient predicate (CBOR) the wallet will own a newly minted token with. */
    recipientPredicate(): Promise<Uint8Array>;
}
/** Revision strings that scope validation caches; any change invalidates every cached verdict. */
export interface PolicyRevision {
    manifestRevision: string;
    profileRevision: string;
}
/** The native plug-in: the bridge (deployments + pinned trust) plus its wallet-facing registrations. */
export interface NativeBridgePlugin {
    readonly bridge: NativeBridge;
    readonly revision: PolicyRevision;
    /** SDK registrations for wallets that wire the existing seams; not sufficient on their own. */
    readonly walletPlugin: WalletTokenPlugin;
    verifyNativeToken(bytes: Uint8Array, expect?: Expect): Promise<VerifiedToken>;
}
export declare function createNativeBridgePlugin(bridge: NativeBridge, revision: PolicyRevision): NativeBridgePlugin;
/** Cache of verdicts bound to exact token bytes, the pinned document digest and the revisions. */
export declare class VerdictCache {
    private readonly plugin;
    private readonly ok;
    constructor(plugin: NativeBridgePlugin);
    private key;
    verify(bytes: Uint8Array, expect: Expect): Promise<void>;
    get size(): number;
}
/**
 * A redemption journal entry; burn acknowledgement is durable handoff, not vault payout. The states in order:
 * `burned` (the certified blob is durably handed off), `submitted` (a `redeem` was sent; every hash is kept in `redeemTxs`, an
 * unknown outcome is never forgotten), `redeemed` (the vault credited `amount` to `releaseTo`), `settled` (the claim of that credit
 * was confirmed by its receipt and by the `claimable` balance falling by the claimed amount: the native funds are paid).
 */
export interface RedemptionEntry {
    burnId: string;
    tokenId: string;
    burnedToken: Uint8Array;
    nullifier: Uint8Array;
    /** The ROOT lock nonce of the token: with the part's token ID it keys the vault's spent state (`spentPart(nonce, partId)` holds the nullifier). */
    nonce: bigint;
    /** The redeemable native amount, in wei. */
    amount: bigint;
    releaseTo: Uint8Array;
    status: 'burned' | 'submitted' | 'redeemed' | 'settled';
    /** Every `redeem` transaction hash sent for this burn, oldest first. */
    redeemTxs: string[];
    /** A claim send was started (journalled BEFORE the send): without `claimTx` its hash may be lost, and no second claim is sent until the host decides (`abandonAttempt`). */
    claimStarted?: boolean;
    /** The claim transaction hash (`settled` once it is confirmed). */
    claimTx?: string;
}
/** The big-endian unsigned integer of a fixed-width byte string. */
export declare const uintOf: (b: Uint8Array) => bigint;
export interface RedemptionJournal {
    put(entry: RedemptionEntry): Promise<void>;
    get(burnId: string): Promise<RedemptionEntry | null>;
    list(): Promise<RedemptionEntry[]>;
}
/** Explicit test/demo journal. Its writes are not durable; the handoff callback remains required. */
export declare class MemoryRedemptionJournal implements RedemptionJournal {
    private readonly m;
    put(e: RedemptionEntry): Promise<void>;
    get(id: string): Promise<RedemptionEntry | null>;
    list(): Promise<RedemptionEntry[]>;
}
/** The gated `BridgePayments` adapter. */
export declare class NativeBridgePayments implements BridgePayments {
    private readonly plugin;
    private readonly backend;
    readonly journal: RedemptionJournal;
    readonly cache: VerdictCache;
    constructor(plugin: NativeBridgePlugin, backend: NativeWalletBackend, journal: RedemptionJournal);
    /** Verify the certified EVM lock before the SDK mint options are submitted. */
    mintCustom(request: Parameters<BridgePayments['mintCustom']>[0]): Promise<WalletMintResult>;
    /** Burn only a token that verifies as a native receipt; recheck the returned blob as a return. */
    burn(request: Parameters<BridgePayments['burn']>[0]): Promise<WalletBurnResult>;
    tokenJustification(tokenId: string): Promise<Uint8Array | null>;
    pendingBurns(): Promise<readonly WalletPendingBurn[]>;
    acknowledgeBurn(burnId: string): Promise<void>;
    /** Gate for import/receive and cached balance activation. */
    receive(bytes: Uint8Array): Promise<VerifiedToken>;
    /** Gate for export: only a native receipt may leave the wallet as a token. */
    export(tokenId: string): Promise<Uint8Array>;
}
/** Mint through bridge-core with the native pre-check. Mint options use null deadlines by default. */
export declare function mintBridgedToken(payments: NativeBridgePayments, request: MintRequest): Promise<WalletMintResult>;
/**
 * Burn for return: durable handoff of the full certified blob (journalled and rechecked as a native
 * return) before the wallet burn is acknowledged. Acknowledgement is not vault payout.
 */
export declare function burnForReturn(plugin: NativeBridgePlugin, payments: NativeBridgePayments, args: BurnForReturnArgs): Promise<BurnForReturnResult>;
/** Recover interrupted burns. `persist` must durably store the complete blob before resolving. */
export declare function recoverPendingBurns(plugin: NativeBridgePlugin, payments: NativeBridgePayments, persist: BurnForReturnArgs['persist']): Promise<readonly BurnForReturnResult[]>;
/** Source of fresh aggregator proofs for one token, in history order (host transport; untrusted). */
export type ProofSource = (token: Token) => Promise<InclusionProof[]>;
/**
 * The host's consolidation of a token (the SDK's uc-consolidation flow, `TokenProofClient.consolidate`, over the host's routing and
 * transport). It returns the SDK's result; a `ConsolidationError` of any kind (`cancelled`, `input`, `integrity`,
 * `invalid_response`, `rejected`, `server`, `timeout`, `transport`) is thrown as the SDK throws it and is never turned into a
 * fallback. Like a `ProofSource` it is host code and untrusted: only the outer proofs of its token are used, re-attached to the held
 * token's own transactions (`refreshToken`), so a token other than the held one is `ErrRefreshMismatch`.
 */
export type TokenConsolidator = (token: Token) => Promise<ConsolidationResult>;
/** The partition view's V1 shard limit (`MaxPartitionViewLeaves`): a larger partition is never consolidated. */
export declare const MAX_VIEW_SHARDS = 8;
/** The consolidated path's inputs from the host: its consolidator and the aggregation partition's shard count (its routing). */
export interface ConsolidationPath {
    consolidate: TokenConsolidator;
    partitionShards: number;
}
/**
 * How a return proof was assembled: from the consolidated token (one seal), or per SID: consolidation not used, the partition
 * over the view's shard limit (`overViewLimit`, consolidation not called), or consolidation `unavailable`.
 */
export type ReturnProofPath = {
    kind: 'consolidated';
} | {
    kind: 'per-sid';
    overViewLimit?: true;
    unavailable?: ProofUnavailableReason;
    retryable?: boolean;
};
/**
 * One consolidation attempt for `held`: the outer proofs of the consolidated token (to be re-attached to `held` with
 * `refreshToken`), or none and the per-SID path with its cause (no consolidation configured, the partition over the view's shard
 * limit, consolidation `unavailable`). A `ConsolidationError` propagates.
 */
export declare function consolidatedProofs(held: Token, consolidation?: ConsolidationPath): Promise<{
    proofs?: InclusionProof[];
    path: ReturnProofPath;
}>;
/** Attempts at fetching and assembling one return proof before it is reported unavailable. */
export declare const MAX_PROOF_ATTEMPTS = 3;
/**
 * Failures that mean the fetched (path, UC) pair raced a certificate or does not belong together: the
 * path does not verify under its own UC. They are retried a bounded number of times with a fresh fetch;
 * nothing is re-queried to make certificates converge, and a pair that never verifies is `ErrProofUnavailable`.
 */
export declare const PAIR_RACE: readonly NativeReason[];
/**
 * Assemble the return proof, refreshing the aggregator proofs first from the optional transport.
 * Refresh keeps J/M/T/CD and the original `t`; a proof for another epoch is rejected by verification.
 * Every response keeps its own (path, UC) pair; assembly uses only what the transport returned.
 */
export declare function buildNativeReturnProof(plugin: NativeBridgePlugin, tokenBytes: Uint8Array, source?: ProofSource, consolidation?: ConsolidationPath): Promise<{
    encoded: Uint8Array;
    nullifier: Uint8Array;
    path: ReturnProofPath;
    tokenBytes: Uint8Array;
}>;
/**
 * `claim(uint256 amount, address to)`: the vault's guarded pull payment, as calldata. An amount that does not fit a word, the zero address
 * and the vault itself are refused before any gas is paid (the vault would refuse the last two with `BadRecipient`).
 */
export declare function claimCalldata(amount: bigint, to: Uint8Array, vault: Uint8Array): Uint8Array;
/**
 * Submit `claim` and return the transaction hash. This only SENDS: it does not wait for the receipt or read `claimable`. Use `claimCredited`
 * (`lifecycle.ts`) for the journalled path whose settlement is confirmed from the receipt and the balance, never from this call or the burn acknowledgement.
 * Only the credited recipient can redirect.
 */
export declare function claim(send: (tx: {
    to: Uint8Array;
    data: Uint8Array;
}) => Promise<string>, vault: Uint8Array, amount: bigint, to: Uint8Array): Promise<string>;
export { NativeError };
