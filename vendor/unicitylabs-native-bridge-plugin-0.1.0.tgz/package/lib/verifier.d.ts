import { CertifiedMintTransaction } from '@unicitylabs/state-transition-sdk/lib/transaction/CertifiedMintTransaction.js';
import { Token } from '@unicitylabs/state-transition-sdk/lib/transaction/Token.js';
import { TokenType } from '@unicitylabs/state-transition-sdk/lib/transaction/TokenType.js';
import type { IMintJustificationVerifier } from '@unicitylabs/state-transition-sdk/lib/transaction/verification/IMintJustificationVerifier.js';
import type { ITokenVerifier } from '@unicitylabs/state-transition-sdk/lib/transaction/verification/ITokenVerifier.js';
import type { IVerificationContext } from '@unicitylabs/state-transition-sdk/lib/transaction/verification/IVerificationContext.js';
import { VerificationContext } from '@unicitylabs/state-transition-sdk/lib/transaction/verification/VerificationContext.js';
import type { WalletIssuancePolicy } from '@unicitylabs/bridge-core';
import { VerificationResult } from '@unicitylabs/state-transition-sdk/lib/verification/VerificationResult.js';
import { VerificationStatus } from '@unicitylabs/state-transition-sdk/lib/verification/VerificationStatus.js';
import type { DeploymentRegistry } from './deployment.js';
import { type NativeReason } from './errors.js';
import { type Outcome } from './history.js';
import { type VerifiedLock } from './lockproof.js';
import { type LineageOutcome } from './lineage.js';
import { type TrustInput } from './trust.js';
export type Expect = 'receipt' | 'return';
export interface VerifiedToken {
    /** For a split part, the lineage's root identity and every leaf of the lineage, root first (`lineage` below). */
    outcome: Outcome;
    lock: VerifiedLock;
    /** Index of the allow-listed deployment the token was verified under. */
    deployment: number;
    /** A split part's lineage (protocol 6): the part, the depth and the walk's charge; absent for a lock-backed token. */
    lineage?: LineageOutcome;
}
/** Name an SDK verification failure with the shared sentinel vocabulary. */
export declare function mapSdkFailure(r: VerificationResult<unknown>): NativeReason;
export declare class NativeBridge {
    readonly registry: DeploymentRegistry;
    readonly trust: TrustInput;
    constructor(registry: DeploymentRegistry, trust: TrustInput);
    /** The SDK verification context with this bridge's justification verifier and issuance policies. */
    context(base?: Partial<Pick<IVerificationContext, 'predicateVerifier' | 'unicityCertificateVerifier'>>): Promise<VerificationContext>;
    /** Decode canonical token bytes (bounded, re-encoding equal) and verify them. */
    verifyNativeTokenBytes(bytes: Uint8Array, expect: Expect): Promise<VerifiedToken>;
    /** Verify a return as the completion of this exact held-token burn request. */
    verifyBurnRequestBytes(held: Uint8Array, burned: Uint8Array, reason: Uint8Array): Promise<VerifiedToken>;
    verifyNativeToken(token: Token, expect: Expect, parts?: Partial<Pick<IVerificationContext, 'predicateVerifier' | 'unicityCertificateVerifier'>>): Promise<VerifiedToken>;
    /**
     * A split part (protocol 6): the lineage relation over the part's projection (its ancestry read from the exact reason bytes), the
     * root's lock proof against the root's lock digest, every leaf of the lineage (root first) admitted under the deployment's policy,
     * then the SDK's own verification (the split verifier walks the same ancestry).
     */
    private verifySplitPart;
    private checkLeaf;
}
/** Verifies the native lock justification of a genesis fully offline (tag 39049, version 2). */
export declare class NativeLockJustificationVerifier implements IMintJustificationVerifier {
    private readonly bridge;
    lastError: NativeReason | null;
    constructor(bridge: NativeBridge);
    get tag(): bigint;
    /** Verify the genesis binding to the certified permanent lock; throws a {@link NativeError}. */
    check(genesis: CertifiedMintTransaction): Promise<void>;
    verify(transaction: CertifiedMintTransaction): Promise<VerificationResult<VerificationStatus>>;
}
/**
 * Claims exactly the native asset for one token type: the exact lock reason and the exact value
 * envelope, no null or unknown reason. A split output (protocol 6) is admitted only when the root its
 * reason walks down to is a lock of an allow-listed deployment of this type and its value is that
 * deployment's exact envelope; the split verifier proves the allocation and the burned parent.
 */
export declare class BridgedTokenIssuancePolicy implements WalletIssuancePolicy {
    private readonly bridge;
    readonly tokenType: TokenType;
    readonly coinIds: readonly string[];
    readonly revision?: string;
    lastError: NativeReason | null;
    constructor(bridge: NativeBridge, ty: Uint8Array, revision?: string);
    check(genesis: CertifiedMintTransaction): void;
    verify(transaction: CertifiedMintTransaction): Promise<VerificationResult<VerificationStatus>>;
}
/**
 * `ITokenVerifier` for the SDK seam: the SDK's ordinary verification composed with the strict
 * bridge verification. The caller's context must carry the same pinned trust base.
 */
export declare class NativeBridgeTokenVerifier implements ITokenVerifier {
    private readonly bridge;
    private readonly expect;
    lastError: NativeReason | null;
    constructor(bridge: NativeBridge, expect?: Expect);
    verify(token: Token, context: IVerificationContext): Promise<VerificationResult<VerificationStatus>>;
}
